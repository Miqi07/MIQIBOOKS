// Příliš žluťoučký kůň úpěl ďábelské ó - PŘÍLIŠ ŽLUŤOUČKÝ KŮŇ ÚPĚL ĎÁBELSKÉ Ó
// J:/77_JAVA/b77_java_nz2/vehicle/IVehicle1_1.java

import java.util.Set;


class StaticArray {
    static final int SIZE = 10;
    static int[] array1 = new int[SIZE];  //OK - SIZE je compile-time konstanta
    static int x() { return 10; } //new Random().nextInt(10); }
    static int[] array2 = new int[x()];
}

class A{}

/*******************************************************************************
 * Definuje společné rozhraní vozidel vytvářených ve 14. kapitole.
 */
public class Exp
{
    <P> String gen(P param) {return param.toString();}
    public static void main(String[] args)
    {
        shapes77.dbg.ClassInfo.analyze(A.class);
    }
}
