package b77_java_nz2._11_arrangement;
// Příliš žluťoučký kůň úpěl ďábelské ó - PŘÍLIŠ ŽLUŤOUČKÝ KŮŇ ÚPĚL ĎÁBELSKÉ Ó
// J:/77_JAVA/b67_java_nz2/_11_arrangement/Light.java

import shapes77.canvas_1.Ellipse;
import shapes77.canvas_1.NamedColor;


/********************************************************************************
 * Instance představují světla, která je možné rozsvítit a zhasnout.
 * Odpovídá závěrečná verzi kapitoly 10 s doplněnými metodami z úlohy 10.1.
 */
public class Light
{
    private static final int        DEFAULT_SIZE  = 50;
    private static final NamedColor DEFAULT_COLOR = NamedColor.RED;
    private static final NamedColor OFF_COLOR     = NamedColor.DARK_GRAY;

    private static int instances = 0;   //Počet vytvořených instancí

    public static int instances() {
        return instances;
    }

//##############################################################################

    private final int ID = ++instances; //Rodné číslo instance

    private final Ellipse    bulb;      //Reprezentuje žárovku
    private final NamedColor color;     //Barva rozsvícené žárovky

    public Light() {
        this(0, 0);
    }

    public Light(int x, int y) {
        this(x, y, DEFAULT_SIZE);
    }

    public Light(int x, int y, int size) {
        this(x, y, size, DEFAULT_COLOR);
    }

    public Light(int x, int y, int size, NamedColor color) {
        this.color = color;
        this.bulb  = new Ellipse(x, y, size, size, color);
    }

    public NamedColor color() {
        return color;
    }

    public boolean isOn() {
        return color == bulb.getColor();
    }

    public void setPosition(int x, int y) {
        bulb.setPosition(x, y);
    }

    public void setSize(int width, int height) {
        bulb.setSize(width, height);
    }

    public void switchOff() {
        bulb.setColor(OFF_COLOR);
    }

    public void switchOn() {
        bulb.setColor(color);
    }

    public String toString() {
        return "Light_" + ID + "(x=" + bulb.getX() + ", y=" + bulb.getY()
             + ", size=" + bulb.getWidth() + ", color=" + color
             + ", isOn=" + isOn() + ")";
    }
}
