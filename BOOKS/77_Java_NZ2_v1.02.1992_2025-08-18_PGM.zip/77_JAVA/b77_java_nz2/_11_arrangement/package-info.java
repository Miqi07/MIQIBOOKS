// Příliš žluťoučký kůň úpěl ďábelské ó - PŘÍLIŠ ŽLUŤOUČKÝ KŮŇ ÚPĚL ĎÁBELSKÉ Ó
// J:/77_JAVA/b77_java_nz2/_11_arrangement/package-info.java

/********************************************************************************
 * Balíček obsahuje doprovodné programy ke kapitole
 * <i>11  Uspořádání kódu</i>.
 */
package b77_java_nz2._11_arrangement;
