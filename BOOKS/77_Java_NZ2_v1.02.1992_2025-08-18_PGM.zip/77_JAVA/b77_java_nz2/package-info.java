// Příliš žluťoučký kůň úpěl ďábelské ó - PŘÍLIŠ ŽLUŤOUČKÝ KŮŇ ÚPĚL ĎÁBELSKÉ Ó
// J:/77_JAVA/b77_java_nz2/package-info.java


/*******************************************************************************
 * Balíček {@code eu.pedu.lib} obsahuje datové typy knihovny
 * pro podporu výuky programování v Javě.
 */
package b77_java_nz2;
