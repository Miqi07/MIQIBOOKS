package b77_java_nz2._27_application;
// Příliš žluťoučký kůň úpěl ďábelské ó - PŘÍLIŠ ŽLUŤOUČKÝ KŮŇ ÚPĚL ĎÁBELSKÉ Ó
// J:/77_JAVA/b77_java_nz2/_27_application/Enter.java

import java.util.Scanner;

class Enter
{
    private static Scanner sc = new Scanner(System.in);

    /** Pomocná metoda realizující vstup. */
    public static int enter(String msg)
    {
        System.out.print(msg + "\nZadáš: ");    //Neodřádkuje
        int result;
        for(;;) {
            try {
                result = sc.nextInt();  //Přečte další odhad
                if (result == 0) {      //Uživatel už chce končit
                    System.out.print("Děkuji za hru\n");
                    System.exit(0);  //Ukončení aplikace ≡≡≡≡≡≡≡≡≡≡>
                }
            } catch (Exception e) {
                String answer = sc.next();  //Přečte vadný token
                System.out.print(answer + " není celé číslo, zkus to znovu"
                               + "\nZadej celé číslo: ");
                continue;   //Necháme uživatele zadat odhad znovu
            }
            return result;
        }
    }
}
