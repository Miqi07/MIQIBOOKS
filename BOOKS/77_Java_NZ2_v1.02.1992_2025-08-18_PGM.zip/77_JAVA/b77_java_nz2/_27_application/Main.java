package b77_java_nz2._27_application;
// Příliš žluťoučký kůň úpěl ďábelské ó - PŘÍLIŠ ŽLUŤOUČKÝ KŮŇ ÚPĚL ĎÁBELSKÉ Ó
// J:/77_JAVA/b77_java_nz2/_27_application/Main.java

import java.util.Arrays;
import java.util.function.Consumer;
import java.util.function.ToIntFunction;
import shapes77.util.IO;

public class Main
{
    public static void main(String[] args)
    {
        ToIntFunction<String> input;    //Zjištění uživatelova odhadu
        Consumer<String>      output;   //Vypsání oznamovací zprávy

        if (Arrays.asList(args).contains("-con")) {
            input  = Enter::enter;          //Metoda enter() třídy Enter
            output = System.out::println;   //Tisk na standardní výstup
        }
        else {
            input  = msg -> IO.enter(msg, 0); //Metoda enter() třídy IO
            output = IO::inform;                    //Zpráva v dialogovém okně
        }
        GuessIO.guess(input, output);
    }
}
