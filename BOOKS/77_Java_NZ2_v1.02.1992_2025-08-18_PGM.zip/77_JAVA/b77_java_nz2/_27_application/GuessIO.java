package b77_java_nz2._27_application;
// Příliš žluťoučký kůň úpěl ďábelské ó - PŘÍLIŠ ŽLUŤOUČKÝ KŮŇ ÚPĚL ĎÁBELSKÉ Ó
// J:/77_JAVA/b77_java_nz2/_27_application/GuessIO.java

import java.util.function.Consumer;
import java.util.function.ToIntFunction;

public class GuessIO
{
    public static void guess(ToIntFunction<String> input,
                             Consumer     <String> inform)
    {
        int number = new java.util.Random().nextInt(100); //Hádané číslo
        String msg = "Myslím si číslo od 0 do 100.\n"
                   + "Zkus jej uhodnout.\n"
                   + "Zadáním nuly předčasně ukončíš hru";
        int guess = 0;              //Proměnná pro odpovědi uživatele
        for(;;) {
            guess = input.applyAsInt(msg);      //Další odhad
            if (guess == number)    break;      //Trefil se
            if (guess == 0) {
                inform.accept("Děkuji za hru\n");
                System.exit(0);  //Konec aplikace ≡≡≡≡≡≡≡≡≡≡>
            }
            msg = "Zadal jsi " + guess + " - "
                + ((guess < number)  ?  "To je málo."
                                     :  "To je moc.")
                + " - Zkus to znovu.";
        }
        inform.accept("Hurá! To bylo ono!\nDěkuji za hru.");
    }
}
