// Příliš žluťoučký kůň úpěl ďábelské ó - PŘÍLIŠ ŽLUŤOUČKÝ KŮŇ ÚPĚL ĎÁBELSKÉ Ó
// J:/77_JAVA/_23_arrays/_22_containers/package-info.java

/********************************************************************************
 * Balíček obsahuje doprovodné programy ke kapitole
 * <i>23  Pole</i>.
 */
package b77_java_nz2._23_arrays;
