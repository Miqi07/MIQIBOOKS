package b77_java_nz2._23_arrays;
// Příliš žluťoučký kůň úpěl ďábelské ó - PŘÍLIŠ ŽLUŤOUČKÝ KŮŇ ÚPĚL ĎÁBELSKÉ Ó
// J:/77_JAVA/b77_java_nz2/_23_arrays/Number2CZWords.java



/********************************************************************************
 * Knihovní třída {@code Number2CZWords} slouží k převodu celých čísel
 * na textové řetězce vyjadřující hodnotu zadaného čísla slovy v češtině.
 */
public final class Number2CZWords
{
//\CC== CLASS CONSTANTS (CONSTANT CLASS/STATIC ATTRIBUTES/FIELDS) ==============

    /** Největší číslo, které umí program převést na text. */
    public static final long MAX = 999L;

    /** Názvy čísel do dvaceti. */
    private static final String[] UNITS__STRINGSCZ = {
        "",        "jedna",    "dva",       "tři",      "čtyři",
        "pět",     "šest",     "sedm",      "osm",      "devět",
        "deset",   "jedenáct", "dvanáct",   "třináct",  "čtrnáct",
        "patnáct", "šestnáct", "sedmnáct",  "osmnáct",  "devatenáct"
    };

    /** Názvy desítek. */
    private static final String[] TENS_CZ = {
        "",        "",         "dvacet",    "třicet",   "čtyřicet",
        "padesát", "šedesát",  "sedmdesát", "osmdesát", "devadesát"
    };

    /** Názvy stovek. */
    private static final String[] HUNDREDS_CZ = {
        "",        "sto",      "dvě stě",   "tři sta",  "čtyři sta",
        "pět set", "šest set", "sedm set",  "osm set",  "devět set"
    };



//\CM== CLASS (STATIC) REMAINING NON-PRIVATE METHODS ===========================

    /***************************************************************************
     * Metoda vrátí řetězec představující slovní vyjádření zadaného čísla.
     *
     * @param number  Číslo, které chceme vyjádřit slovy.
     *
     * @return Slovní vyjádření zadaného čísla
     * @throws IllegalArgumentException je-li číslo příliš malé nebo veliké
     */
    public static String convert(int number)
    {
        if ((number < 0)  ||  (MAX < number)) {
            throw new IllegalArgumentException(
                    "Lze převádět pouze nezáporná čísla do " + MAX);
        }
        if (number == 0) {
            return "nula";                         //====================>
        }
        if (number < 20) {
            return UNITS__STRINGSCZ[number];       //====================>
        }
        int units    = number % 10;     //Počet jednotek
        int tens     = number / 10;     //Celkový počet desítek
        int hundreds = tens / 10;       //Počet stovek
            tens     = tens % 10;       //Počet pouhých desítek
        return HUNDREDS_CZ[hundreds] +
              (((hundreds  > 0)  &&  (number%100 > 0))  ?  " "  :  "")  +
              ((tens < 2)  ?  UNITS__STRINGSCZ[ 10*tens + units ]
                           :  (TENS_CZ [ tens ]) +
                              ((units > 0)  ?  " "  :  "")  +
                              UNITS__STRINGSCZ[ units ]);
    }



//##############################################################################
//\II== INSTANCE INITIALIZERS (CONSTRUCTORS) ===================================

    /***************************************************************************
     * Tato třída bude knihovní, bude obsahovat pouze statické metody,
     * takže od ní zakážeme vytvářet instance.
     */
    private Number2CZWords()
    {
    }
}
