package b77_java_nz2._16_deepen;
// Příliš žluťoučký kůň úpěl ďábelské ó - PŘÍLIŠ ŽLUŤOUČKÝ KŮŇ ÚPĚL ĎÁBELSKÉ Ó
// J:/77_JAVA/b77_java_nz2/_16_deepen/StaticArray.java

import java.util.Random;

/*******************************************************************************
 * Třída {@code StaticArray} je
 */
public class StaticArray
{
    static final int SIZE = 10;
    static final int[] array1 = new int[SIZE];  //OK

    static int x() { return new Random().nextInt(10); }
    static final int[] array2 = new int[x()];   //Ve starších verzích nefunguje

    public static void main(String[] args) {
        System.out.println("array2.length = " + array2.length);
    }
}
