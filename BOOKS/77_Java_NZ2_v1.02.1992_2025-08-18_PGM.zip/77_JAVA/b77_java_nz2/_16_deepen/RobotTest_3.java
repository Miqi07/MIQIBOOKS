package b77_java_nz2._16_deepen;
// Příliš žluťoučký kůň úpěl ďábelské ó - PŘÍLIŠ ŽLUŤOUČKÝ KŮŇ ÚPĚL ĎÁBELSKÉ Ó
// J:/77_JAVA/b77_java_nz2/_16_deepen/RobotTest_3.java

import shapes77.canvasmanager.CanvasManager;
import shapes77.geom.Direction8;
import shapes77.geom.Resizer;

import b77_java_nz2.vehicle.IVehicle1_3;
import b77_java_nz2.vehicle.IVehicleFactory1_3;
import b77_java_nz2.vehicle.IVehicleTest_3;
import b77_java_nz2.vehicle.Vehicles_3;



/********************************************************************************
 * Instance třídy {@code RobotTest_3} představují testy
 * prověřující vozidla implementující interfejs {@link IVehicle1_3}.
 */
public  class      RobotTest_3
        implements IVehicleTest_3
{
//\CC== CLASS CONSTANTS (CONSTANT CLASS/STATIC ATTRIBUTES/FIELDS) ==============
//\CV== CLASS VARIABLES (VARIABLE CLASS/STATIC ATTRIBUTES/FIELDS) ==============



//##############################################################################
//\CI== CLASS (STATIC) INITIALIZER (CLASS CONSTRUCTOR) =========================
//\CF== CLASS (STATIC) FACTORY METHODS =========================================
//\CG== CLASS (STATIC) GETTERS AND SETTERS =====================================
//\CM== CLASS (STATIC) REMAINING NON-PRIVATE METHODS ===========================
//\CP== CLASS (STATIC) PRIVATE AND AUXILIARY METHODS ===========================



//##############################################################################
//\IC== INSTANCE CONSTANTS (CONSTANT INSTANCE ATTRIBUTES/FIELDS) ===============

    /** Objekt uchovávající název aktuálního testu. */
    public String testName;



//\IV== INSTANCE VARIABLES (VARIABLE INSTANCE ATTRIBUTES/FIELDS) ===============

    private CanvasManager CM;
    private IVehicle1_3 vehicleE;
    private IVehicle1_3 vehicleN;
    private IVehicle1_3 vehicleW;
    private IVehicle1_3 vehicleS;



//##############################################################################
//\II== INSTANCE INITIALIZERS (CONSTRUCTORS) ===================================
//----- Test class manages with empty default constructor ----------------------



//\IA== INSTANCE ABSTRACT METHODS ==============================================
//\IG== INSTANCE GETTERS AND SETTERS ===========================================

    /***************************************************************************
     * Vrátí instanci tovární třídy.
     *
     * @return Instance tovární třídy
     */
    @Override
    public IVehicleFactory1_3 factory() {
        return new RobotFactory_3();
    }

    /***************************************************************************
     * Vrátí přepravku (záznam) s instancemi vozidel tvořících přípravek.
     *
     * @return Přepravka s instancemi vozidel tvořících přípravek
     */
    @Override
    public Vehicles_3 fixtureObjects() {
        return new Vehicles_3(vehicleE, vehicleS, vehicleW, vehicleN);
    }

    /***************************************************************************
     * Vrátí název aktuálně spuštěného testu.
     *
     * @return Název aktuálně spuštěného testu
     */
    @Override
    public String testName() {
        return testName;
    }



//\IM== INSTANCE REMAINING NON-PRIVATE METHODS =================================
//\IP== INSTANCE PRIVATE AND AUXILIARY METHODS =================================

    /***************************************************************************
     * Nastaví rozměr vozidla obdrženého v prvním parametru na 50 bodů tak,
     * aby jeho roh ve směru zadaném v druhém parametru nezměnil pozici.
     *
     * @param vehicle "Resizované" vozidlo
     * @param dir     Směr ukotveného rohu
     */
    private void resizeToDir(IVehicle1_3 vehicle, Direction8 dir) {
        Resizer r = new Resizer(100);
        r.resizeTo(50, vehicle, dir);
    }




//##############################################################################
//\NT== NESTED DATA TYPES ======================================================



//##############################################################################
//\TC== PREPARATION AND CLEAN UP OF THE CLASS FIXTURE ==========================
//\TI== PREPARATION AND CLEAN UP OF THE TEST FIXTURE ===========================

    /***************************************************************************
     * Inicializace předcházející spuštění každého testu a připravující tzv.
     * testovací přípravek (test fixture), po jehož přípravě otevře dialogové
     * okno, v němž oznámí zhotovení přípravku spolu se jménem autora/autorky,
     * názvem testovací třídy a názvem spouštěného testu (testovací metody).
     */
    @Override
    public void setUp() {
        vehicleS = new Robot1S_3();
        vehicleW = new Robot1W_3();
        vehicleN = new Robot1N_3();
        vehicleE = new Robot1E_3();

        vehicleS.setPosition(200,   0);
        vehicleW.setPosition(200, 200);
        vehicleN.setPosition(  0, 200);
        vehicleE.setPosition(  0,   0);

        CM = CanvasManager.getInstance();
        CM.add(vehicleE, vehicleS, vehicleW, vehicleN);

        fixtureReady();
    }

    /***************************************************************************
     * Úklid po testu - tato metoda se spustí po vykonání každého testu.
     * Metoda nejprve otevře dialogové okno, oznámí ukončení testu,
     * přičemž oznámí názvem testovací třídy a ukončeného testu.
     * Na závěr vyčistí plátno.
     */
    @Override
    public void tearDown() {
        testFinished();
    }



//##############################################################################
//\TT== TESTS PROPER ===========================================================

    /***************************************************************************
     * S každým z vozidel popojede o 50 bodů vpřed prostřednictvím zavolání
     * jeho metody <b>{@link IVehicle1_3#forward(int)}</b>.
     */
    @Override
    public void testForward() {
        vehicleE.forward(50);
        vehicleN.forward(50);
        vehicleW.forward(50);
        vehicleS.forward(50);
    }

    /***************************************************************************
     * Zmenší každé z vozidel na modul 50 tak,
     * aby vozidlo zůstalo nadále umístěné v příslušném rohu plátna.
     */
    @Override
    public void testResizeToCorner() {
        resizeToDir(vehicleE, Direction8.NORTH_WEST);
        resizeToDir(vehicleN, Direction8.SOUTH_WEST);
        resizeToDir(vehicleW, Direction8.SOUTH_EAST);
        resizeToDir(vehicleS, Direction8.NORTH_EAST);
    }

}
