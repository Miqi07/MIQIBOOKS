package b77_java_nz2._16_deepen;
// Příliš žluťoučký kůň úpěl ďábelské ó - PŘÍLIŠ ŽLUŤOUČKÝ KŮŇ ÚPĚL ĎÁBELSKÉ Ó
// J:/77_JAVA/b77_java_nz2/_16_deepen/Robot1E_3.java

import shapes77.canvasmanager.Ellipse;
import shapes77.canvasmanager.Multishape;
import shapes77.canvasmanager.Painter;
import shapes77.canvasmanager.Rectangle;
import shapes77.canvasmanager.Triangle;
import shapes77.geom.Direction8;
import shapes77.util.NamedColor;

import b77_java_nz2.vehicle.IVehicle1_3;
import b77_java_nz2.vehicle.IVehicleFactory1_3;


/********************************************************************************
 * Instance třídy {@code Robot1E_3} reprezentují na východ otočená vozidla,
 * která znají svůj směr a umějí měnit svoji pozici a velikost.
 * Oproti minulé verzi umožňují zadat hlavní barvu vytvářeného vozidla
 * a znají sdruženou tovární třídu.
 */
public   class Robot1E_3
    implements IVehicle1_3
{
//\CC== CLASS CONSTANTS (CONSTANT CLASS/STATIC ATTRIBUTES/FIELDS) ==============

    /** Implicitní hlaní barva vozidla. */
    public static final NamedColor DEFAULT_COLOR = NamedColor.RED;



//\CV== CLASS VARIABLES (VARIABLE CLASS/STATIC ATTRIBUTES/FIELDS) ==============



//##############################################################################
//\CI== CLASS (STATIC) INITIALIZER (CLASS CONSTRUCTOR) =========================
//\CF== CLASS (STATIC) FACTORY METHODS =========================================
//\CG== CLASS (STATIC) GETTERS AND SETTERS =====================================
//\CM== CLASS (STATIC) REMAINING NON-PRIVATE METHODS ===========================
//\CP== CLASS (STATIC) PRIVATE AND AUXILIARY METHODS ===========================



//##############################################################################
//\IC== INSTANCE CONSTANTS (CONSTANT INSTANCE ATTRIBUTES/FIELDS) ===============

    /** Hlavní barva vozidla. */
    public final NamedColor color;

    /** Mnohotvar uchovávající grafickou podobu vytvořeného vozidla. */
    private final Multishape multishape;



//\IV== INSTANCE VARIABLES (VARIABLE INSTANCE ATTRIBUTES/FIELDS) ===============



//##############################################################################
//\II== INSTANCE INITIALIZERS (CONSTRUCTORS) ===================================

    /***************************************************************************
     * Vytvoří v implicitní pozici [0; 0] vozidlo implicitní velikosti 100
     * a implicitní barvy otočené na východ.
     */
    public Robot1E_3()
    {
        this(DEFAULT_COLOR);
    }

    /***************************************************************************
     * Vytvoří v implicitní pozici [0; 0] vozidlo implicitní velikosti 100
     * a zadané barvy otočené na východ.
     *
     * @param color Hlavní barva vozidla
     */
    public Robot1E_3(NamedColor color) {
        this.color        = color;
        Rectangle frame   = new Rectangle( 0,  0,100,100, NamedColor.NO);
        Rectangle body    = new Rectangle( 0, 20, 70, 60, color);
        Ellipse   nose    = new Ellipse  (40, 20, 60, 60, color);
        Rectangle arrBody = new Rectangle( 0, 30, 70, 40, color.inverse());
        Triangle  arrHead = new Triangle (70, 20, 30, 60, color.inverse(),
                                                          Direction8.EAST);
        multishape = new Multishape(frame, body, nose, arrBody, arrHead);
    }

    /***************************************************************************
     * Vytvoří v zadané pozici [0; 0] vozidlo implicitní velikosti 100
     * otočené na východ.
     *
     * @param x Vodorovná souřadnice vytvářeného vozidla
     * @param y Svislá souřadnice vytvářeného vozidla
     */
    public Robot1E_3(int x, int y) {
        this ();
        multishape.setPosition(x, y);
    }

    /***************************************************************************
     * Vytvoří v zadané pozici [0; 0] vozidlo zadané velikosti
     * otočené na východ.
     *
     * @param x Vodorovná souřadnice vytvářeného vozidla
     * @param y Svislá souřadnice vytvářeného vozidla
     * @param module Velikost vozidla = čtverce opsaného vytvářenému vozidlu
     */
    public Robot1E_3(int x, int y, int module) {
        this(x, y);
        multishape.setSize(module, module);
    }



//\IA== INSTANCE ABSTRACT METHODS ==============================================
//\IG== INSTANCE GETTERS AND SETTERS ===========================================

    /***************************************************************************
     * Vrátí instanci tovární třídy.
     *
     * @return Instance tovární třídy
     */
    @Override
    public IVehicleFactory1_3 factory() {
        return new RobotFactory_3();
    }

    /***************************************************************************
     * Vrátí hlavní barvu vozidla.
     *
     * @return  Instance třídy {@link NamedColor} definující
     *          hlavní barvu vozidla
     */
    @Override
    public NamedColor color() {
        return color;
    }

    /***************************************************************************
     * Vrátí směr, do nějž je vozidlo právě natočeno.
     *
     * @return  Instance třídy {@link Direction8} definující
     *          směr, do nějž je vozidlo právě natočeno
     */
    @Override
    public Direction8 getDirection() {
        return Direction8.EAST;
    }


    /***************************************************************************
     * Vrátí x-ovou (vodorovnou) souřadnici pozice instance,
     * tj. vodorovnou souřadnici levého horního rohu opsaného obdélníku.
     *
     * @return  Aktuální vodorovná (x-ová) souřadnice instance,
     *          x=0 má levý okraj plátna, souřadnice roste doprava
     */
    @Override
    public int getX() {
        return multishape.getX();
    }


    /***************************************************************************
     * Vrátí y-ovou (svislou) souřadnici pozice instance,
     * tj. svislou souřadnici levého horního rohu opsaného obdélníku.
     *
     * @return  Aktuální svislá (y-ová) souřadnice instance,
     *          y=0 má horní okraj plátna, souřadnice roste dolů
     */
    @Override
    public int getY() {
        return multishape.getY();
    }


    /***************************************************************************
     * Přemístí instanci na zadanou pozici.
     * Pozice instance je přitom definována jako pozice
     * levého horního rohu opsaného obdélníku.
     *
     * @param x  Nově nastavovaná vodorovná (x-ová) souřadnice instance,
     *           x=0 má levý okraj plátna, souřadnice roste doprava
     * @param y  Nově nastavovaná svislá (y-ová) souřadnice instance,
     *           y=0 má horní okraj plátna, souřadnice roste dolů
     */
    @Override
    public void setPosition(int x, int y) {
        multishape.setPosition(x, y);
    }


    /***************************************************************************
     * Vrátí velikost modulu, tj. délku strany opsaného čtverce.
     *
     * @return   Velikost modulu instance
     */
    @Override
    public int getModule() {
        return multishape.getWidth();
    }


    /***************************************************************************
     * Změní velikost instance, aby měl její nový modul
     * (= délku strany opsaného čtverce) zadanou velikost.
     *
     * @param module    Nově nastavovaný modul
     */
    @Override
    public void setModule(int module) {
        multishape.setSize(module, module);
    }



//\IM== INSTANCE REMAINING NON-PRIVATE METHODS =================================

    /***************************************************************************
     * Prostřednictvím dodaného kreslítka vykreslí obraz své instance.
     *
     * @param painter Kreslítko schopné kreslit na plátno ovládané správcem
     */
    @Override
    public void paint(Painter painter) {
        multishape.paint(painter);
    }

    /***************************************************************************
     * Přesune vozidlo o velikost jeho modulu vpřed.
     */
    @Override
    public void forward() {
        forward(getModule());
    }

    /***************************************************************************
     * Přesune vozidlo o zadanou vzdálenost vpřed.
     *
     * @param distance Vzdálenost, o níž se má vozidlo přesunout
     */
    @Override
    public void forward(int distance) {
        multishape.setPosition(getX()+distance, getY());
    }

    /***************************************************************************
     * Vrátí textový podpis instance sestávající z názvu mateřské třídy
     * náslkedovaným jejími souřadnicemi a velikostí.
     *
     * @return Textový podpis instance
     */
    @Override
    public String toString() {
        return getClass().getSimpleName()
             + "(x=" + multishape.getX() + ", y=" + multishape.getY()
             + ", size=" + multishape.getWidth() + ", dir=" + getDirection()
             + ")";
    }



//\IP== INSTANCE PRIVATE AND AUXILIARY METHODS =================================



//##############################################################################
//\NT== NESTED DATA TYPES ======================================================
}
