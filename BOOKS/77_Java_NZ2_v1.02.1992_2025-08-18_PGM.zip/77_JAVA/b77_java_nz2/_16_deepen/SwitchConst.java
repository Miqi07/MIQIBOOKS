package b77_java_nz2._16_deepen;
// Příliš žluťoučký kůň úpěl ďábelské ó - PŘÍLIŠ ŽLUŤOUČKÝ KŮŇ ÚPĚL ĎÁBELSKÉ Ó
// J:/77_JAVA/b77_java_nz2/_16_deepen/SwitchConst.java

import java.util.Random;

/*******************************************************************************
 * Třída {@code SwitchConst} demonstruje použitelnost statických konstant
 * jako konstant vyhodnotitelných v době překladu (compile-time constant - CTC).
 */
public class SwitchConst
{
    static final int ctc = 2; //Po tomto přiřazení zůstavá CTC
//    static {
//        ctc = 2;    //Tímto přiřazením přestane být CTC
//    }

    public static void main(String[] args) {
        int i = new Random().nextInt(3);
        System.out.print(ctc + " - " + i + ": ");
        switch(i) {
            case ctc -> System.out.println("Shodné");
            default  -> System.out.println("NE NE NE");
        }
    }
}
