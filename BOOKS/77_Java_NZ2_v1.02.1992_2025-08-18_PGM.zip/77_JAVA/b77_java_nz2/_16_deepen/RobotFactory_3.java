package b77_java_nz2._16_deepen;
// Příliš žluťoučký kůň úpěl ďábelské ó - PŘÍLIŠ ŽLUŤOUČKÝ KŮŇ ÚPĚL ĎÁBELSKÉ Ó
// J:/77_JAVA/b77_java_nz2/_16_deepen/RobotFactory_3.java

import shapes77.util.NamedColor;
import b77_java_nz2.vehicle.IVehicle1_3;
import b77_java_nz2.vehicle.IVehicleFactory1_3;
import b77_java_nz2.vehicle.IVehicleTest_3;



/********************************************************************************
 * Instance třídy {@code RobotFactory_3} představují tovární objekty
 * schopné vytvořit vozidlo s požadovanými vlastnostmi
 * a testovací objekt, který prověří funkčnost vytvořeného vozidla.
 */
public  class       RobotFactory_3
        implements  IVehicleFactory1_3
{
//\CC== CLASS CONSTANTS (CONSTANT CLASS/STATIC ATTRIBUTES/FIELDS) ==============
//\CV== CLASS VARIABLES (VARIABLE CLASS/STATIC ATTRIBUTES/FIELDS) ==============



//##############################################################################
//\CI== CLASS (STATIC) INITIALIZER (CLASS CONSTRUCTOR) =========================
//\CF== CLASS (STATIC) FACTORY METHODS =========================================
//\CG== CLASS (STATIC) GETTERS AND SETTERS =====================================
//\CM== CLASS (STATIC) REMAINING NON-PRIVATE METHODS ===========================
//\CP== CLASS (STATIC) PRIVATE AND AUXILIARY METHODS ===========================



//##############################################################################
//\IC== INSTANCE CONSTANTS (CONSTANT INSTANCE ATTRIBUTES/FIELDS) ===============
//\IV== INSTANCE VARIABLES (VARIABLE INSTANCE ATTRIBUTES/FIELDS) ===============



//##############################################################################
//\II== INSTANCE INITIALIZERS (CONSTRUCTORS) ===================================
//\IA== INSTANCE ABSTRACT METHODS ==============================================
//\IG== INSTANCE GETTERS AND SETTERS ===========================================

    /***************************************************************************
     * Vrátí string s identifikací autora.
     *
     * @return String s identifikací autora
     */
    @Override
    public String author() {
        return "PECINOVSKÝ Rudolf";
    }



//\IM== INSTANCE REMAINING NON-PRIVATE METHODS =================================

    /***************************************************************************
     * Vytvoří vozidlo velikosti 100×100 umístěné na pozici [0;0]
     * a otočené na východ.
     *
     * @return Vozidlo otočené na východ
     */
//    @Override
    public IVehicle1_3 newVehicle1E(NamedColor color) {
        return new Robot1E_3(color);
    }

    /***************************************************************************
     * Vytvoří vozidlo velikosti 100×100 umístěné na pozici [0;0]
     * a otočené na sever.
     *
     * @return Vozidlo otočené na sever
     */
    @Override
    public IVehicle1_3 newVehicle1N(NamedColor color) {
        return new Robot1N_3(color);
    }

    /***************************************************************************
     * Vytvoří vozidlo velikosti 100×100 umístěné na pozici [0;0]
     * a otočené na západ.
     *
     * @return Vozidlo otočené na západ
     */
    @Override
    public IVehicle1_3 newVehicle1W(NamedColor color) {
        return new Robot1W_3(color);
    }

    /***************************************************************************
     * Vytvoří vozidlo velikosti 100×100 umístěné na pozici [0;0]
     * a otočené na jih.
     *
     * @return Vozidlo otočené na jih
     */
    @Override
    public IVehicle1_3 newVehicle1S(NamedColor color) {
        return new Robot1S_3(color);
    }

    /***************************************************************************
     * Vrátí test (instanci testovací třídy) prověřující vytvářená vozidla.
     *
     * @return Test prověřující vytvářená vozidla
     */
    @Override
    public IVehicleTest_3 newVehicleTest() {
        return new RobotTest_3();
    }



//\IP== INSTANCE PRIVATE AND AUXILIARY METHODS =================================



//##############################################################################
//\NT== NESTED DATA TYPES ======================================================
}
