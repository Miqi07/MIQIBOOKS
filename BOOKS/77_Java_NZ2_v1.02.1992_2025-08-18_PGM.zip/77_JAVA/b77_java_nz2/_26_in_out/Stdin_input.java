package b77_java_nz2._26_in_out;
// Příliš žluťoučký kůň úpěl ďábelské ó - PŘÍLIŠ ŽLUŤOUČKÝ KŮŇ ÚPĚL ĎÁBELSKÉ Ó
// J:/77_JAVA/b77_java_nz2/_26_files/Stdin_input.java
/***********************************************************************
** Demonstruje použití scanneru při načítání ze standardního vstupu.
***********************************************************************/
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Stdin_input {
    public static void sum_entered()
    {
        double sum = 0;
        List<Double> lst = new ArrayList<>();
        System.out.print("Zadejte čísla: ");
        var inp = new Scanner(System.in);
        while(inp.hasNextDouble())  {
            double val = inp.nextDouble();
            lst.add(val);
            sum += val;
        }
        inp.close();
        System.out.println("Hodnoty: " + lst
                       + "\nSoučet = " + sum);
    }
}



