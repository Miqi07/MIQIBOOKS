// Příliš žluťoučký kůň úpěl ďábelské ó - PŘÍLIŠ ŽLUŤOUČKÝ KŮŇ ÚPĚL ĎÁBELSKÉ Ó
// J:/77_JAVA/b77_java_nz2/_18_impl_inherit/package-info.java

/********************************************************************************
 * Balíček obsahuje doprovodné programy ke kapitole
 * <i>18  Dědění implementace</i>.
 */
package b77_java_nz2._18_impl_inherit;
