package b77_java_nz2.vehicle;
/* UTF-8 codepage: Příliš žluťoučký kůň úpěl ďábelské ó. ÷ × ¤ */

import shapes77.canvasmanager.CanvasManager;
import shapes77.util.IO;

/*******************************************************************************
 * Instance interfejsu {@code IVehicleTest_3} představují testy
 * prověřující vozidla implementující interfejs {@link IVehicle1_3}.
 */
public interface IVehicleTest_3
{
    /***************************************************************************
     * Vrátí instanci tovární třídy.
     *
     * @return Instance tovární třídy
     */
    public IVehicleFactory1_3 factory();

    /***************************************************************************
     * Vrátí přepravku (záznam) s instancemi vozidel tvořících přípravek.
     *
     * @return Přepravka s instancemi vozidel tvořících přípravek
     */
    public Vehicles_3 fixtureObjects();

    /***************************************************************************
     * Vrátí název aktuálně spuštěného testu.
     *
     * @return Název aktuálně spuštěného testu
     */
//    @Override
    public String testName();

    /***************************************************************************
     * Inicializace předcházející spuštění každého testu a připravující tzv.
     * testovací přípravek (test fixture), po jehož přípravě otevře dialogové
     * okno, v němž oznámí zhotovení přípravku spolu se jménem autora/autorky,
     * názvem testovací třídy a názvem spouštěného testu (testovací metody).
     * Přopravek vytvoří 4 instance vozidel implicitní velikosti 100
     * otočených do jednotlivých směrů a umístěných do rohů plátna tak,
     * aby při pojezdu vpřed objížděly plátno ve směru hodinových ručiček.
     */
    public void setUp();

    /***************************************************************************
     * Úklid po testu - tato metoda se spustí po vykonání každého testu.
     * Metoda nejprve otevře dialogové okno, oznámí ukončení testu,
     * přičemž oznámí názvem testovací třídy a ukončeného testu.
     * Na závěr vyčistí plátno.
     */
    public void tearDown();

    /***************************************************************************
     * S každým z vozidel popojede o 50 bodů vpřed prostřednictvím zavolání
     * jeho metody <b>{@link IVehicle1_3#forward(int)}</b>.
     */
    public void testForward();

    /***************************************************************************
     * Zmenší každé z vozidel na modul 50 tak,
     * aby vozidlo zůstalo nadále umístěné v příslušném rohu plátna.
     */
//    @Override
    public void testResizeToCorner();

    /***************************************************************************
     * Oznamuje vytvoření testovacího přípravku spolu se jménem autora
     * a názvem následně spuštěného testu. Je určena k zavolání
     * v posledním příkazu metody <b>{@link #setUp()}</b>.
     */
    default
    public void fixtureReady() {
        IO.inform(factory().author() + "\nPřípravek vytvořen");
    }

    /***************************************************************************
     * Metoda oznamující dokončení testu spolu se jménem autora
     * a názvem ukončeného testu. Je určena k zavolání
     * v posledním příkazu metody <b>{@link #tearDown()}</b>.
     */
    default
    public void testFinished() {
        IO.inform(factory().author() + "\nKonec testu");
        CanvasManager.getInstance().removeAll();
    }
}
