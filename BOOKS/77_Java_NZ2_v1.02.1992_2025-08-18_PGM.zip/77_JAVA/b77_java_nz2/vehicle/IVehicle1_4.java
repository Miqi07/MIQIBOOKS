package b77_java_nz2.vehicle;
/* Codepage UTF-8: Příliš žluťoučký kůň úpěl ďábelské ó. ÷ × ¤ */

import shapes77.canvasmanager.ICMPaintable;
import shapes77.canvasmanager.Multishape;
import shapes77.geom.Direction8;
import shapes77.geom.IModular;
import shapes77.util.NamedColor;

/*******************************************************************************
 * {@code IVehicle1_4} definuje společné rozhraní "jednosměrných" vozidel
 * definovaných ve 20. kapitole při výkladu návrhového vzoru <i>Stav</i>.
 */
public interface IVehicle1_4
{
    /***************************************************************************
     * Vrátí směr, do nějž je vozidlo právě natočeno.
     *
     * @return  Instance třídy {@code Direction8} definující
     *          směr, do nějž je vozidlo natočeno
     */
    public Direction8 direction();


    /***************************************************************************
     * Vrátí mnohotvar se součástmi vozidla.
     *
     * @return Multishape se součástmi vozidla
     */
//    @Override
    public Multishape multishape();

    /***************************************************************************
     * Přesune vozidlo o zadanou vzdálenost vpřed.
     *
     * @param distance Vzdálenost, o níž se má vozidlo přesunout
     */
    public void forward(int distance);

    /***************************************************************************
     * Vrátí stejně velké, umístěné a vybarvené vozidlo otočené
     * o 180°.
     *
     * @return Požadované vozidlo
     */
//    @Override
    public IVehicle1_4 turnedAbout();

    /***************************************************************************
     * Vrátí stejně velké, umístěné a vybarvené vozidlo otočené
     * o 90° vlevo.
     *
     * @return Požadované vozidlo
     */
//    @Override
    public IVehicle1_4 turnedLeft();

    /***************************************************************************
     * Vrátí stejně velké, umístěné a vybarvené vozidlo otočené
     * o 90° vpravo.
     *
     * @return Požadované vozidlo
     */
//    @Override
    public IVehicle1_4 turnedRight();
}
