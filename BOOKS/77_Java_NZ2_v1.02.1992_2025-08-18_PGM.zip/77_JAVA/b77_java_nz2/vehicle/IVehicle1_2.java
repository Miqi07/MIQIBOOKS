package b77_java_nz2.vehicle;
// Příliš žluťoučký kůň úpěl ďábelské ó - PŘÍLIŠ ŽLUŤOUČKÝ KŮŇ ÚPĚL ĎÁBELSKÉ Ó
// J:/77_JAVA/b77_java_nz2/vehicle/IVehicle1_2.java

import shapes77.canvasmanager.ICMPaintable;
import shapes77.geom.IModular;

/*******************************************************************************
 * Definuje společné rozhraní vozidel vytvářených v 15. kapitole
 * po přechodu na zobrazování prostřednictvím instance třídy
 * {@link shapes77.canvasmanager.CanvasManager}.
 */
public interface IVehicle1_2
         extends IModular, ICMPaintable
{
    /***************************************************************************
     * Přesune vozidlo o velikost jeho modulu vpřed.
     */
    public void forward();

    /***************************************************************************
     * Přesune vozidlo o zadanou vzdálenost vpřed.
     *
     * @param distance Vzdálenost, o níž se má vozidlo přesunout
     */
    public void forward(int distance);
}
