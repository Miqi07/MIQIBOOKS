package b77_java_nz2.vehicle;
/* Codepage UTF-8: Příliš žluťoučký kůň úpěl ďábelské ó. ÷ × ¤ */

import shapes77.canvasmanager.ICMPaintable;
import shapes77.geom.Direction8;
import shapes77.geom.IModular;
import shapes77.util.NamedColor;

/*******************************************************************************
 * {@code IVehicle_3} definuje společné rozhraní vozidel vytvářených
 * v 17. kapitole po zavedení tovární třídy.
 */
public interface IVehicle1_3
         extends IModular, ICMPaintable
{
    /***************************************************************************
     * Vrátí instanci tovární třídy.
     *
     * @return Instance tovární třídy
     */
    public IVehicleFactory1_3 factory();

    /***************************************************************************
     * Vrátí hlavní barvu vozidla.
     *
     * @return  Instance třídy {@link NamedColor} definující
     *          hlavní barvu vozidla
     */
    public NamedColor color();

    /***************************************************************************
     * Vrátí směr, do nějž je vozidlo právě natočeno.
     *
     * @return  Instance třídy {@code Direction8} definující
     *          směr, do nějž je vozidlo natočeno
     */
    public Direction8 getDirection();

    /***************************************************************************
     * Přesune vozidlo o velikost jeho modulu vpřed.
     */
    public void forward();

    /***************************************************************************
     * Přesune vozidlo o zadanou vzdálenost vpřed.
     *
     * @param distance Vzdálenost, o níž se má vozidlo přesunout
     */
    public void forward(int distance);

    /***************************************************************************
     * Vrací povinnou podobu textového podpisu instance vracenou
     * metodou {@code toString()}.
     *
     * @return Textový podpis instance
     */
    default
    public String signature() {
        return getClass().getSimpleName()
                + "(x="  +  getX()  +  ", y="  +  getY()
                + ", module="  +  getModule()
                + ", dir="     +  getDirection()
                + ")";
    }
}
