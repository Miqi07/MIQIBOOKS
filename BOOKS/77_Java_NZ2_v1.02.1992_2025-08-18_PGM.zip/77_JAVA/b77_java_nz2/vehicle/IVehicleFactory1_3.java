package b77_java_nz2.vehicle;
// Příliš žluťoučký kůň úpěl ďábelské ó - PŘÍLIŠ ŽLUŤOUČKÝ KŮŇ ÚPĚL ĎÁBELSKÉ Ó
// J:/77_JAVA/b77_java_nz2/vehicle/IVehicleFactory1_3.java

import shapes77.util.NamedColor;



/*******************************************************************************
 * Instance interfejsu {@code IVehicleFactory1_3} představují tovární objekty
 * schopné vytvořit vozidlo s požadovanými vlastnostmi
 * a testovací objekt, který prověří funkčnost vytvořeného vozidla.
 */
public interface IVehicleFactory1_3
{
    /***************************************************************************
     * Vrátí string s identifikací autora.
     *
     * @return String s identifikací autora
     */
    public String author();

    /***************************************************************************
     * Vytvoří vozidlo velikosti 100×100 umístěné na pozici [0;0]
     * a otočené na východ.
     *
     * @param color     Barva vozidla
     * @return Vozidlo otočené na východ
     */
    public IVehicle1_3 newVehicle1E(NamedColor color);

    /***************************************************************************
     * Vytvoří vozidlo velikosti 100×100 umístěné na pozici [0;0]
     * a otočené na sever.
     *
     * @param color     Barva vozidla
     * @return Vozidlo otočené na sever
     */
    public IVehicle1_3 newVehicle1N(NamedColor color);

    /***************************************************************************
     * Vytvoří vozidlo velikosti 100×100 umístěné na pozici [0;0]
     * a otočené na západ.
     *
     * @param color     Barva vozidla
     * @return Vozidlo otočené na západ
     */
    public IVehicle1_3 newVehicle1W(NamedColor color);

    /***************************************************************************
     * Vytvoří vozidlo velikosti 100×100 umístěné na pozici [0;0]
     * a otočené na jih.
     *
     * @param color     Barva vozidla
     * @return Vozidlo otočené na jih
     */
    public IVehicle1_3 newVehicle1S(NamedColor color);

    /***************************************************************************
     * Vrátí test (instanci testovací třídy) prověřující vytvářená vozidla.
     *
     * @return Test prověřující vytvářená vozidla
     */
    public IVehicleTest_3 newVehicleTest();
}
