package b77_java_nz2.vehicle;
// Příliš žluťoučký kůň úpěl ďábelské ó - PŘÍLIŠ ŽLUŤOUČKÝ KŮŇ ÚPĚL ĎÁBELSKÉ Ó
// J:/77_JAVA/b77_java_nz2/vehicle/IVehicle1_1.java

import shapes77.canvas_4.IModular;

/*******************************************************************************
 * Definuje společné rozhraní vozidel vytvářených ve 14. kapitole.
 */
public interface IVehicle1_1
         extends IModular
{
    /***************************************************************************
     * Přesune vozidlo o velikost jeho modulu vpřed.
     */
    public void forward();

    /***************************************************************************
     * Přesune vozidlo o zadanou vzdálenost vpřed.
     *
     * @param distance Vzdálenost, o níž se má vozidlo přesunout
     */
    public void forward(int distance);
}
