package b77_java_nz2.vehicle;

public record Vehicles_3 (
       IVehicle1_3 vehicleE,
       IVehicle1_3 vehicleS,
       IVehicle1_3 vehicleW,
       IVehicle1_3 vehicleN)
{
    private static final String LINE =
    "-------------------------------------------------------------------------";

    /***************************************************************************
     * Vrátí textový podpis přepravky sestávající z podpisů jednotlivých
     * vozidel, každého na samostatném řádku uvozeném směrem otočení.
     *
     * @return Textový podpis instance
     */
    @Override
    public String toString() {
        return LINE
             + "\nVýchod (vehicleE)=" + vehicleE.signature()
             + "\nJih    (vehicleS)=" + vehicleS.signature()
             + "\nZápad  (vehicleW)=" + vehicleW.signature()
             + "\nSever  (vehicleN)=" + vehicleN.signature()
             + "\n" + LINE;
    }
}
