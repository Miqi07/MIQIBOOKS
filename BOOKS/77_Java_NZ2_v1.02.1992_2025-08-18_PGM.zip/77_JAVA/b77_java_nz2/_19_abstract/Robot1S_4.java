package b77_java_nz2._19_abstract;
// Příliš žluťoučký kůň úpěl ďábelské ó - PŘÍLIŠ ŽLUŤOUČKÝ KŮŇ ÚPĚL ĎÁBELSKÉ Ó
// J:/77_JAVA/b77_java_nz2/_19_abstract/Robot1S_4.java

import shapes77.canvasmanager.Ellipse;
import shapes77.canvasmanager.Rectangle;
import shapes77.canvasmanager.Triangle;
import shapes77.geom.Direction8;
import shapes77.util.NamedColor;



/********************************************************************************
 * Instance třídy {@code Robot1S_4} reprezentují na jih otočená jednosměrná
 * vozidla, pracující jako jednotavové podobjekty čtyřrozěrných vozidel.
 * Oproti minulé verzi umožňují zadat hlavní barvu vytvářeného vozidla
 * a znají sdruženou tovární třídu.
 */
public   class Robot1S_4
       extends ARobot1_4
{
//\CC== CLASS CONSTANTS (CONSTANT CLASS/STATIC ATTRIBUTES/FIELDS) ==============
//\CV== CLASS VARIABLES (VARIABLE CLASS/STATIC ATTRIBUTES/FIELDS) ==============



//##############################################################################
//\CI== CLASS (STATIC) INITIALIZER (CLASS CONSTRUCTOR) =========================
//\CF== CLASS (STATIC) FACTORY METHODS =========================================
//\CG== CLASS (STATIC) GETTERS AND SETTERS =====================================
//\CM== CLASS (STATIC) REMAINING NON-PRIVATE METHODS ===========================
//\CP== CLASS (STATIC) PRIVATE AND AUXILIARY METHODS ===========================



//##############################################################################
//\IC== INSTANCE CONSTANTS (CONSTANT INSTANCE ATTRIBUTES/FIELDS) ===============
//\IV== INSTANCE VARIABLES (VARIABLE INSTANCE ATTRIBUTES/FIELDS) ===============



//##############################################################################
//\II== INSTANCE INITIALIZERS (CONSTRUCTORS) ===================================

    /***************************************************************************
     * Vytvoří v implicitní pozici [0; 0] vozidlo implicitní velikosti 100
     * a implicitní barvy otočené na východ.
     */
    public Robot1S_4(NamedColor color)
    {
        super(color);
        Rectangle frame   = new Rectangle( 0,  0,100,100, NamedColor.NO);
        Rectangle body    = new Rectangle(20, 00, 60, 70, color);
        Ellipse   nose    = new Ellipse  (20, 40, 60, 60, color);
        Rectangle arrBody = new Rectangle(30, 00, 40, 70, color.inverse());
        Triangle  arrHead = new Triangle (20, 70, 60, 30, color.inverse(),
                                                          Direction8.SOUTH);
        multishape.addShapes(frame, body, nose, arrBody, arrHead);
        multishape.creationDone();
    }



//\IA== INSTANCE ABSTRACT METHODS ==============================================
//\IG== INSTANCE GETTERS AND SETTERS ===========================================

    /***************************************************************************
     * Vrátí směr, do nějž je vozidlo právě natočeno.
     *
     * @return  Instance třídy {@link Direction8} definující
     *          směr, do nějž je vozidlo právě natočeno
     */
    @Override
    public Direction8 direction() {
        return Direction8.SOUTH;
    }


//\IM== INSTANCE REMAINING NON-PRIVATE METHODS =================================

    /***************************************************************************
     * Přesune vozidlo o zadanou vzdálenost vpřed.
     *
     * @param distance Vzdálenost, o níž se má vozidlo přesunout
     */
    @Override
    public void forward(int distance) {
        multishape.setPosition(multishape.getX(),
                               multishape.getY()+distance);
    }

    /***************************************************************************
     * Vrátí stejně vybarvené jednosměrné vozidlo otočené o 180°.
     *
     * @return Požadované vozidlo
     */
    @Override
    public ARobot1_4 turnedAbout()
    {
        return newRobot1(color, Direction8.NORTH);
    }

    /***************************************************************************
     * Vrátí stejně vybarvené jednosměrné vozidlo otočené o 90° vlevo.
     *
     * @return Požadované vozidlo
     */
    @Override
    public ARobot1_4 turnedLeft()
    {
        return newRobot1(color, Direction8.EAST);
    }

    /***************************************************************************
     * Vrátí stejně vybarvené jednosměrné vozidlo otočené o 90° vpravo.
     *
     * @return Požadované vozidlo
     */
//    @Override
    public ARobot1_4 turnedRight()
    {
        return newRobot1(color, Direction8.WEST);
    }



//\IP== INSTANCE PRIVATE AND AUXILIARY METHODS =================================



//##############################################################################
//\NT== NESTED DATA TYPES ======================================================
}
