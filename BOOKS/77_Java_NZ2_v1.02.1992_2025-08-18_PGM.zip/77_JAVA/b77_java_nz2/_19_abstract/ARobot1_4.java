package b77_java_nz2._19_abstract;
// Příliš žluťoučký kůň úpěl ďábelské ó - PŘÍLIŠ ŽLUŤOUČKÝ KŮŇ ÚPĚL ĎÁBELSKÉ Ó
// J:/77_JAVA/b77_java_nz2/_19_abstract/ARobot1_4.java

import shapes77.canvasmanager.Multishape;
import shapes77.geom.Direction8;
import shapes77.util.NamedColor;
import b77_java_nz2.vehicle.IVehicle1_4;


/********************************************************************************
 * Třída {@code ARobot1_4} je společným rodičem jednosměrných robotů
 * tvořících jednostavové části otočného vozidla.
 */
abstract public class ARobot1_4
{
//\CC== CLASS CONSTANTS (CONSTANT CLASS/STATIC ATTRIBUTES/FIELDS) ==============
//\CV== CLASS VARIABLES (VARIABLE CLASS/STATIC ATTRIBUTES/FIELDS) ==============



//##############################################################################
//\CI== CLASS (STATIC) INITIALIZER (CLASS CONSTRUCTOR) =========================
//\CF== CLASS (STATIC) FACTORY METHODS =========================================

    /***************************************************************************
     * Vytvoří v implicitní pozici [0; 0] vozidlo implicitní velikosti 100
     * a zadané barvy otočené zadaným směrem.
     *
     * @param color Hlavní barva vozidla
     */
    static
    public ARobot1_4 newRobot1(NamedColor color, Direction8 dir)
    {
        ARobot1_4 result = switch(dir) {
            case EAST  -> new Robot1E_4(color);
            case NORTH -> new Robot1N_4(color);
            case WEST  -> new Robot1W_4(color);
            case SOUTH -> new Robot1S_4(color);
            default    -> throw new IllegalArgumentException(
                                "\nNepovolený směr: " + dir);
        };
        return result;
    }



//\CG== CLASS (STATIC) GETTERS AND SETTERS =====================================
//\CM== OTHER NON-PRIVATE CLASS (STATIC) METHODS ===============================
//\CP== PRIVATE AND AUXILIARY CLASS (STATIC) METHODS ===========================



//##############################################################################
//\IC== INSTANCE CONSTANTS (CONSTANT INSTANCE ATTRIBUTES/FIELDS) ===============

    /** Hlavní barva vozidla. */
    protected final NamedColor color;

    /** Mnohotvar uchovávající grafickou podobu vytvořeného vozidla. */
    protected final Multishape multishape;



//\IV== INSTANCE VARIABLES (VARIABLE INSTANCE ATTRIBUTES/FIELDS) ===============



//##############################################################################
//\II== INSTANCE INITIALIZERS (CONSTRUCTORS) ===================================

    /***************************************************************************
     * Vytvoří v implicitní pozici [0; 0] vozidlo implicitní velikosti 100
     * a zadané barvy otočené na východ.
     *
     * @param color Hlavní barva vozidla
     */
    public ARobot1_4(NamedColor color) {
        this.color      = color;
        this.multishape = new Multishape();
    }



//\IA== ABSTRACT METHODS =======================================================

    /***************************************************************************
     * Vrátí směr, do nějž je vozidlo právě natočeno.
     *
     * @return  Instance třídy {@link Direction8} definující
     *          směr, do nějž je vozidlo právě natočeno
     */
    abstract public Direction8 direction();

    /***************************************************************************
     * Přesune vozidlo o zadanou vzdálenost vpřed.
     *
     * @param distance Vzdálenost, o níž se má vozidlo přesunout
     */
    abstract public void forward(int distance);

    /***************************************************************************
     * Vrátí stejně velké, umístěné a vybarvené vozidlo otočené
     * o 180°.
     *
     * @return Požadované vozidlo
     */
//    @Override
    abstract public ARobot1_4 turnedAbout();

    /***************************************************************************
     * Vrátí stejně velké, umístěné a vybarvené vozidlo otočené
     * o 90° vlevo.
     *
     * @return Požadované vozidlo
     */
//    @Override
    abstract public ARobot1_4 turnedLeft();

    /***************************************************************************
     * Vrátí stejně velké, umístěné a vybarvené vozidlo otočené
     * o 90° vpravo.
     *
     * @return Požadované vozidlo
     */
//    @Override
    abstract public ARobot1_4 turnedRight();



//\IG== INSTANCE GETTERS AND SETTERS ===========================================

    /***************************************************************************
     * Vrátí směr, do nějž je vozidlo právě natočeno.
     *
     * @return  Instance třídy {@link Direction8} definující
     *          směr, do nějž je vozidlo právě natočeno
     */
    public Multishape multishape() {
        return multishape;
    }



//\IM== OTHER NON-PRIVATE INSTANCE METHODS =====================================
//\IP== PRIVATE AND AUXILIARY INSTANCE METHODS =================================



//##############################################################################
//\NT== NESTED DATA TYPES ======================================================
}
