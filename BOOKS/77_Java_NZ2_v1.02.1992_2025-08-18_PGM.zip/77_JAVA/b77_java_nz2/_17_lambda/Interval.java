package b77_java_nz2._17_lambda;
// Příliš žluťoučký kůň úpěl ďábelské ó - PŘÍLIŠ ŽLUŤOUČKÝ KŮŇ ÚPĚL ĎÁBELSKÉ Ó
// J:/77_JAVA/b77_java_nz2/_17_lambda/Interval.java


/*******************************************************************************
 * Instance třídy {@code Interval} reprezentují uzavřený interval hodnot.
 */
public record Interval <T extends Comparable<T>> (T low, T high)
{
    /***************************************************************************
     * Vytvoří interval se zadanou spodní a horní mezí.
     *
     * @param low   Spodní mez vytvářeného intervalu
     * @param high  Horní mez vytvářeného intervalu
     */
    public Interval(T low, T high) {
        this.low  = low;
        this.high = high;
    }

    /***************************************************************************
     * Vrátí informaci o tom, patří-li zadaný objekt do daného intervalu.
     *
     * @param object Prověřovaný objekt
     * @return  Patří-li, vrátí {@code true}, jinak vrátí {@code false}
     */
    public boolean contains(T object) {
        return 0 >= low .compareTo(object)  &&
               0 <= high.compareTo(object);
    }
}
