package b77_java_nz2._20_special_types;
// Příliš žluťoučký kůň úpěl ďábelské ó - PŘÍLIŠ ŽLUŤOUČKÝ KŮŇ ÚPĚL ĎÁBELSKÉ Ó
// J:/77_JAVA/b77_java_nz2/_20_special_types/Direction.java



/***********************************************************************
 * Výčtový typ, jehož instance definují čtyři základní světové strany,
 * znají velikost vodorovného a svislého posunu při natočení do daného
 * směru a znají směr po provedení základních tří obratů.
 */
public enum Direction
{
    EAST ( 1, 0),
    NORTH( 0,-1),
    WEST (-1, 0),
    SOUTH( 0, 1);

    private final int dx;
    private final int dy;

    /*******************************************************************
     * Vytvoří instanci reprezentující světovou stranu.
     *
     * @param dx  Vodorovný posun při natočení do daného směru
     * @param dy  Svislý    posun při natočení do daného směru
     */
    private Direction(int dx, int dy) {
        this.dx = dx;
        this.dy = dy;
    }

    /*******************************************************************
     * Vrátí přírůstek vodorovné souřadnice při pohybu v daném směru.
     *
     * @return Přírůstek vodorovné souřadnice při pohybu v daném směru
     */
    public int dx() {
        return dx;
    }

    /*******************************************************************
     * Vrátí přírůstek svislé souřadnice při pohybu v daném směru.
     *
     * @return Přírůstek svislé souřadnice při pohybu v daném směru
     */
    public int dy() {
        return dy;
    }

    /*******************************************************************
     * Vrátí směr otočený o 90° vlevo.
     *
     * @return Směr otočený o 90° vlevo
     */
    Direction turnLeft() {
        return values()[(ordinal()+1) & 3];
    }

    /*******************************************************************
     * Vrátí směr otočený o 90° vpravo.
     *
     * @return Směr otočený o 90° vpravo
     */
    Direction turnRight() {
        return values()[(ordinal()+3) & 3];
    }

    /*******************************************************************
     * Vrátí směr otočený o 180°.
     *
     * @return Směr otočený o 180°
     */
    Direction turnAbout() {
        return values()[(ordinal()+2) & 3];
    }
}


