// Příliš žluťoučký kůň úpěl ďábelské ó - PŘÍLIŠ ŽLUŤOUČKÝ KŮŇ ÚPĚL ĎÁBELSKÉ Ó
// J:/77_JAVA/b77_java_nz2/_21_exceptions/package-info.java

/********************************************************************************
 * Balíček obsahuje doprovodné programy ke kapitole
 * <i>21  Výjimky</i>.
 */
package b77_java_nz2._21_exceptions;
