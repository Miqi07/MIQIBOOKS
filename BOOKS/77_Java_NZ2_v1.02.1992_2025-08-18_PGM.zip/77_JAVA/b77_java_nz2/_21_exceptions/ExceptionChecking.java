package b77_java_nz2._21_exceptions;
// Příliš žluťoučký kůň úpěl ďábelské ó - PŘÍLIŠ ŽLUŤOUČKÝ KŮŇ ÚPĚL ĎÁBELSKÉ Ó
// J:/77_JAVA/b77_java_nz2/_21_exceptions/ExceptionChecking.java



/********************************************************************************
 * Knihovní třída {@code ExceptionChecking} obsahuje metody demonstrující
 * práci s kontrolovanými (checked) a nekontrolovanými (unchecked) výjimkami.
 */
public class ExceptionChecking
{
//== CONSTANT CLASS ATTRIBUTES =================================================
//== VARIABLE CLASS ATTRIBUTES =================================================



//##############################################################################
//== STATIC INITIALIZER (CLASS CONSTRUCTOR) ====================================
//== CLASS GETTERS AND SETTERS =================================================
//== OTHER NON-PRIVATE CLASS METHODS ===========================================

    /***************************************************************************
     * Volá metody vyhazující kontrolované i nekontrolované výjimky
     * a demonstruje rozdílný přístup překladače k nutnosti jejich ošetření.
     */
    public static void callThrowingMtd()
//           throws CheckedException
    {
        throwsUnchecked();
//        throwsChecked();
        try {
            throwsChecked();
        }catch(CheckedException e) {
            System.out.println("Ošetření kontrolované výjimky: " + e);
        }
    }


    /***************************************************************************
     * Demonstruje převedení nekontrolované výjimky na kontrolovanou.
     */
    public static void conversion()
    {
        try {
            throwsChecked();
        }catch(CheckedException e) {
            throw new UncheckedException("Nečekaně vyhozená výjimka", e);
        }
    }


    /***************************************************************************
     * Metoda demonstrující způsob zobrazení informace
     * o převodu jedné výjimky na jinou.
     *
     * @param level Kolikrát se ještě budeme rekurzivně zanořovat
     */
    public static void recursionCE(int level) {
        System.err.println("+++++ Příchod na hladinu "  + level);
        try {
            int breaker = 1 / level;
            recursionCE(level - 1);
        }catch(RuntimeException rex) {
            System.err.println("V hladině " + level + " přišla " + rex);
            rex.printStackTrace();
            System.err.println("========================================");
            throw new RuntimeException("Hladina " + level, rex);
        }
        System.err.println("----- Konec akce v hladině " + level);
    }



//== PRIVATE AND AUXILIARY CLASS METHODS =======================================

    /***************************************************************************
     * Metoda vyhazující kontrolovanou výjimku.
     *
     * @throws CheckedException Popis vyhazované výjimky
     */
    public static void throwsChecked()
           throws CheckedException
    {
        throw new CheckedException("Kontrolovaná výjimka");
    }


    /***************************************************************************
     * Metoda vyhazující nekontrolovanou výjimku.
     *
     * @throws UncheckedException Popis vyhazované výjimky
     */
    public static void throwsUnchecked()
           throws UncheckedException
    {
        throw new UncheckedException("Nekontrolovaná výjimka");
    }



//##############################################################################
//== CONSTANT INSTANCE ATTRIBUTES ==============================================
//== VARIABLE INSTANCE ATTRIBUTES ==============================================



//##############################################################################
//== CONSTRUCTORS AND FACTORY METHODS ==========================================

    /** Soukromý konstruktor bránící vytvoření instance. */
    private ExceptionChecking() {}



//== ABSTRACT METHODS ==========================================================
//== INSTANCE GETTERS AND SETTERS ==============================================
//== OTHER NON-PRIVATE INSTANCE METHODS ========================================
//== PRIVATE AND AUXILIARY INSTANCE METHODS ====================================



//##############################################################################
//== NESTED DATA TYPES =========================================================



//##############################################################################
//== TESTING CLASSES AND METHODS ===============================================

    /***************************************************************************
     * Hlavní metoda sloužící k rychlému otestování dané třídy.
     *
     * @param args Parametry příkazového řádku - nepoužívané.
     */
    public static void main(String[] args)
    {
        callThrowingMtd();
        conversion();
        recursionCE(3);

        System.exit(0);
    }

}
