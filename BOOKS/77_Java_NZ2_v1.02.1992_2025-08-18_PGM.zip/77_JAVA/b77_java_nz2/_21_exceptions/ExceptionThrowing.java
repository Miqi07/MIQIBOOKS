package b77_java_nz2._21_exceptions;
// Příliš žluťoučký kůň úpěl ďábelské ó - PŘÍLIŠ ŽLUŤOUČKÝ KŮŇ ÚPĚL ĎÁBELSKÉ Ó
// J:/77_JAVA/b77_java_nz2/_21_exceptions/ExceptionThrowing.java



/********************************************************************************
 * Knihovní třída {@code ExceptionThrowing} obsahuje metody
 * sloužící k demonstraci činností spojených s vyhazováním výjimek.
 */
public class ExceptionThrowing
{
    /***************************************************************************
     * Metoda volá metodu volající metodu vyhazující výjimku.
     */
    public static void call()
    {
        System.out.println("Budu volat metodu vyhazující výjimku");
        throw2();
    }


    /***************************************************************************
     * Metoda volá metodu vyhazující výjimku.
     */
    public static void throw2()
    {
        System.out.println("Tahle to ještě není, až teď");
        throwing();
    }


    /***************************************************************************
     * Metoda demonstruje vyhození výjimky.
     */
    public static void throwing()
    {
        throw new RuntimeException("\nCvičně vyhazovaná výjimka");
    }

    /***************************************************************************
     * Metoda demonstruje možnost vytvořit výjimku na jiném místě,
     * než kde bude vyhozena.
     */
    public static void cleanUpFirst()
    {
        System.err.println("Obstarávám prostředky");
        System.err.println("Začínám vykonávat požadovanou operaci");
        RuntimeException rex = new RuntimeException(
                "\nOperace zhavarovaly protože ...");
        System.err.println("Výjimka je vytvořena - bude se vyhazovat");
        throw rex;
    }


    /***************************************************************************
     * Metoda demonstruje nedosažitelnost kódu za vyhozením výjimky.
     */
    public static void unreachable() {
        System.err.println("Před vyhozením výjimky");
        throw new RuntimeException("\nZa mnou už se nic neudělá");
//        System.err.println("Po vyhození výjimky");
    }


    /***************************************************************************
     * Demonstrace použití metod výjimek.
     */
    public static void exceptionMethods() {
        RuntimeException exception = new RuntimeException("Popis příčiny");
        System.out.println("Zpráva:   " + exception.getMessage() +
                         "\ntoString: " + exception +
                         "\nZásobník:");
        exception.printStackTrace(System.out);
        System.err.println("===== Začátek");
        exception.printStackTrace();
        System.err.println("===== Konec");
    }



//##############################################################################
//== CONSTRUCTORS AND FACTORY METHODS ==========================================

    /** Soukromý konstruktor bránící vytvoření instance. */
    private ExceptionThrowing() {}



//##############################################################################
//== TESTING CLASSES AND METHODS ===============================================

    /***************************************************************************
     * Hlavní metoda sloužící k rychlému otestování dané třídy.
     *
     * @param args Parametry příkazového řádku - nepoužívané.
     */
    public static void main(String[] args)
    {
//        throwing();
//        cleanUpFirst();
//        unreachable();
        exceptionMethods();

        System.exit(0);
    }

}
