package b77_java_nz2._21_exceptions;
// Příliš žluťoučký kůň úpěl ďábelské ó - PŘÍLIŠ ŽLUŤOUČKÝ KŮŇ ÚPĚL ĎÁBELSKÉ Ó
// J:/77_JAVA/b77_java_nz2/_21_exceptions/CheckedException.java



/********************************************************************************
 * Instance třídy {@code CheckedException} představují kontrolované výjimky.
 */
@SuppressWarnings("serial")
public class CheckedException extends Exception
{
//== CONSTANT CLASS ATTRIBUTES =================================================
//== VARIABLE CLASS ATTRIBUTES =================================================



//##############################################################################
//== STATIC INITIALIZER (CLASS CONSTRUCTOR) ====================================
//== CLASS GETTERS AND SETTERS =================================================
//== OTHER NON-PRIVATE CLASS METHODS ===========================================
//== PRIVATE AND AUXILIARY CLASS METHODS =======================================



//##############################################################################
//== CONSTANT INSTANCE ATTRIBUTES ==============================================
//== VARIABLE INSTANCE ATTRIBUTES ==============================================



//##############################################################################
//== CONSTRUCTORS AND FACTORY METHODS ==========================================

    /***************************************************************************
     * Constructs a new exception with null as its detail message.
     * The cause is not initialized, and may subsequently be initialized
     * by a call to {@link #initCause(java.lang.Throwable)}.
     */
    public CheckedException()
    {
    }


    /***************************************************************************
     * Constructs a new exception with the specified detail message.
     * The cause is not initialized, and may subsequently be initialized
     * by a call to {@link #initCause(java.lang.Throwable)}.
     *
     * @param message The detail message (which is saved for later retrieval
                      by the {@link Throwable#getMessage()} method).
     */
    public CheckedException(String message)
    {
        super(message);
    }


    /***************************************************************************
     * Constructs a new exception with the specified cause and a detail
     * message of <tt>(cause==null ? null : cause.toString())</tt> (which
     * typically contains the class and detail message of <tt>cause</tt>).
     * This constructor is useful for exceptions that are little more than
     * wrappers for other throwables (for example,
     * {@link java.security.PrivilegedActionException}).
     *
     * @param  cause The cause (which is saved for later retrieval by the
     *               {@link #getCause()} method).  (A <tt>null</tt> value is
     *               permitted, and indicates that the cause is nonexistent
     *               or unknown.)
     */
    public CheckedException(Throwable cause)
    {
        super(cause);
    }


    /***************************************************************************
     * Constructs a new exception with the specified detail message and
     * cause.  <p>Note that the detail message associated with
     * {@code cause} is <i>not</i> automatically incorporated in
     * this exception's detail message.
     *
     * @param  message The detail message (which is saved for later retrieval
     *                 by the {@link #getMessage()} method).
     * @param  cause   The cause (which is saved for later retrieval by the
     *                 {@link #getCause()} method).  (A <tt>null</tt> value is
     *                 permitted, and indicates that the cause is nonexistent
     *                 or unknown.)
     */
    public CheckedException(String message, Throwable cause)
    {
        super(message, cause);
    }



//== ABSTRACT METHODS ==========================================================
//== INSTANCE GETTERS AND SETTERS ==============================================
//== OTHER NON-PRIVATE INSTANCE METHODS ========================================
//== PRIVATE AND AUXILIARY INSTANCE METHODS ====================================



//##############################################################################
//== NESTED DATA TYPES =========================================================
}
