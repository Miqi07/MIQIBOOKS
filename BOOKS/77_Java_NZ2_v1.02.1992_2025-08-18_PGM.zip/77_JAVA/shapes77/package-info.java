// Příliš žluťoučký kůň úpěl ďábelské ó - PŘÍLIŠ ŽLUŤOUČKÝ KŮŇ ÚPĚL ĎÁBELSKÉ Ó
// J:/77_JAVA/shapes77/package-info.java

/*******************************************************************************
 * Balíček {@code eu.pedu.lib} obsahuje datové typy knihovny
 * pro podporu výuky programování v Javě.
 */
package shapes77;
