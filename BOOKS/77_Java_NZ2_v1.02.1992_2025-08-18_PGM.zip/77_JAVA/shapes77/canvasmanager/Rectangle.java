package shapes77.canvasmanager;
// Příliš žluťoučký kůň úpěl ďábelské ó - PŘÍLIŠ ŽLUŤOUČKÝ KŮŇ ÚPĚL ĎÁBELSKÉ Ó

import shapes77.geom.AShape;
import shapes77.geom.Area;
import shapes77.geom.Position;
import shapes77.geom.Size;
import shapes77.util.IColorable;
import shapes77.util.NamedColor;



/*******************************************************************************
 * Instance třídy {@code Rectangle} představují obdélníky
 * určené pro práci na plátně spravovaném správcem plátna &ndash;.
 * instancí třídy {@link CanvasManager}.
 * Tyto obdélníky jsou definované svojí pozicí, rozměrem a barvou.
 */
public class Rectangle
     extends AShape
  implements ICMShape, IColorable
{
//\CC== CLASS CONSTANTS (CONSTANT CLASS/STATIC ATTRIBUTES/FIELDS) ==============

    /** Počáteční barva nakreslené instance v případě,
     *  kdy uživatel žádnou požadovanou barvu nezadá -
     *  pro obdélník {@link NamedColor#RED}. */
    public static final NamedColor DEFAULT_COLOR = NamedColor.RED;



//\CV== CLASS VARIABLES (VARIABLE CLASS/STATIC ATTRIBUTES/FIELDS) ==============



//##############################################################################
//\CI== CLASS (STATIC) INITIALIZER (CLASS CONSTRUCTOR) =========================
//\CF== CLASS (STATIC) FACTORY METHODS =========================================
//\CG== CLASS (STATIC) GETTERS AND SETTERS =====================================
//\CM== CLASS (STATIC) REMAINING NON-PRIVATE METHODS ===========================
//\CP== CLASS (STATIC) PRIVATE AND AUXILIARY METHODS ===========================



//##############################################################################
//\IC== INSTANCE CONSTANTS (CONSTANT INSTANCE ATTRIBUTES/FIELDS) ===============
//\IV== INSTANCE VARIABLES (VARIABLE INSTANCE ATTRIBUTES/FIELDS) ===============

    /** Barva instance. */
    private NamedColor color;



//##############################################################################
//\II== INSTANCE INITIALIZERS (CONSTRUCTORS) ===================================

    /***************************************************************************
     * Připraví novou instanci s implicitním umístěním, rozměry a barvou.
     * Instance bude umístěna v levém horním rohu plátna
     * a bude mít implicitní barvu,
     * výšku rovnu kroku a šířku dvojnásobku kroku (tj. implicitně 50x100 bodů).
     */
    public Rectangle()
    {
        this(0, 0, 2*CM.getStep(), CM.getStep());
    }


    /***************************************************************************
     * Připraví novou instanci se zadanou pozicí a rozměry
     * a implicitní barvou.
     * Pozice instance je přitom definována jako pozice
     * jejího levého horního rohu.
     * &nbsp;
     *
     * @param x       Vodorovná (x-ová) souřadnice instance,
     *                x=0 má levý okraj plátna, souřadnice roste doprava
     * @param y       Svislá (y-ová) souřadnice instance,
     *                y=0 má horní okraj plátna, souřadnice roste dolů
     * @param width   Šířka vytvářené instance, šířka &gt;= 0
     * @param height  Výška vytvářené instance, výška &gt;= 0
     */
    public Rectangle(int x, int y, int width, int height)
    {
        this(x, y, width, height, DEFAULT_COLOR);
    }


    /***************************************************************************
     * Připraví novou instanci se zadanou pozicí, rozměry a barvou.
     * Pozice instance je přitom definována jako pozice
     * jejího levého horního rohu.
     * &nbsp;
     *
     * @param x       Vodorovná (x-ová) souřadnice instance,
     *                x=0 má levý okraj plátna, souřadnice roste doprava
     * @param y       Svislá (y-ová) souřadnice instance,
     *                y=0 má horní okraj plátna, souřadnice roste dolů
     * @param width   Šířka vytvářené instance,  šířka &gt; 0
     * @param height  Výška vytvářené instance,  výška &gt; 0
     * @param color   Barva vytvářené instance
     */
    public Rectangle(int x, int y, int width, int height, NamedColor color)
    {
        super(x, y, width, height);
        this.color = color;
    }


    /***************************************************************************
     * Připraví novou instanci se zadanými rozměry, polohou a barvou.
     * Pozice instance je přitom definována jako pozice
     * jejího levého horního rohu.
     * &nbsp;
     *
     * @param position  Pozice vytvářené instance
     * @param size      Rozměr vytvářené instance
     * @param color     Barva vytvářené instance
     */
    public Rectangle(Position position, Size size, NamedColor color)
    {
        this(position.x(), position.y(), size.width(), size.height(), color);
    }


    /***************************************************************************
     * Připraví novou instanci vyplňující zadanou oblast
     * a mající zadanou barvu.
     * Pozice instance je přitom definována jako pozice
     * jejího levého horního rohu.
     * &nbsp;.
     *
     * @param area  Oblast definující pozici a rozměr vytvářené instance
     * @param color Barva vytvářené instance
     */
    public Rectangle(Area area, NamedColor color)
    {
        this(area.x(), area.y(), area.width(), area.height(), color);
    }


    /***************************************************************************
     * Připraví novou instanci vyplňující zadanou oblast.
     *
     * @param area  Oblast definující pozici a rozměr vytvářené instance
     */
    public Rectangle(Area area)
    {
        this(area.x(), area.y(), area.width(), area.height());
    }



//\IA== INSTANCE ABSTRACT METHODS ==============================================
//\IG== INSTANCE GETTERS AND SETTERS ===========================================

    /***************************************************************************
     * Vrátí aktuální barvu instance.
     *
     * @return Instance třídy {@link NamedColor} definující
     *         aktuálně nastavenou barvu
     */
    public final NamedColor getColor()
    {
        return color;
    }


    /***************************************************************************
     * Nastaví novou barvu instance.
     *
     * @param color  Požadovaná nová barva
     */
    public final void setColor(NamedColor color)
    {
        this.color = color;
        CM.repaint();
    }


    /***************************************************************************
     * Přemístí instanci na zadanou pozici.
     * Pozice instance je přitom definována jako pozice
     * jejího levého horního rohu.
     *
     * @param x  Nově nastavovaná vodorovná (x-ová) souřadnice instance,
     *           x=0 má levý okraj plátna, souřadnice roste doprava
     * @param y  Nově nastavovaná svislá (y-ová) souřadnice instance,
     *           y=0 má horní okraj plátna, souřadnice roste dolů
     */
    @Override
    public void setPosition(int x, int y)
    {
        CM.changeTogether(() -> super.setPosition(x, y));
    }


    /***************************************************************************
     * Nastaví nové rozměry instance.
     * Rozměry instance jsou přitom definovány jako rozměry
     * opsaného obdélníku.
     * Nastavované rozměry musí být nezáporné,
     * místo nulového rozměru se nastaví rozměr rovný jedné.
     *
     * @param width    Nově nastavovaná šířka; šířka &gt;= 0
     * @param height   Nově nastavovaná výška; výška &gt;= 0
     */
    @Override
    public void setSize(int width, int height)
    {
        CM.changeTogether(() -> super.setSize(width, height));
    }



//\IM== INSTANCE REMAINING NON-PRIVATE METHODS =================================

    /***************************************************************************
     * Vrátí kopii dané instance,
     * tj. stejně velkou a stejně umístěnou instanci stejné barvy.
     *
     * @return Požadovaná kopie
     */
    @Override
    public Rectangle copy()
    {
        return new Rectangle(getX(), getY(), getWidth(), getHeight(), color);
    }


    /***************************************************************************
     * Prostřednictvím dodaného kreslítka vykreslí obraz své instance.
     *
     * @param painter Kreslítko schopné kreslit na plátno ovládané správcem
     */
    @Override
    public void paint(Painter painter)
    {
        painter.fillRectangle(getX(), getY(), getWidth(), getHeight(), color);
    }


    /***************************************************************************
     * Vrací charakteristiky vkládané do podpisu dané instance.
     *
     * @return String s vkládanými charakteristikami
     */
    @Override
    public String forToString()
    {
        return super.forToString() + ", color=" + color;
    }



//\IP== INSTANCE PRIVATE AND AUXILIARY METHODS =================================



//##############################################################################
//\NT== NESTED DATA TYPES ======================================================
}
