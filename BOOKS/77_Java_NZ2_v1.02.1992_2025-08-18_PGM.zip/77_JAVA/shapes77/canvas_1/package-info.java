// Příliš žluťoučký kůň úpěl ďábelské ó - PŘÍLIŠ ŽLUŤOUČKÝ KŮŇ ÚPĚL ĎÁBELSKÉ Ó
// J:/77_JAVA/shapes77/canvas_1/package-info.java

/*******************************************************************************
 * Balíček obsahuje základní grafické třídy používané v úvodních lekcích
 * vstupních kurzů programování před tím, než jsou vysvětleny základní
 * návrhové vzory a je představen správce plátna s jeho dokonalejším
 * řešením grafiky založeném na použití vzorů <i>Prostředník</i>
 * a <i>Pozorovatel</i>.
 */
package shapes77.canvas_1;
