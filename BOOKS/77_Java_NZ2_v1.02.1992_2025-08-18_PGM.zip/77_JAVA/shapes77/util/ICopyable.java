package shapes77.util;
// Příliš žluťoučký kůň úpěl ďábelské ó - PŘÍLIŠ ŽLUŤOUČKÝ KŮŇ ÚPĚL ĎÁBELSKÉ Ó



/*******************************************************************************
 * Instance interfejsu {@code Interface} dokáží
 * vytvořit svoji hlubokou kopii.
 */
public interface ICopyable
{
//\CC== CLASS (STATIC) CONSTANTS ===============================================
//\CM== CLASS (STATIC) METHODS =================================================



//##############################################################################
//\AG== ABSTRACT GETTERS AND SETTERS ===========================================
//\AM== REMAINING ABSTRACT METHODS =============================================

    /***************************************************************************
     * Vrátí svoji hlubokou kopii.
     *
     * @return Hluboká kopie daného objektu
     */
//     @Override
    public ICopyable copy();



//\DG== DEFAULT GETTERS AND SETTERS ============================================
//\DM== REMAINING DEFAULT METHODS ==============================================



//##############################################################################
//\NT== NESTED DATA TYPES ======================================================
}
