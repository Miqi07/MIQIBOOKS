package shapes77.util;
// Příliš žluťoučký kůň úpěl ďábelské ó - PŘÍLIŠ ŽLUŤOUČKÝ KŮŇ ÚPĚL ĎÁBELSKÉ Ó



/*******************************************************************************
 * Instance rozhraní {@code IListener} představují posluchače
 * očekávající nějakou událost.
 *
 * @param <Informant> Typ objektu poskytujícího informace o události,
 *                    na kterou posluchač čeká
 */
public interface IListener<Informant>
{
//== STATIC CONSTANTS ==========================================================
//== STATIC METHODS ============================================================



//##############################################################################
//== ABSTRACT GETTERS AND SETTERS ==============================================
//== OTHER ABSTRACT METHODS ====================================================

    /***************************************************************************
     * Hlášeni o výskytu očekávané události.
     *
     * @param informant Objekt, který je schopen poskytnout informace
     *                  o události, kterou zavolání dané metody ohlašuje
     */
//    @Override
    public void notify(Informant informant);



//== DEFAULT GETTERS AND SETTERS ===============================================
//== OTHER DEFAULT METHODS =====================================================



//##############################################################################
//== NESTED DATA TYPES =========================================================
}
