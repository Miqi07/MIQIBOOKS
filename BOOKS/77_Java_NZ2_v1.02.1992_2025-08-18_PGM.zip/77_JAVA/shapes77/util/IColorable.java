package shapes77.util;
// Příliš žluťoučký kůň úpěl ďábelské ó - PŘÍLIŠ ŽLUŤOUČKÝ KŮŇ ÚPĚL ĎÁBELSKÉ Ó



/*******************************************************************************
 * Instance interfejsu {@code IColorable} představují objekty,
 * které jsou schopny prozradit a nastavit svoji barvu.
 * Nemusí jít nutně o jednobarevné objekty.
 * Stačí, když umějí prozradit a nastavit barvu některé svojí části.
 */
public interface IColorable
{
//\CC== CLASS (STATIC) CONSTANTS ===============================================
//\CM== CLASS (STATIC) METHODS =================================================



//##############################################################################
//\AG== ABSTRACT GETTERS AND SETTERS ===========================================

    /***************************************************************************
     * Vrátí aktuální barvu instance.
     *
     * @return Instance třídy {@code NamedColor} definující
     *         aktuálně nastavenou barvu
     */
    public NamedColor getColor();


    /***************************************************************************
     * Nastaví novou barvu instance.
     *
     * @param newColor  Požadovaná nová barva
     */
    public void setColor(NamedColor newColor);



//\AM== REMAINING ABSTRACT METHODS =============================================
//\DG== DEFAULT GETTERS AND SETTERS ============================================
//\DM== REMAINING DEFAULT METHODS ==============================================



//##############################################################################
//\NT== NESTED DATA TYPES ======================================================
}
