package shapes77.util;
// Příliš žluťoučký kůň úpěl ďábelské ó - PŘÍLIŠ ŽLUŤOUČKÝ KŮŇ ÚPĚL ĎÁBELSKÉ Ó



/*******************************************************************************
 * Instance rozhraní {@code IBroadcaster} představuji hlasatele
 * oznamujícího přihlášeným posluchačům výskyt události, na niž čekají.
 *
 * @param <Informant> Typ objektu obsahujícího informace o události,
 *                    kterou hlasatel oznamuje svým posluchačům
 */
public interface IBroadcaster<Informant>
{
//== STATIC CONSTANTS ==========================================================
//== STATIC METHODS ============================================================



//##############################################################################
//== ABSTRACT GETTERS AND SETTERS ==============================================
//== OTHER ABSTRACT METHODS ====================================================

    /***************************************************************************
     * Přidá zadaného posluchače do seznamu posluchačů,
     * které zpravuje o výskytu očekávané události.
     *
     * @param listener Přihlašovaný posluchač
     */
//    @Override
    public void addListener(IListener<Informant> listener);


    /***************************************************************************
     * Odebere zadaného posluchače ze seznamu posluchačů,
     * které zpravuje o výskytu očekávané události.
     *
     * @param listener Odhlašovaný posluchač
     */
//    @Override
    public void removeListener(IListener<Informant> listener);



//== DEFAULT GETTERS AND SETTERS ===============================================
//== OTHER DEFAULT METHODS =====================================================



//##############################################################################
//== NESTED DATA TYPES =========================================================
}
