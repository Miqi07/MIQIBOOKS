package shapes77.util;
// Příliš žluťoučký kůň úpěl ďábelské ó - PŘÍLIŠ ŽLUŤOUČKÝ KŮŇ ÚPĚL ĎÁBELSKÉ Ó



/*******************************************************************************
/ * Interfejs {@code ITextConstants} je sbírkou obecně užitečných textových
 * konstant.
 */
public interface ITextConstants
{
//\CC== CLASS (STATIC) CONSTANTS ===============================================

    /** Oddělující řádek znaků mínus <code>('-')</code>. */
    String LINE_1M =
    "-------------------------------------------------------------------------";

    /** Oddělující řádek znaků rovno ('='). */
    String LINE_1E =
    "=========================================================================";

    /** Oddělující řádek znaků mříž ('#'). */
    String LINE_1H =
    "#########################################################################";

    /** Podtržení mínusy a odřádkování. */
    String LINE_1MN = LINE_1M + '\n';
    /** Podtržení rovnítky a odřádkování. */
    String LINE_1EN = LINE_1E + '\n';
    /** Podtržení mřížemi a odřádkování. */
    String LINE_1HN = LINE_1H + '\n';

    /** Odřádkování a podtržení mínusy. */
    String LINE_N1M = '\n' + LINE_1M;
    /** Odřádkování a podtržení rovnítky. */
    String LINE_N1E = '\n' + LINE_1E;
    /** Odřádkování a podtržení mžížemi. */
    String LINE_N1H = '\n' + LINE_1H;

    /** Odřádkování, podtržení mínusy a opět odřátkováni. */
    String LINE_N1MN = LINE_N1M + '\n';
    /** Odřádkování, podtržení rovnítky a opět odřátkováni. */
    String LINE_N1EN = LINE_N1E + '\n';
    /** Odřádkování, podtržení mřížemi a opět odřátkováni. */
    String LINE_N1HN = LINE_N1H + '\n';

    /** Odřádkování, dvojité podtržení mínusy a opět odřátkováni. */
    String LINE_N2MN = LINE_N1M + LINE_N1MN;
    /** Odřádkování, dvojité podtržení rovnítky a opět odřátkováni. */
    String LINE_N2EN = LINE_N1E + LINE_N1EN;
    /** Odřádkování, dvojité podtržení mřížemi a opět odřátkováni. */
    String LINE_N2HN = LINE_N1H + LINE_N1HN;



//\CM== CLASS (STATIC) METHODS =================================================



//##############################################################################
//\AG== ABSTRACT GETTERS AND SETTERS ===========================================
//\AM== REMAINING ABSTRACT METHODS =============================================
//\DG== DEFAULT GETTERS AND SETTERS ============================================
//\DM== REMAINING DEFAULT METHODS ==============================================



//##############################################################################
//\NT== NESTED DATA TYPES ======================================================
}
