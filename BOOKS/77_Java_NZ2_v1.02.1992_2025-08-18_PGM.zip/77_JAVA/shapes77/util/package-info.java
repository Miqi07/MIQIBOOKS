/* Saved in UTF-8 codepage: Příliš žluťoučký kůň úpěl ďábelské ódy. ÷ × ¤
 * Check: «Stereotype», Section mark-§, Copyright-©, Alpha-α, Beta-β, Smile-☺
 */



/*******************************************************************************
 * Balíček obsahuje obecně použitelné datové typy a vedle nich i typy
 * určené pro objekty, u nichž má smysl hovořit o jejich barvě.
 */
package shapes77.util;
