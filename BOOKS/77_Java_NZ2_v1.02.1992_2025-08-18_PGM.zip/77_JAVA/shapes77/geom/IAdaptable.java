package shapes77.geom;
// Příliš žluťoučký kůň úpěl ďábelské ó - PŘÍLIŠ ŽLUŤOUČKÝ KŮŇ ÚPĚL ĎÁBELSKÉ Ó



/********************************************************************************
 * Instance interfejsu {@code IAdaptable} představují objekty,
 * které jsou schopny se měnit svoji velikost a pozici
 * a přizpůsobovat se tak rozměrům prostředí, v němž se nacházejí.
 */
public interface IAdaptable
{
//\CC== CLASS (STATIC) CONSTANTS ===============================================
//\CM== CLASS (STATIC) METHODS =================================================



//##############################################################################
//\AG== ABSTRACT GETTERS AND SETTERS ===========================================
//\AM== REMAINING ABSTRACT METHODS =============================================

    /***************************************************************************
     * V závislosti na zadané změně referenční velikosti <br>
     * změní absolutní pozici a rozměr instance tak,
     * aby se její relativní pozice a velikost nezměnila .
     *
     * @param oldSize  Původní hodnota referenční velikosti
     * @param newSize  Nově nastavená hodnota referenční velikosti
     */
//    @Override
    public void stepChanged(int oldSize, int newSize);



//\DG== DEFAULT GETTERS AND SETTERS ============================================
//\DM== REMAINING DEFAULT METHODS ==============================================



//##############################################################################
//\NT== NESTED DATA TYPES ======================================================
}
