package shapes77.geom;
// Příliš žluťoučký kůň úpěl ďábelské ó - PŘÍLIŠ ŽLUŤOUČKÝ KŮŇ ÚPĚL ĎÁBELSKÉ Ó



/********************************************************************************
 * Instance třídy {@code Rozměr} představují přepravky uchovávající informace
 * o rozměrech objektu.
 *
 * @param width  Šířka objektu
 * @param height Výška objektu
 */
public record Size(int width, int height)
{
}
