package shapes77.geom;
// Příliš žluťoučký kůň úpěl ďábelské ó - PŘÍLIŠ ŽLUŤOUČKÝ KŮŇ ÚPĚL ĎÁBELSKÉ Ó



/*******************************************************************************
 * Instance rozhraní {@code IDirectable} představují objekty,
 * které umějí prozradit a nastavit svůj směr.
 * Rozhraní nijak nespecifikuje, zda se instance mají umět otočit
 * pouze do jednoho ze čtyř hlavních směrů, anebo zda umějí všech 8 směrů.
 */
public interface IDirectable
{
//== STATIC CONSTANTS ==========================================================
//== STATIC METHODS ============================================================



//##############################################################################
//== ABSTRACT GETTERS AND SETTERS ==============================================

    /***************************************************************************
     * Vrátí směr, do nějž je daná instance natočena.
     *
     * @return Směr, do nějž je daná instance natočena
     */
//    @Override
    public Direction8 getDirection();


    /***************************************************************************
     * Otočí instanci do zadaného směru.
     *
     * @param direction Směr, do nějž má být instance otočena
     */
//    @Override
    public void setDirection(Direction8 direction);



//== OTHER ABSTRACT METHODS ====================================================
//== DEFAULT GETTERS AND SETTERS ===============================================
//== OTHER DEFAULT METHODS =====================================================



//##############################################################################
//== NESTED DATA TYPES =========================================================
}
