package shapes77.geom;
// Příliš žluťoučký kůň úpěl ďábelské ó - PŘÍLIŠ ŽLUŤOUČKÝ KŮŇ ÚPĚL ĎÁBELSKÉ Ó

/********************************************************************************
 * Instance třídy {@code Position} představují přepravky uchovávající informace
 * o pozici objektu.
 *
 * @param x  Vodorovná souřadnice
 * @param y  Svislá souřadnice
 */
public record Position(int x, int y)
{
}
