package shapes77.geom;
// Příliš žluťoučký kůň úpěl ďábelské ó - PŘÍLIŠ ŽLUŤOUČKÝ KŮŇ ÚPĚL ĎÁBELSKÉ Ó

import shapes77.util.ICopyable;



/********************************************************************************
 * Instance interfejsu {@code Interface} představují objekty,
 * které umějí prozradit a nastavit svoji velikost a pozici
 * a které se navíc umějí i zkopírovat.
 */
public interface IShape
         extends IChangeable, ICopyable
{
//\CC== CLASS (STATIC) CONSTANTS ===============================================
//\CM== CLASS (STATIC) METHODS =================================================



//##############################################################################
//\AG== ABSTRACT GETTERS AND SETTERS ===========================================
//\AM== REMAINING ABSTRACT METHODS =============================================

    /***************************************************************************
     * Vrátí svoji hlubokou kopii, tj. instanci s naprosto shodnými vlastnostmi
     * s výjimkou těch, které podle kontraktu shodné být nesmějí.
     *
     * @return Požadovaná kopie
     */
    @Override
    public IShape copy();



//\DG== DEFAULT GETTERS AND SETTERS ============================================
//\DM== REMAINING DEFAULT METHODS ==============================================



//##############################################################################
//\NT== NESTED DATA TYPES ======================================================
}
