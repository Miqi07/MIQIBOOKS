package shapes77.canvas_4;
// Příliš žluťoučký kůň úpěl ďábelské ó - PŘÍLIŠ ŽLUŤOUČKÝ KŮŇ ÚPĚL ĎÁBELSKÉ Ó



/*******************************************************************************
 * Instance interfejsu {@code IModular} představují geometrické objekty,
 * které umějí prozradit a nastavit svoji pozici a modul.
 * Modul objektu je přitom základní rozměr, od nějž jsou dovozovány
 * všechny ostatní rozměry objektu.
 * Většinou je definován jako délka strany opsaného čtverce.
 */
public interface IModular
         extends IMovable
{
//\CC== CLASS (STATIC) CONSTANTS ===============================================
//\CM== CLASS (STATIC) METHODS =================================================



//##############################################################################
//\AG== ABSTRACT GETTERS AND SETTERS ===========================================

    /***************************************************************************
     * Vrátí velikost modulu, tj. délku strany opsaného čtverce.
     *
     * @return   Velikost modulu instance
     */
//    @Override
    public int getModule();


    /***************************************************************************
     * Změni velikost instance, aby měl její nový modul
     * (= délku strany opsaného čtverce) zadanou velikost.
     *
     * @param module    Nově nastavovaný modul
     */
//    @Override
    public void setModule(int module);



//\AM== REMAINING ABSTRACT METHODS =============================================
//\DG== DEFAULT GETTERS AND SETTERS ============================================
//\DM== REMAINING DEFAULT METHODS ==============================================



//##############################################################################
//\NT== NESTED DATA TYPES ======================================================
}
