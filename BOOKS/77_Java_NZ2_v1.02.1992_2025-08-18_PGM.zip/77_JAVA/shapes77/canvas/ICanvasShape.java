package shapes77.canvas;
// Příliš žluťoučký kůň úpěl ďábelské ó - PŘÍLIŠ ŽLUŤOUČKÝ KŮŇ ÚPĚL ĎÁBELSKÉ Ó
// J:/77_JAVA/shapes77/canvas/ICanvasShape.java

import shapes77.geom.IShape;



/*******************************************************************************
 * Instance interfejsu {@code ICanvasShape} představují geometrické tvary,
 * které se umějí nakreslit na plátno a
 * které umějí prozradit a nastavit svoji pozici a svoje rozměry.
 * Pozice instance je implicitně definována jako pozice
 * levého horního rohu opsaného obdélníku.
 * Rozměry instance jsou přitom definovány jako rozměry opsaného obdélníku.
 * Interfejs nedeklaruje žádné nové abstraktní metody, všechny zdědí.
 */
public interface ICanvasShape
         extends IShape, ICanvasPaintable
{
//\CC== CLASS (STATIC) CONSTANTS ===============================================
//\CM== CLASS (STATIC) METHODS =================================================



//##############################################################################
//\AG== ABSTRACT GETTERS AND SETTERS ===========================================
//\AM== REMAINING ABSTRACT METHODS =============================================

    /***************************************************************************
     * Vrátí kopii daného tvaru, tj. stejný tvar
     * se stejnou velikostí, umístěním a barvou.
     *
     * @return Požadovaná kopie
     */
    public ICanvasShape copy();



//\DG== DEFAULT GETTERS AND SETTERS ============================================
//\DM== REMAINING DEFAULT METHODS ==============================================



//##############################################################################
//\NT== NESTED DATA TYPES ======================================================
}
