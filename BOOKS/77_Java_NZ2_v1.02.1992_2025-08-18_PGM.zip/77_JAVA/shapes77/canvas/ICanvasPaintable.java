package shapes77.canvas;
// Příliš žluťoučký kůň úpěl ďábelské ó - PŘÍLIŠ ŽLUŤOUČKÝ KŮŇ ÚPĚL ĎÁBELSKÉ Ó
// J:/77_JAVA/shapes77/canvas/ICanvasPaintable.java



/*******************************************************************************
 * Instance interfejsu {@code ICanvasPaintable} představují objekty,
 * které jsou schopny se nakreslit na plátno a opět se smazat.
 */
public interface ICanvasPaintable
{
//\CC== CLASS (STATIC) CONSTANTS ===============================================
//\CM== CLASS (STATIC) METHODS =================================================



//##############################################################################
//\AG== ABSTRACT GETTERS AND SETTERS ===========================================
//\AM== REMAINING ABSTRACT METHODS =============================================

    /***************************************************************************
     * Zobrazí svoji instanci, tj.vykreslí její obraz na plátno.
     */
//     @Override
    public void paint();


    /***************************************************************************
     * Smaže obraz své instance z plátna,
     * t.j. nakreslí ji barvou pozadí plátna.
     */
//     @Override
    public void rubOut();



//\DG== DEFAULT GETTERS AND SETTERS ============================================
//\DM== REMAINING DEFAULT METHODS ==============================================



//##############################################################################
//\NT== NESTED DATA TYPES ======================================================
}
