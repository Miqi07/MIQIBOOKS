package shapes77.templates;
/* UTF-8 codepage: Příliš žluťoučký kůň úpěl ďábelské ó. ÷ × ¤ */

/*******************************************************************************
 * {@code IIntefaceTemplate} je šablonou interfejsů doprovodných programů.
 *
 * @author  author name
 * @version 0.00.0000 — 20yy-mm-dd
 */
public interface BJ_IIntefaceTemplate
{
    //\CC== CLASS (STATIC) CONSTANTS ===========================================
    //\CM== CLASS (STATIC) METHODS =============================================

    //##########################################################################
    //\AG== ABSTRACT GETTERS AND SETTERS =======================================
    //\AM== OTHER ABSTRACT METHODS =============================================
    //\DG== DEFAULT GETTERS AND SETTERS ========================================
    //\DM== OTHER DEFAULT METHODS ==============================================

    //##########################################################################
    //\NT== NESTED DATA TYPES ==================================================
}
