// Příliš žluťoučký kůň úpěl ďábelské ó - PŘÍLIŠ ŽLUŤOUČKÝ KŮŇ ÚPĚL ĎÁBELSKÉ Ó
// J:/77_JAVA/game77/ck1__portal/package-info.java


/*******************************************************************************
 * Balíček {@code game77.ck1__portal} je demonstrační balíček,
 * v němž je definován pouze portál.
 */
package game77.ck1__portal;

