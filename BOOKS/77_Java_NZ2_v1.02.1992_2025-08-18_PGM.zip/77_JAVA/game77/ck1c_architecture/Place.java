package game77.ck1c_architecture;
// Příliš žluťoučký kůň úpěl ďábelské ó - PŘÍLIŠ ŽLUŤOUČKÝ KŮŇ ÚPĚL ĎÁBELSKÉ Ó
// J:/77_JAVA/game77/ck1c_architecture/Place.java

import game77.api.IPlace;
import game77.api.TypeOfStep;

import java.util.Arrays;
import java.util.List;
import java.util.List;


/*******************************************************************************
Instance třídy {@code Place} představují prostory ve hře.
Dosažení prostoru si můžeme představovat jako částečný cíl,
kterého se hráč ve hře snaží dosáhnout.
Prostory mohou být místnosti, planety, životní etapy atd.
Prostory mohou obsahovat různé h-objekty,
které mohou hráči pomoci v dosažení cíle hry.
Každý prostor zná své aktuální bezprostřední sousedy
a ví, jaké objekty se v něm v daném okamžiku nacházejí.
Sousedé daného prostoru i v něm se nacházející objekty
se mohou v průběhu hry měnit.
 */
public   class Place
       extends AItemContainer
    implements IPlace
{
    /** Stručná charakteristika daného prostoru. */
    private final String description;

    /** Názvy sousedů daného prostoru po startu hry. */
    private final List<Place> neighbors;


    public Place(String name,  String description,
                 Place[] initialNeighbors,
                 Item... initialItems)
    {
        super(name, initialItems);
        this.description = description;
        this.neighbors   = Arrays.asList(initialNeighbors);
    }


    /***************************************************************************
     * Vrátí stručný popis daného prostoru.
     *
     * @return Stručný popis daného prostoru
     */
    @Override
    public String description()
    {
        return description;
    }


    /***************************************************************************
     * Vrátí kolekci sousedů daného prostoru, tj. kolekci prostorů,
     * do nichž je možno se z tohoto prostoru přesunout příkazem typu
     * {@link game77.api.TypeOfStep#tsGOTO TypeOfStep.tsGOTO}.
     *
     * @return Kolekce sousedů
     */
    @Override
    public List<Place> neighbors()
    {
        return neighbors;
    }


    /***************************************************************************
     * Inicializuje daný prostor, tj. přiřadí mu počáteční sadu sousedů
     * a umístí do něj počáteční sadu objektů.
     */
    @Override
    public void initialize()
    {
        throw new UnsupportedOperationException(
              "\nMetoda Place.initialize()"
            + "\nnení dosud plně implementována.");
    }
}
