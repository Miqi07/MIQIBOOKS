package game77.ck1c_architecture;
// Příliš žluťoučký kůň úpěl ďábelské ó - PŘÍLIŠ ŽLUŤOUČKÝ KŮŇ ÚPĚL ĎÁBELSKÉ Ó
// J:/77_JAVA/game77/ck1c_architecture/AItemContainer.java

import game77.api.IItem;
import game77.api.IItemContainer;

import java.util.Arrays;
import java.util.List;


/*******************************************************************************
 * Instance abstraktní třídy {@code AItemContainer} jsou rodičovskými podobjekty
 * tříd, jejichž instance představují kontejnery h-objektů.
 * Speciálními případy těchto kontejnerů jsou prostory a batoh.
 */
public   class AItemContainer
       extends ANamed
    implements IItemContainer
{
    /** Aktuálně obsažené h-objekty. */
    private final List<Item> items;


    /***************************************************************************
     * Vytvoří rodičovský podobjekt představující kontejner h-objektů.
     *
     * @param name  Název vlastníka předávaný rodiči
     * @param items Položky uložené v kontejneru na počátku hry
     */
    public AItemContainer(String name, Item... items)
    {
        super(name);
        this.items = Arrays.asList(items);
    }


    /***************************************************************************
     * Vrátí kolekci objektů nacházejících se v daném kontejneru.
     *
     * @return Kolekce objektů nacházejících se v daném kontejneru
     */
    @Override
    public List<IItem> items()
    {
        return List.copyOf(items);
    }


    /***************************************************************************
     * Je li v kontejneru objekt se zadaným názvem, vrátí jej,
     * není-li tam, vrátí prázdný odkaz {@code null}.
     *
     * @param  name Název hledané objektu
     * @return Hledaný objekt nebo prázdný odkaz {@code null}.
     */
    @Override
    public Item item(String name)
    {
        throw new UnsupportedOperationException(
                  "\nMetoda AItemContainer.item(String name)"
                + "\nnení dosud korektně implementována.");
    }


    /***************************************************************************
     * Přidá zadaný objekt do kontejneru a vrátí informaci o tom,
     * jestli se to podařilo.
     *
     * @param item Přidávaný objekt
     * @return Podařilo-li se h-objekt přidat, vrátí {@code true}
     */
    @Override
    public boolean addItem(IItem item)
    {
        throw new UnsupportedOperationException(
                  "\nMetoda AItemContainer.addItem(IItem item)"
                + "\nnení dosud korektně implementována.");
    }


    /***************************************************************************
     * Odebere zadaný objekt z kontejneru a vrátí informaci o tom,
     * jestli se to podařilo.
     *
     * @param item Odebíraný objekt
     * @return Podařilo-li se objekt odebrat, vrátí {@code true}
     */
    @Override
    public boolean removeItem(IItem item)
    {
        throw new UnsupportedOperationException(
              "\nMetoda AItemContainer.removeItem(IItem item)"
            + "\nnení dosud plně implementována.");
    }


    /***************************************************************************
     * Inicializuje kontejner na počátku hry.
     * Po inicializace bude obsahovat příslušnou výchozí sadu objektů.
     */
    @Override
    public void initializeItems()
    {
        throw new UnsupportedOperationException(
              "\nMetoda AItemContainer.initializeItems()"
            + "\nnení dosud plně implementována.");
    }
}
