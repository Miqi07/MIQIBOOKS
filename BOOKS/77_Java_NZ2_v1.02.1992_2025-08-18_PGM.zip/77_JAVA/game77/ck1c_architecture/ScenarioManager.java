package game77.ck1c_architecture;
// Příliš žluťoučký kůň úpěl ďábelské ó - PŘÍLIŠ ŽLUŤOUČKÝ KŮŇ ÚPĚL ĎÁBELSKÉ Ó
// J:/77_JAVA/game77/ck1c_architecture/ScenarioManager.java

import game77.api.Scenario;
import game77.api.ScenarioStep;

import java.util.List;

import static game77.api.TypeOfScenario.*;
import static game77.api.TypeOfStep.*;



/*******************************************************************************
 * Třída {@code ScenarioManager} definuje sadu scénářů,
 * podle nichž je možno hrát (anebo testovat) hru, pro niž jsou určeny -
 * v tomoto případě hru inspirovanou pohádkou o Červené Karkulce.
 * Aby bylo možno jednotlivé scénáře od sebe odlišit,
 * je každý pojmenován a má přiřazen typ, podle které lze blíže určit,
 * k čemu je možno daný scénář použít.
 * Scénáře jsou definovány jako posloupnosti kroků.
 * Tato verze obsahuje vedle scénáře HAPPY ještě scénář BASIC
 * definující posloupnost kroků prověřující všechny povinné akce.
 */
public class ScenarioManager
{
//===== CLASS (STATIC) ATTRIBUTES (FIELDS) =====================================

/** Téma vyvíjené hry používané ve startovním kroku a v nápovědě. */
static final String SUBJECT = """
        Toto je příběh o Červené Karkulce, babičce a vlkovi.
        Svými příkazy řídíte Karkulku, aby donesla bábovku a víno
        babičce v chaloupce za temným lesem.
        Karkulka musí nejprve v domečku vložit do košíku víno a bábovku,
        a potom přejít přes les a temný les do chaloupky.
        Když přijde do chaloupky, měla by položit dárky, vzbudit babičku,
        pozdravit a popřát jí k narozeninám.
        Jste-li dobrodružné typy, můžete to místo s babičkou provést
        s vlkem, který spí v temném lese.
        """;

/** Společný startovní krok všech scénářů. */
private static final ScenarioStep START_STEP =
    new ScenarioStep(tsSTART, "",
        "Vítejte!\n" + SUBJECT
      + "\nNebudete-li si vědět rady, zadejte znak ?, jenž zobrazí nápovědu."
        ,
        "Domeček",                                      //Aktuální prostor
        new String[] { "Les" },                         //Sousedé
        new String[] { "Bábovka", "Víno", "Stůl", "Panenka", },//H-o v prostoru
        new String[] { }                                //H-objekty v batohu
    );

////////////////////////////////////////////////////////////////////////////////
private static final Scenario BASIC = new Scenario(scBASIC,
    START_STEP,
    new ScenarioStep(1, tsGOTO, "Jdi Les",
        "Karkulka se přesunula do prostoru:\n"
      + "Les s jahodami, malinami a pramenem vody",
        "Les",                                          //Aktuální prostor
        new String[] { "Domeček", "Temný_les" },        //Sousedé
        new String[] { "Maliny", "Jahody", "Studánka",},//H-obj. v prostoru
        new String[] { }                                //H-objekty v batohu
    ),
    new ScenarioStep(tsTAKE, "Vezmi Maliny",
        "Karkulka dala do košíku objekt: Maliny",
        "Les",                                          //Aktuální prostor
        new String[] { "Domeček", "Temný_les" },        //Sousedé
        new String[] { "Jahody", "Studánka", },         //H-obj. v prostoru
        new String[] { "Maliny", }                      //H-objekty v batohu
    ),
    new ScenarioStep(tsPUT_DOWN, "Polož Maliny",
        "Karkulka vyndala z košíku objekt: Maliny",
        "Les",                                          //Aktuální prostor
        new String[] { "Domeček", "Temný_les" },        //Sousedé
        new String[] { "Maliny", "Jahody", "Studánka",},//H-obj. v prostoru
        new String[] { }                                //H-objekty v batohu
    ),
    new ScenarioStep(tsTAKE, "Vezmi Maliny",
        "Karkulka dala do košíku objekt: Maliny",
        "Les",                                          //Aktuální prostor
        new String[] { "Domeček", "Temný_les" },        //Sousedé
        new String[] { "Jahody", "Studánka", },         //H-obj. v prostoru
        new String[] { "Maliny", }                      //H-objekty v batohu
    ),
    new ScenarioStep(tsHELP, "?",
        SUBJECT + "\nMůžete zadat tyto příkazy:\n",
        "Les",                                          //Aktuální prostor
        new String[] { "Domeček", "Temný_les" },        //Sousedé
        new String[] { "Jahody", "Studánka", },         //H-obj. v prostoru
        new String[] { "Maliny", }                      //H-objekty v batohu
    ),
    new ScenarioStep(tsEND, "konec",
        "Ukončili jste hru.\n"
      + "Děkujeme, že jste si zahráli.",
        "Les",                                          //Aktuální prostor
        new String[] { "Domeček", "Temný_les" },        //Sousedé
        new String[] { "Jahody", "Studánka", },         //H-obj. v prostoru
        new String[] { "Maliny", }                      //H-objekty v batohu
    )
);


////////////////////////////////////////////////////////////////////////////////
private static final Scenario HAPPY = new Scenario(scHAPPY,
    START_STEP,
    new ScenarioStep(1, tsTAKE, "Vezmi víno",
        "Karkulka dala do košíku objekt: Víno",
        "Domeček",                                      //Aktuální prostor
        new String[] { "Les" },                         //Sousedé
        new String[] { "Bábovka", "Stůl", "Panenka", }, //H-obj. v prostoru
        new String[] { "Víno", }                        //H-objekty v batohu
    ),
    new ScenarioStep(tsTAKE, "Vezmi Bábovka",
        "Karkulka dala do košíku objekt: Bábovka",
        "Domeček",                                      //Aktuální prostor
        new String[] { "Les" },                         //Sousedé
        new String[] { "Stůl", "Panenka", },            //H-obj. v prostoru
        new String[] { "Bábovka", "Víno", }             //H-objekty v batohu
    ),
    new ScenarioStep(tsGOTO, "Jdi Les",
        "Karkulka se přesunula do prostoru:\n"
      + "Les s jahodami, malinami a pramenem vody",
        "Les",                                          //Aktuální prostor
        new String[] { "Domeček", "Temný_les" },        //Sousedé
        new String[] { "Maliny", "Jahody", "Studánka", },//H-obj. v prostoru
        new String[] { "Bábovka", "Víno",  }            //H-objekty v batohu
    ),
    new ScenarioStep(tsGOTO, "Jdi Temný_les",
        "Karkulka se přesunula do prostoru:\n"
      + "Temný_les s jeskyní a číhajícím vlkem",
        "Temný_les",                                    //Aktuální prostor
        new String[] { "Les", "Jeskyně", "Chaloupka", },//Sousedé
        new String[] { "Vlk", },                        //H-obj. v prostoru
        new String[] { "Bábovka", "Víno", }             //H-objekty v batohu
    ),
    new ScenarioStep(tsGOTO, "Jdi Chaloupka",
        "Karkulka se přesunula do prostoru:\n"
      + "Chaloupka, kde bydlí babička",
        "Chaloupka",                                    //Aktuální prostor
        new String[] { "Temný_les" },                   //Sousedé
        new String[] { "Postel", "Stůl", "Babička", },  //H-obj. v prostoru
        new String[] { "Bábovka", "Víno", }             //H-objekty v batohu
    ),
    new ScenarioStep(tsPUT_DOWN, "Polož Bábovka",
        "Karkulka vyndala z košíku objekt: Bábovka",
        "Chaloupka",                                    //Aktuální prostor
        new String[] { "Temný_les" },                   //Sousedé
        new String[] { "Postel", "Stůl", "Babička", "Bábovka", },
        new String[] { "Víno", }                        //H-objekty v batohu
    ),
    new ScenarioStep(tsPUT_DOWN, "Polož Víno",
        "Karkulka vyndala z košíku objekt: Víno",
        "Chaloupka",                                    //Aktuální prostor
        new String[] { "Temný_les" },                   //Sousedé
        new String[] { "Postel", "Stůl", "Babička", "Bábovka", "Víno", },
        new String[] { }                                //H-objekty v batohu
    ),
    new ScenarioStep(tsNS_1, "Probuď babička",
        "Karkulka probudila objekt Babička",
        "Chaloupka",                                    //Aktuální prostor
        new String[] { "Temný_les" },                   //Sousedé
        new String[] { "Postel", "Stůl", "Babička", "Bábovka", "Víno", },
        new String[] { }                                //H-objekty v batohu
    ),
    new ScenarioStep(tsNS_0, "Pozdrav",
        "Karkulka pozdravila objekt Babička",
        "Chaloupka",                                    //Aktuální prostor
        new String[] { "Temný_les" },                   //Sousedé
        new String[] { "Postel", "Stůl", "Babička", "Bábovka", "Víno", },
        new String[] { }                                //H-objekty v batohu
    ),
    new ScenarioStep(tsSUCCESS, "Popřej",
        "Karkulka popřála objektu babička vše nejlepší k narozeninám\n"
      + "Úspěšně jste ukončili hru.\n"
      + "Děkujeme, že jste si zahráli.",
        "Chaloupka",                                    //Aktuální prostor
        new String[] { "Temný_les" },                   //Sousedé
        new String[] { "Postel", "Stůl", "Babička", "Bábovka", "Víno", },
        new String[] { }                                //H-objekty v batohu
    )
);


//===== CLASS (STATIC) GETTERS AND SETTERS =====================================

    /***************************************************************************
     * Vrátí seznam definovaných scénářů.
     *
     * @return Seznam spravovaných scénářů
     */
    public static List<Scenario> scenarios()
    {
        return List.of(HAPPY, BASIC);
    }


//===== INSTANCE INITIALIZERS (CONSTRUCTORS) ===================================

    private ScenarioManager() {}

}
