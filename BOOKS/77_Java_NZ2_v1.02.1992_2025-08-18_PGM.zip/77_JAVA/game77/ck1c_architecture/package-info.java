// Příliš žluťoučký kůň úpěl ďábelské ó - PŘÍLIŠ ŽLUŤOUČKÝ KŮŇ ÚPĚL ĎÁBELSKÉ Ó
// J:/77_JAVA/game77/ck1c_architecture/package-info.java


/*******************************************************************************
 * Balíček {@code game77.ck1c_architecture} obsahuje soubory hry v etapě,
 * kdy jsou vedle portálu a scénářů HAPPY a BASIC definovány všechny třídy
 * potřebné k formální implementaci API.
 */
package game77.ck1c_architecture;

