package game77.ck1l_user_io;
// Příliš žluťoučký kůň úpěl ďábelské ó - PŘÍLIŠ ŽLUŤOUČKÝ KŮŇ ÚPĚL ĎÁBELSKÉ Ó
// J:/77_JAVA/game77/ck1l_user_io/IUI.java


/*******************************************************************************
 * Interfejs {@code IUI} definuje požadované rozhraní objektů,
 * jejichž prostřednictvím bude aplikace kounikovat s uživatelem.
 */
public interface IUI
{
    /***************************************************************************
     * Zobrazí uživateli odpověď hry a požádá jej o zadání dalšího příkazu.
     *
     * @param answer Zobrazovaná odpověď hry
     * @return Příkaz zadaný uživatelem
     */
    public String getCommand(String answer);


    /***************************************************************************
     * Zobrazí zadaný string -- většinou odpověď hry.
     *
     * @param answer Zobrazovaný string
     */
    public void showAnswer(String answer);


    /***************************************************************************
     * Zeptá se uživatele a očekává odpověď ANO/NE, nebo její ekvivalent.
     *
     * @param question Pokládaná otázka
     * @return Odpověď uživatele jako logická hodnota
     */
    public boolean askQuestion(String question);
}
