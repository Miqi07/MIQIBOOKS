package game77.ck1l_user_io;
// Příliš žluťoučký kůň úpěl ďábelské ó - PŘÍLIŠ ŽLUŤOUČKÝ KŮŇ ÚPĚL ĎÁBELSKÉ Ó
// J:/77_JAVA/game77/ck1l_user_io/Console.java

import java.util.Scanner;


/********************************************************************************
 * Třída {@code Console} definuje definuje komunikační objekt
 * komunikující s uživatelem prostřednictvím standardního vstupu a výstupu.
 */
public   class Console
    implements IUI
{
    /** Scanner sloužící k načítání příkazů ze standardního vstupu. */
    private static final Scanner SCANNER = new Scanner(System.in);

    /** Jediná instance této třídy - jedináček. */
    private static final Console CONSOLE = new Console();


    /***************************************************************************
     * Tovární metoda vracející odkaz na jedinou instanci.
     *
     * @return Požadovaný odkaz
     */
    public static Console get() { return CONSOLE; }


    /***************************************************************************
     * Soukromý konstruktor bránící volnému vytváření instancí.
     */
    private Console() {}


    /***************************************************************************
     * Zobrazí uživateli odpověď hry a požádá jej o zadání dalšího příkazu.
     *
     * @param answer Zobrazovaná odpověď hry
     * @return Příkaz zadaný uživatelem
     */
    @Override
    public String getCommand(String answer) {
        System.out.println(answer);
        System.out.print("==============================\nZadáte: ");
        String command =  SCANNER.nextLine();
        System.out.print("------------------------------\n");
        return command;
    }


    /***************************************************************************
     * Zobrazí zadaný string -- většinou odpověď hry.
     *
     * @param answer Zobrazovaný string
     */
    public void showAnswer(String answer) {
        System.out.println(answer + "==============================\n");
    }


    /***************************************************************************
     * Zeptá se uživatele a očekává odpověď ANO/NE, nebo její ekvivalent.
     *
     * @param question Pokládaná otázka
     * @return Odpověď uživatele jako logická hodnota
     */
    public boolean askQuestion(String question) {
        char answer;
        for(;;) {
            System.out.println("==============================\n"
                             + "Chcete si zahrát ještě jednou (A/N): ");
            String line = SCANNER.nextLine().trim();
            if (!  line.isEmpty()
                && "01ANan".indexOf(line.charAt(0)) != -1) {
                answer = line.charAt(0);
                break;                      //Výskok z cyklu ---------->
            }
            System.out.println("------------------------------\n"
                + "Odpověď musí začínat některým ze znaků \"01ANan\"\n"
                + "Zkuste odpovědět znovu.");
        }
        return ("1Aa".indexOf(answer) != -1);
    }

}
