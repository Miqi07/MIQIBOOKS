package game77.ck1l_user_io;
// Příliš žluťoučký kůň úpěl ďábelské ó - PŘÍLIŠ ŽLUŤOUČKÝ KŮŇ ÚPĚL ĎÁBELSKÉ Ó
// J:/77_JAVA/game77/ck1l_user_io/Main.java

import game77.api.IGame;
import game77.api.IPlace;
import game77.api.IWorld;

import java.util.Scanner;


/*******************************************************************************
 * Třída {@code Main} je hlavní třídou aplikace s demonstrační hrou.
 */
public class Main
{
    private static final Scanner scanner = new Scanner(System.in);


    /***************************************************************************
     * Metoda spouštěnící celou aplikaci.
     *
     * @param args Argumenty příkazového řádku
     */
    public static void main(String[] args) {
        multirun(new game77.ck1k_whole.Portal().game());
    }


    /***************************************************************************
     * Spustí hru a umožní uživateli ji odehrát.
     *
     * @param game Spouštěná hra
     */
    private static void run(IGame game) {
        String  command = "";
        String  answer;
        for(;;) {
            answer = game.executeCommand(command);
            System.out.println(answer);
            if (! game.isActive()) { break; }    //---------->
            System.out.print("==============================\nZadáte: ");
            command =  scanner.nextLine();
            System.out.print("------------------------------\n");
        }
    }


    /***************************************************************************
     * Spustí hru, umožní uživateli ji odehrát a po skončení hry se s ním
     * domluví, bude-li končit nebo si che hru zahrát znovu.
     *
     * @param game Spouštěná hra
     */
    public static void multirun(IGame game) {
        for(;;) {
            run(game);      //Spuštění jednoho běhu hry
            char answer;
            for(;;) {
                System.out.println("==============================\n"
                                 + "Chcete si zahrát ještě jednou (A/N): ");
                String line = scanner.nextLine().trim();
                if (!  line.isEmpty()
                    && "01ANan".indexOf(line.charAt(0)) != -1) {
                    answer = line.charAt(0);
                    break; // Výskok z vnitřního cyklu          //---------->
                }
                System.out.println("------------------------------\n"
                    + "Odpověď musí začínat některým ze znaků \"01ANan\"\n"
                    + "Zkuste odpovědět znovu.");
            }
            if ("0Nn".indexOf(answer) != -1) {
                break; // Výskok z vnějšího cyklu               //---------->
            }
            System.out.println("\nDobře, zahrajeme si ještě jednou.\n");
        }
        System.out.println("\nJeště jednou děkuji za hru.\nNa shledanou.");
    }


    /***************************************************************************
     * Vrátí string popisující základní informace o aktuálním stavy hry.
     *
     * @param game Hra, jejíž stav popisujeme
     * @return Požadovaný popis aktuálního stavu zadané hry
     */
    static String currentState(IGame game) {
        IWorld world = game.world();
        IPlace place = world.currentPlace();
        return   "Aktuální prostor:    " + place
             + "\nSousedé prostoru:    " + place.neighbors()
             + "\nPředměty v prostoru: " + place.items()
             + "\nPředměty v batohu:   " + game.bag().items()
             + "\n";
    }


    /** Soukromý konstruktor blokující vytváření istancí. */
    private Main() {}
}
