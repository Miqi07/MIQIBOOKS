package game77.ck1l_user_io;
// Příliš žluťoučký kůň úpěl ďábelské ó - PŘÍLIŠ ŽLUŤOUČKÝ KŮŇ ÚPĚL ĎÁBELSKÉ Ó
// J:/77_JAVA/game77/ck1l_user_io/PrimitiveGUI.java

import javax.swing.JOptionPane;

import static javax.swing.JOptionPane.showInputDialog;
import static javax.swing.JOptionPane.showMessageDialog;
import static javax.swing.JOptionPane.showConfirmDialog;


/********************************************************************************
 * Třída {@code Console} definuje definuje komunikační objekt
 * komunikující s uživatelem prostřednictvím standardního vstupu a výstupu.
 */
public   class PrimitiveGUI
    implements IUI
{
    /** Jediná instance této třídy - jedináček. */
    private static final PrimitiveGUI SINGLETON = new PrimitiveGUI();


    /***************************************************************************
     * Tovární metoda vracející odkaz na jedinou instanci.
     *
     * @return Požadovaný odkaz
     */
    public static PrimitiveGUI get() { return SINGLETON; }


    /***************************************************************************
     * Soukromý konstruktor bránící volnému vytváření instancí.
     */
    private PrimitiveGUI() {}


    /***************************************************************************
     * Zobrazí uživateli odpověď hry a požádá jej o zadání dalšího příkazu.
     *
     * @param answer Zobrazovaná odpověď hry
     * @return Příkaz zadaný uživatelem
     */
    @Override
    public String getCommand(String answer) {
        String command = showInputDialog(answer);
        if (command == null) { return ""; }
        return command;
    }


    /***************************************************************************
     * Zobrazí zadaný string -- většinou odpověď hry.
     *
     * @param answer Zobrazovaný string
     */
    public void showAnswer(String answer) {
        showMessageDialog(null, answer);
    }


    /***************************************************************************
     * Zeptá se uživatele a očekává odpověď ANO/NE, nebo její ekvivalent.
     *
     * @param question Pokládaná otázka
     * @return Odpověď uživatele jako logická hodnota
     */
    public boolean askQuestion(String question) {
        int answer = showConfirmDialog(null, question);
        return answer == JOptionPane.YES_OPTION;
    }

}
