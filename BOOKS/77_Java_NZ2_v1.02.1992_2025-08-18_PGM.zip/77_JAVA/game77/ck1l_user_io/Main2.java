package game77.ck1l_user_io;
// Příliš žluťoučký kůň úpěl ďábelské ó - PŘÍLIŠ ŽLUŤOUČKÝ KŮŇ ÚPĚL ĎÁBELSKÉ Ó
// J:/77_JAVA/game77/ck1l_user_io/Main.java

import game77.api.IGame;
import game77.api.IPlace;
import game77.api.IWorld;

import java.util.function.Supplier;


/*******************************************************************************
 * Třída {@code Main} je hlavní třídou aplikace s demonstrační hrou.
 */
public class Main2
{
    /***************************************************************************
     * Metoda spouštěnící celou aplikaci.
     *
     * @param args Argumenty příkazového řádku
     */
    public static void main(String[] args) {
//        IUI        ui = Console.get();
        IUI        ui = PrimitiveGUI.get();
        IGame    game = new game77.ck1k_whole.Portal().game();
        boolean state = true;   //Budeme-li chtít vypisování aktuálního stavu
        Supplier<String> details = (state ? () -> currentState(game)
                                          : () -> "");
        multirun(game, details, ui);
    }


    /***************************************************************************
     * Spustí hru a umožní uživateli ji odehrát.
     *
     * @param game Spouštěná hra
     */
    private static void run(IGame game, Supplier<String> details, IUI ui) {
        String  command = "";
        for(;;) {
            String answer = game.executeCommand(command);
            if (! game.isActive()) {
                ui.showAnswer(answer);  //Už bez přidaných informaci
                return;
            }
            command =  ui.getCommand(answer + details.get());
        }
    }


    /***************************************************************************
     * Spustí hru, umožní uživateli ji odehrát a po skončení hry se s ním
     * domluví, bude-li končit nebo si che hru zahrát znovu.
     *
     * @param game Spouštěná hra
     */
    public static void multirun(IGame game, Supplier<String> details, IUI ui) {
        for(;;) {
            run(game, details, ui);      //Spuštění jednoho běhu hry
            boolean answer = ui.askQuestion("Chcete si zahrát ještě jednou?");
            if (! answer) {
                ui.showAnswer("Ještě jednou děkuji za hru.\nNa shledanou.\n");
                return;
            }
            ui.showAnswer("Dobře, zahrajeme si ještě jednou.");
        }
    }


    /***************************************************************************
     * Vrátí string popisující základní informace o aktuálním stavy hry.
     *
     * @param game Hra, jejíž stav popisujeme
     * @return Požadovaný popis aktuálního stavu zadané hry
     */
    static String currentState(IGame game) {
        IWorld world = game.world();
        IPlace place = world.currentPlace();
        return "\n------------------------------"
             + "\nAktuální prostor:    " + place
             + "\nSousedé prostoru:    " + place.neighbors()
             + "\nPředměty v prostoru: " + place.items()
             + "\nPředměty v batohu:   " + game.bag().items()
             + "\n";
    }


    /** Soukromý konstruktor blokující vytváření istancí. */
    private Main2() {}
}
