// Příliš žluťoučký kůň úpěl ďábelské ó - PŘÍLIŠ ŽLUŤOUČKÝ KŮŇ ÚPĚL ĎÁBELSKÉ Ó
// J:/77_JAVA/game77/ck1g_triplet/package-info.java


/*******************************************************************************
 * Balíček {@code game77.ck1g_triplet} je demonstrační balíček,
 * jenž vedle scénáře HAPPY definuje i scénář  BASIC a MISTAKES.
 */
package game77.ck1g_triplet;

