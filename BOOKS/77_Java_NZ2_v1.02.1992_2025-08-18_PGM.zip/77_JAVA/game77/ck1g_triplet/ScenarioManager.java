package game77.ck1g_triplet;
// Příliš žluťoučký kůň úpěl ďábelské ó - PŘÍLIŠ ŽLUŤOUČKÝ KŮŇ ÚPĚL ĎÁBELSKÉ Ó
// J:/77_JAVA/game77/ck1g_triplet/ScenarioManager.java

import game77.api.Scenario;
import game77.api.ScenarioStep;

import java.util.List;

import static game77.api.TypeOfScenario.*;
import static game77.api.TypeOfStep.*;



/*******************************************************************************
 * Třída {@code ScenarioManager} definuje sadu scénářů,
 * podle nichž je možno hrát (anebo testovat) hru, pro niž jsou určeny -
 * v tomoto případě hru inspirovanou pohádkou o Červené Karkulce.
 * Aby bylo možno jednotlivé scénáře od sebe odlišit,
 * je každý pojmenován a má přiřazen typ, podle které lze blíže určit,
 * k čemu je možno daný scénář použít.
 * Scénáře jsou definovány jako posloupnosti kroků.
 * Tato verze obsahuje vedle scénáře HAPPY ještě scénář BASIC
 * definující posloupnost kroků prověřující všechny povinné akce.
 */
public class ScenarioManager
{
/** Předpony názvů proměnných s texty používanými ve scénářích i kódu:
 *  an - answer         - Zpráva hry jako odpověď na příkaz
 *  pl - place          - Název prostoru hry
 *  ds - description    - Stručný popis aktuálního prostoru
 *  nb - neighbors      - Názvy počátečních sousedů prostoru
 *  ip - items in place - Názvy sady h-objektů v prostoru
 *  ib - items in bag   - Názvy sady h-objektů v batohu
 *  in - item name      - Název h-objektu
 *  er - error          - Odpověď na chybně zadaný příkaz
 */
static final String SUBJECT, anWELCOME,          //EMPTYsa = Empty String array,
    plHOUSE,   dsHOUSE,   nbHOUSE[],    ipHOUSE[],  EMPTYsa[],
    plWOOD,    dsWOOD,    nbWOOD[],     ipWOOD[],   ibWOOD[],
    plFOREST,  dsFOREST,  nbFOREST[],   ipFOREST[],
//    plCAVE,    dsCAVE,    nbCAVE[],     ipCAVE[],
//    plCOTTAGE, dsCOTTAGE, nbCOTTAGE[],  ipCOTTAGE[],
    ipSTART[], bgSTART[], ipBAG_FULL[], ibBAG_FULL[],
    anGOTO, anTAKE, anPUT, anHELP, anSTOP,
    anNOT_START, anEMPTY, anUNKNOWN,
    anMOVE_WA, anTAKE_WA, anPUT_DOWN_WA,
    anBAD_NEIGHBOR, anBAD_ITEM, anUNMOVABLE, anBAG_FULL, anNOT_IN_BAG;

/** Definované scénáře. */
private static final Scenario BASIC, MISTAKES, HAPPY;

/** Startovní krok. */
public static final ScenarioStep START_STEP;

// Statický inicializační blok umožňující inicializaci statických konstant
static {

// Téma vyvíjené hry používané ve startovním kroku a v nápovědě
SUBJECT = """
        Toto je příběh o Červené Karkulce, babičce a vlkovi.
        Svými příkazy řídíte Karkulku, aby donesla bábovku a víno
        babičce v chaloupce za temným lesem.
        Karkulka musí nejprve v domečku vložit do košíku víno a bábovku,
        a potom přejít přes les a temný les do chaloupky.
        Když přijde do chaloupky, měla by položit dárky, vzbudit babičku,
        pozdravit a popřát jí k narozeninám.
        Jste-li dobrodružné typy, můžete to místo s babičkou provést
        s vlkem, který spí v temném lese.
        """;

// Společný startovní krok všech scénářů
START_STEP = new ScenarioStep(tsSTART, "",
        anWELCOME = ("Vítejte!\n" + SUBJECT
      + "\nNebudete-li si vědět rady, zadejte znak ?, jenž zobrazí nápovědu.")
        ,
        plHOUSE = "Domeček",                             //Aktuální prostor
        nbHOUSE = new String[] { plWOOD = "Les" },       //Sousedé
        ipHOUSE = new String[] { "Bábovka", "Víno", "Stůl", "Panenka", },
        EMPTYsa = new String[] { }                       //H-objekty v batohu
    );

// Další atributy neinicializované ve scénářích:
    dsHOUSE = "Domeček, kde bydlí Karkulka";

////////////////////////////////////////////////////////////////////////////////
BASIC = new Scenario(scBASIC,
    START_STEP,
    new ScenarioStep(1, tsGOTO, "Jdi Les",
        (anGOTO = "Karkulka se přesunula do prostoru:\n")
      + (dsWOOD = "Les s jahodami, malinami a pramenem vody"),
        plWOOD,                                          //Aktuální prostor
        nbWOOD = new String[] { "Domeček", "Temný_les" },//Sousedé
        ipWOOD = new String[] { "Maliny", "Jahody", "Studánka", },
        EMPTYsa                                          //H-objekty v batohu
    ),
    new ScenarioStep(tsTAKE, "Vezmi Maliny",
        (anTAKE = "Karkulka dala do košíku objekt: ") + "Maliny",
        plWOOD,                                          //Aktuální prostor
        nbWOOD,                                          //Sousedé
        ipSTART = new String[] { "Jahody", "Studánka", },//H-obj. v prostoru
        bgSTART = new String[] { "Maliny", }             //H-objekty v batohu
    ),
    new ScenarioStep(tsPUT_DOWN, "Polož Maliny",
        (anPUT = "Karkulka vyndala z košíku objekt: ") + "Maliny",
        plWOOD, nbWOOD, ipWOOD, EMPTYsa
    ),
    new ScenarioStep(tsTAKE, "Vezmi Maliny",
        anTAKE + "Maliny",
        plWOOD, nbWOOD, ipSTART, bgSTART
    ),
    new ScenarioStep(tsHELP, "?",
        anHELP = SUBJECT + "\nMůžete zadat tyto příkazy:\n",
        plWOOD, nbWOOD, ipSTART, bgSTART
    ),
    new ScenarioStep(tsEND, "konec",
        anSTOP = "Ukončili jste hru.\nDěkujeme, že jste si zahráli.",
        plWOOD, nbWOOD, ipSTART, bgSTART
    )
);


////////////////////////////////////////////////////////////////////////////////
MISTAKES = new Scenario(scMISTAKES,
    new ScenarioStep(-1, tsNOT_START, "Start",
        anNOT_START = "\nPrvním příkazem není startovací příkaz." +
        "\nHru, která neběží, lze spustit pouze startovacím příkazem.\n",
        "", EMPTYsa, EMPTYsa, EMPTYsa   //Před startem na stavu nezáleží
    ),
    START_STEP,
    new ScenarioStep(1, tsEMPTY, "",
        anEMPTY = "Prázdný příkaz lze použít pouze pro start hry",
        plHOUSE, nbHOUSE, ipHOUSE, EMPTYsa
    ),
    new ScenarioStep(tsUNKNOWN, "maso",
        (anUNKNOWN = "Tento příkaz neznám: ") + "maso",
        plHOUSE, nbHOUSE, ipHOUSE, EMPTYsa
    ),
    new ScenarioStep(tsMOVE_WA, "jdi",
        anMOVE_WA = "Nevím, kam mám jít.\n"
      + "Je třeba zadat jméno cílového prostoru.",
        plHOUSE, nbHOUSE, ipHOUSE, EMPTYsa
    ),
    new ScenarioStep(tsTAKE_WA, "vezmi",
        anTAKE_WA = "Nevím, co mám zvednout.\n"
      + "Je třeba zadat jméno zvedaného objektu.",
        plHOUSE, nbHOUSE, ipHOUSE, EMPTYsa
    ),
    new ScenarioStep(tsPUT_DOWN_WA, "polož",
        anPUT_DOWN_WA = "Nevím, co mám položit.\n"
      + "Je třeba zadat jméno pokládaného objektu.",
        plHOUSE, nbHOUSE, ipHOUSE, EMPTYsa
    ),
    new ScenarioStep(tsBAD_NEIGHBOR, "jdi do_háje",
        (anBAD_NEIGHBOR = "Do zadaného prostoru se odsud jít nedá: ") + "do_háje",
        plHOUSE, nbHOUSE, ipHOUSE, EMPTYsa
    ),
    new ScenarioStep(tsBAD_ITEM, "vezmi whisky",
        (anBAD_ITEM = "Zadaný objekt v prostoru není: ") + "whisky",
        plHOUSE, nbHOUSE, ipHOUSE, EMPTYsa
    ),
    new ScenarioStep(tsUNMOVABLE, "vezmi stůl",
        (anUNMOVABLE = "Zadaný objekt není možné zvednout: ") + "stůl",
        plHOUSE, nbHOUSE, ipHOUSE, EMPTYsa
    ),
    new ScenarioStep(tsTAKE, "vezmi víno",
        anTAKE + "víno",
        plHOUSE, nbHOUSE,
        new String[] { "Bábovka", "Stůl", "Panenka", }, // H-obj. v prostoru
        new String[] { "Víno", }                        // H-objekty v batohu
    )
    ,
    new ScenarioStep(tsTAKE, "vezmi bábovka",
        anTAKE + "Bábovka",
        plHOUSE, nbHOUSE,
        ipBAG_FULL = new String[] { "Stůl", "Panenka", }, // H-obj. v prostoru
        ibBAG_FULL = new String[] { "Bábovka", "Víno", }  // H-objekty v batohu
    ),
    new ScenarioStep(tsBAG_FULL, "vezmi panenka",
        (anBAG_FULL = "Zadaný objekt se už do košíku nevejde: ") + "panenka",
        plHOUSE, nbHOUSE, ipBAG_FULL, ibBAG_FULL
    ),
    new ScenarioStep(tsNOT_IN_BAG, "polož panenka",
        (anNOT_IN_BAG = "Zadaný objekt v košíku není: ") + "panenka",
        plHOUSE, nbHOUSE, ipBAG_FULL, ibBAG_FULL
    ),
    new ScenarioStep(tsEND, "konec",
        anSTOP,
        plHOUSE, nbHOUSE, ipBAG_FULL, ibBAG_FULL
    )
);


////////////////////////////////////////////////////////////////////////////////
HAPPY = new Scenario(scHAPPY,
    START_STEP,
    new ScenarioStep(1, tsTAKE, "Vezmi víno",
        anTAKE + "Víno",
        plHOUSE, nbHOUSE,
        new String[] { "Bábovka", "Stůl", "Panenka", }, // H-obj. v prostoru
        new String[] { "Víno", }                        // H-objekty v batohu
    ),
    new ScenarioStep(tsTAKE, "Vezmi Bábovka",
        anTAKE + "Bábovka",
        plHOUSE, nbHOUSE,
        new String[] { "Stůl", "Panenka", },            // H-obj. v prostoru
        ibWOOD = new String[] { "Bábovka", "Víno", }    // H-objekty v batohu
    ),
    new ScenarioStep(tsGOTO, "Jdi Les",
        anGOTO + dsWOOD,
        plWOOD, nbWOOD, ipWOOD,
        new String[] { "Bábovka", "Víno",  }            // H-objekty v batohu
    ),
    new ScenarioStep(tsGOTO, "Jdi Temný_les",
        anGOTO
      + (dsFOREST= "Temný_les s jeskyní a číhajícím vlkem"),
        plFOREST = "Temný_les",                         // Aktuální prostor
        nbFOREST = new String[] { "Les", "Jeskyně", "Chaloupka", },
        ipFOREST = new String[] { "Vlk", },             // H-obj. v prostoru
        ibWOOD                                          // H-objekty v batohu
    ),
    new ScenarioStep(tsGOTO, "Jdi Chaloupka",
        "Karkulka se přesunula do prostoru:\n"
      + "Chaloupka, kde bydlí babička",
        "Chaloupka",                                    // Aktuální prostor
        new String[] { "Temný_les" },                   // Sousedé
        new String[] { "Postel", "Stůl", "Babička", },  // H-obj. v prostoru
        ibWOOD                                          // H-objekty v batohu
    ),
    new ScenarioStep(tsPUT_DOWN, "Polož Bábovka",
        "Karkulka vyndala z košíku objekt: Bábovka",
        "Chaloupka",                                    // Aktuální prostor
        new String[] { "Temný_les" },                   // Sousedé
        new String[] { "Postel", "Stůl", "Babička", "Bábovka", },
        new String[] { "Víno", }                        // H-objekty v batohu
    ),
    new ScenarioStep(tsPUT_DOWN, "Polož Víno",
        "Karkulka vyndala z košíku objekt: Víno",
        "Chaloupka",                                    // Aktuální prostor
        new String[] { "Temný_les" },                   // Sousedé
        new String[] { "Postel", "Stůl", "Babička", "Bábovka", "Víno", },
        new String[] { }                                // H-objekty v batohu
    ),
    new ScenarioStep(tsNS_1, "Probuď babička",
        "Karkulka probudila objekt Babička",
        "Chaloupka",                                    // Aktuální prostor
        new String[] { "Temný_les" },                   // Sousedé
        new String[] { "Postel", "Stůl", "Babička", "Bábovka", "Víno", },
        new String[] { }                                // H-objekty v batohu
    ),
    new ScenarioStep(tsNS_0, "Pozdrav",
        "Karkulka pozdravila objekt Babička",
        "Chaloupka",                                    // Aktuální prostor
        new String[] { "Temný_les" },                   // Sousedé
        new String[] { "Postel", "Stůl", "Babička", "Bábovka", "Víno", },
        new String[] { }                                // H-objekty v batohu
    ),
    new ScenarioStep(tsSUCCESS, "Popřej",
        "Karkulka popřála objektu babička vše nejlepší k narozeninám\n"
      + "Úspěšně jste ukončili hru.\n"
      + "Děkujeme, že jste si zahráli.",
        "Chaloupka",                                    // Aktuální prostor
        new String[] { "Temný_les" },                   // Sousedé
        new String[] { "Postel", "Stůl", "Babička", "Bábovka", "Víno", },
        new String[] { }                                // H-objekty v batohu
    )
);

} //Konec statického inicializačního bloku



//===== CLASS (STATIC) GETTERS AND SETTERS =====================================

    /***************************************************************************
     * Vrátí seznam definovaných scénářů.
     *
     * @return Seznam spravovaných scénářů
     */
    public static List<Scenario> scenarios()
    {
        return List.of(HAPPY, BASIC, MISTAKES);
    }


//===== INSTANCE INITIALIZERS (CONSTRUCTORS) ===================================

    private ScenarioManager() {}

}
