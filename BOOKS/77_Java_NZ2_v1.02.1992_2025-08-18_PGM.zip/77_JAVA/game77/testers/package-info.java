// Příliš žluťoučký kůň úpěl ďábelské ó - PŘÍLIŠ ŽLUŤOUČKÝ KŮŇ ÚPĚL ĎÁBELSKÉ Ó
// J:/77_JAVA/game77/testers/package-info.java


/*******************************************************************************
 * Balíček {@code eu.pedu.adv21s.api} obsahuje sadu datových typů
 * definující závazné společné aplikační programové rozhraní
 * pro textové konverzační hry vyvíjené jako semestrální práce.
 */
package game77.testers;

