/* Saved in UTF-8 codepage: Příliš žluťoučký kůň úpěl ďábelské ódy. ÷ × ¤
 * Check: «Stereotype», Section mark-§, Copyright-©, Alpha-α, Beta-β, Smile-☺
 */
package game77.testers;

import game77.api.TypeOfScenario;

import java.util.Arrays;



/*******************************************************************************
 * Instance výčtového typu {@code Level} reprezentují úrovně testování.
 */
public enum Level
{
//===== VALUES OF THE ENUMERATION TYPE =========================================

    /** Portál s identifikací autora a přístupovými metodami.   0_ */
    PORTAL      (0),
    /** Definuje se výchozí šťastný scénář.                     1a */
    HAPPY       (1),
    /** Dva kompletní scénáře: HAPPY a BASIC.                   2b */
    DUPLET      (2),
    /** Přítomnost základních požadovaných typů a metod.        3c */
    ARCHITECTURE(2),
    /** Hru se podaří úspěšně odstartovat a ukočit.             4d */
    START       (2, 1),
    /** Hra úspěšně vybuduje svůj svět.                         5e */
    WORLD       (2, 1),
    /** Zprovoznění základních akcí při korektním zadání.       6f */
    BASIC       (2, 1, 1),
    /** Přidání scénáře MISTAKE.                                7g */
    TRIPLET     (3),
    /** Základní akce jsou navržené robustní.                   8h */
    MISTAKES    (3, 1, 1, 2),
    /** Zprovoznění běhu podle šťastného scénáře.               9i */
    RUNNING     (3, 0, 0, 2),
    /** Úprava scénáře HAPPY a přidání scénáře MISTAKE_NS.     10j */
    QUADRUPLET  (4),
    /** Úspěšné zprovoznění hry, všechny akce jsou robustní.   11k */
    WHOLE       (4, 0, 0, 2, 3),
    /** Test aplikace s nadstavbovými úpravami.                10j */
    MODIFIED    (4, 0, 0, 2, 3),
    /** Test upravené aplikace s dalším scénářem.              11k */
    EXTENDED    (5, 0, 0, 2, 3, 4),
    /** Test upravené aplikace s několika dalšími scénáři.     12l */
    FREE        (1, 0),
//    /** 4 základní scénáře včetně deklarací příznaků.           2b */
//    SCENARIOS   (2, 0),
    ;



//##############################################################################
//===== INSTANCE CONSTANTS (CONSTANT INSTANCE ATTRIBUTES/FIELDS) ===============

    /** Minimální požadovaný počet definovaných scénářů. */
    private int minScenarios;

    /** Posloupnost názvů scénářů, jak budou postupně zadávány. */
    private String[] testSequence;

    /** Posloupnost názvů scénářů, jak budou postupně zadávány. */
    private int[] testIndexes;



//##############################################################################
//===== INSTANCE INITIALIZERS (CONSTRUCTORS) ===================================

    /***************************************************************************
     * Vytvoří hladinu se zadaným minimálním požadovaným počtem definovaných
     * scénářů a posloupnost indexů scénářů, jak by měly být postupně zadávány.
     */
    private Level(int minScenarios, int... testSequence)
    {
        this.minScenarios = minScenarios;
        this.testIndexes  = testSequence;
        this.testSequence = new String[testSequence.length];
        int t = 0;
        for (int i : testSequence) {
            int v = TypeOfScenario.values().length;
            this.testSequence[t++] = TypeOfScenario.values()[i]
                                                   .requiredName();
        }
    }



//===== INSTANCE REMAINING NON-PRIVATE METHODS =================================

    /***************************************************************************
     * Vrátí posloupnost indexů scénářů, jak by měly být postupně zadávány.
     */
    public int minScenarios()
    {
        return minScenarios;
    }


    /***************************************************************************
     * Vrátí minimální požadovaný počet definovaných scénářů.
     */
    public String[] testSequence()
    {
        return Arrays.copyOf(testSequence, testSequence.length);
    }


    /***************************************************************************
     * Vrátí minimální požadovaný počet definovaných scénářů.
     */
    public int[] getTestIndexes()
    {
        return Arrays.copyOf(testIndexes, testIndexes.length);
    }


    /***************************************************************************
     * Vrátí minimální požadovaný počet definovaných scénářů.
     */
    public void setTestIndexes(int... sequence)
    {
        if (this != FREE) {
            throw new RuntimeException(
                    "\nNastavovat posloupnost testovacích scénářů \n" +
                    "je možno pouze pro hladinu FREE."
            );
        }
        minScenarios = 0;
        for (int i : sequence) {
            if (i > minScenarios) { minScenarios = i; }
        }
        minScenarios += 1;  //Aby se započítala nula
        testIndexes = Arrays.copyOf(sequence, sequence.length);
    }

}
