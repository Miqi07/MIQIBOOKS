package game77.testers.util;
/* Saved in UTF-8 codepage: Příliš žluťoučký kůň úpěl ďábelské ódy. ÷ × ¤ */



/*******************************************************************************
 * Instance třídy {@code FormatStrings} představují ...
 */
public class FormatStrings
{
//===== CLASS CONSTANTS (CONSTANT CLASS/STATIC ATTRIBUTES/FIELDS) ==============

    public static final char NL = '\n';

    public static final String

    LINE =
"-----------------------------------------------------------------------------",

    DOUBLELINE =
"=============================================================================",

    HASHES =
"#############################################################################",

    CIRCUMFLEXES =
"^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^",

    /** Oddělovač vypisovaný před vlastní chybovou zprávou. */
    BEFORE =
"VVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV",

    /** Oddělovač vypisovaný za vlastní chybovou zprávou. */
    AFTER =
"AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA",

    LINE_N   =        LINE + '\n',
    N_LINE   = '\n' + LINE,
    N_LINE_N = '\n' + LINE + '\n',
    LINE_ARG =        LINE + "%s\n",

    DOUBLELINE_N    =          DOUBLELINE + '\n',
    N_DOUBLELINE    =   '\n' + DOUBLELINE,
    N_DOUBLELINE_N  =   '\n' + DOUBLELINE + '\n',
    NN_DOUBLELINE   = "\n\n" + DOUBLELINE,
    NN_DOUBLELINE_NN= "\n\n" + DOUBLELINE + "\n\n",

    HASHES_N   =        HASHES + '\n',
    N_HASHES   = '\n' + HASHES,
    N_HASHES_N = '\n' + HASHES + '\n',

    CIRCUMFLEXES_N   =        CIRCUMFLEXES + '\n',
    N_CIRCUMFLEXES   = '\n' + CIRCUMFLEXES,
    N_CIRCUMFLEXES_N = '\n' + CIRCUMFLEXES + '\n',

    BEFORE_N    =        BEFORE + '\n',
    N_BEFORE    = '\n' + BEFORE,
    N_BEFORE_N  = '\n' + BEFORE + '\n',

    AFTER_N   =        AFTER + '\n',
    N_AFTER   = '\n' + AFTER,
    N_AFTER_N = '\n' + AFTER + '\n',

    EMPTY_STRING=""; //Abych nemusel přemýšlet nad čárkami



//===== CLASS VARIABLES (VARIABLE CLASS/STATIC ATTRIBUTES/FIELDS) ==============



//##############################################################################
//===== CLASS (STATIC) INITIALIZER (CLASS CONSTRUCTOR) =========================
//===== CLASS (STATIC) FACTORY METHODS =========================================
//===== CLASS (STATIC) GETTERS AND SETTERS =====================================
//===== CLASS (STATIC) REMAINING NON-PRIVATE METHODS ===========================

//===== CLASS (STATIC) PRIVATE AND AUXILIARY METHODS ===========================




//##############################################################################
//===== INSTANCE CONSTANTS (CONSTANT INSTANCE ATTRIBUTES/FIELDS) ===============
//===== INSTANCE VARIABLES (VARIABLE INSTANCE ATTRIBUTES/FIELDS) ===============



//##############################################################################
//===== INSTANCE INITIALIZERS (CONSTRUCTORS) ===================================

    /** Soukromý konstruktor zabraňující vytvoření instance.*/
    private FormatStrings() {}



//===== INSTANCE ABSTRACT METHODS ==============================================
//===== INSTANCE GETTERS AND SETTERS ===========================================
//===== INSTANCE REMAINING NON-PRIVATE METHODS =================================
//===== INSTANCE PRIVATE AND AUXILIARY METHODS =================================



//##############################################################################
//===== NESTED DATA TYPES ======================================================
}
