/* The file is saved in UTF-8 codepage.
 * Check: «Stereotype», Section mark-§, Copyright-©, Alpha-α, Beta-β, Smile-☺
 */
package game77.testers.util;



/*******************************************************************************
 * Knihovní třída {@code IndentingFormater} poskytuje metody
 * pro tisk využívající vhodné odsazování.
 */
public class IndentingFormater
{
//===== CLASS CONSTANTS (CONSTANT CLASS/STATIC ATTRIBUTES/FIELDS) ==============

    /** Mezery, z nichž se vybírá podřetězec vkládaný jako odsazení. */
    private static final String PLACES =
    "                                                                        ";



//===== CLASS VARIABLES (VARIABLE CLASS/STATIC ATTRIBUTES/FIELDS) ==============



//##############################################################################
//===== CLASS (STATIC) INITIALIZER (CLASS CONSTRUCTOR) =========================
//===== CLASS (STATIC) FACTORY METHODS =========================================
//===== CLASS (STATIC) GETTERS AND SETTERS =====================================
//===== CLASS (STATIC) REMAINING NON-PRIVATE METHODS ===========================

    /***************************************************************************
     * Metoda vrátí řetězec konstruovaný tak,
     * že za text obdržený v prvním parametru přidá text z druhého parametru,
     * avšak každé odřádkování tohoto textu upraví tak,
     * že začátek následujícího řádku začíná pod začátkem předchozího řádku
     * tohoto textu.
     *
     * @param title Úvodní text jehož délka definuje odsazení
     *              pokračovacích řádků dalšího parametru
     * @param text  Text odsazovaný podle délky předchozího parametru
     * @return Výsledný textový řetězec
     */
    public static String indent(String title, String text)
    {
        StringBuilder sb     = new StringBuilder(title);
        String        indent = PLACES.substring(0, title.length());
        final int     limit  = text.length();
        for (int i = 0;   i < limit;   i++) {
            char c = text.charAt(i);
            sb.append(c);
            if (c == '\n') {
                sb.append(indent);
            }
        }
        return sb.toString();
    }





//===== CLASS (STATIC) PRIVATE AND AUXILIARY METHODS ===========================




//##############################################################################
//===== INSTANCE CONSTANTS (CONSTANT INSTANCE ATTRIBUTES/FIELDS) ===============
//===== INSTANCE VARIABLES (VARIABLE INSTANCE ATTRIBUTES/FIELDS) ===============



//##############################################################################
//===== INSTANCE INITIALIZERS (CONSTRUCTORS) ===================================

    /***************************************************************************
     * Soukromý konstruktor zabraňující vytvoření instance.
     */
    private IndentingFormater()
    {
    }



//===== INSTANCE ABSTRACT METHODS ==============================================
//===== INSTANCE GETTERS AND SETTERS ===========================================
//===== INSTANCE REMAINING NON-PRIVATE METHODS =================================
//===== INSTANCE PRIVATE AND AUXILIARY METHODS =================================



//##############################################################################
//===== NESTED DATA TYPES ======================================================
}
