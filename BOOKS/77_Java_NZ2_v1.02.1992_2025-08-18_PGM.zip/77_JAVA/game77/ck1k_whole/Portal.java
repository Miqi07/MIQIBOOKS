package game77.ck1k_whole;
// Příliš žluťoučký kůň úpěl ďábelské ó - PŘÍLIŠ ŽLUŤOUČKÝ KŮŇ ÚPĚL ĎÁBELSKÉ Ó
// J:/77_JAVA/game77/ck1k_whole/Portal.java

import game77.api.IGame;
import game77.api.IPortal;
import game77.api.Scenario;

import game77.testers.Level;
import game77.testers.PortalTester;

import java.util.List;



/*******************************************************************************
 * Instance třídy {@code _Portal} představují tovární objekty,
 * které jsou schopny na požádání dodat informace o autorovi
 * a odkazy na instance klíčových objektů aplikace,
 * konkrétně aktuální hry, jejích scénářů.
 */
public   class Portal
    implements IPortal
{
//##############################################################################
//===== INSTANCE METHODS =======================================================
/////// Identifikace autora/autorky celého balíčku

    /***************************************************************************
     * Vrátí jméno autora/autorky programu ve formátu <b>PŘÍJMENÍ Křestní</b>,
     * zapsané VELKÝMI PÍSMENY v jeho rodném jazyce.
     *
     * @return Jméno autora/autorky programu v jeho/jejím rodném jazyce
     */
    @Override
    public String authorNativeName()
    {
        return "CELÁ Hra";
    }


    /***************************************************************************
     * Vrátí jméno autora/autorky programu ve formátu <b>PŘÍJMENÍ Křestní</b>,
     * tj. nejprve příjmení psané velkými písmeny a za ním křestní jméno,
     * u nějž bude velké pouze první písmeno a ostatní písmena budou malá.
     * Má-li autor programu více křestních jmen, může je uvést všechna.
     *
     * @return Jméno autora/autorky programu ve tvaru PŘÍJMENÍ Křestní
     */
    @Override
    public String authorName()
    {
        return "WHOLE Game";
    }


    /***************************************************************************
     * Vrátí identifikační řetězec autora/autorky programu
     * zapsaný VELKÝMI PÍSMENY.
     * Tímto řetězcem bývá většinou login do informačního systému školy.
     *
     * @return Identifikační řetězec autora/autorky programu
     */
    @Override
    public String authorID()
    {
        return "CK1K";
    }



//##############################################################################
//===== INSTANCE METHODS =======================================================
/////// Metody vracející odkazy na klíčové objekty

    /***************************************************************************
     * Vrátí seznam definovaných scénářů.
     * <ul>
     *   <li>
     *     Scénářem s indexem 0 musí být základní úspěšný scénář dané hry
     *     definující možný postup vedoucí k úspěšnému ukončení hry.<br>
     *     &nbsp;</li>
     *   <li>
     *     Scénářem s indexem 1 musí být základní povinný scénář, jenž definuje
     *     postup, při němž se demonstruje reakce na korektně zadané příkazy
     *     vyvolávající některou ze základní šestice povinných akcí.<br>
     *     &nbsp;</li>
     *   <li>
     *     Scénářem s indexem 2 musí být základní chybový scénář
     *     definující reakce hry na všechny možné uživatelské chyby
     *     při aktivaci některé ze základní šestice povinných akcí.<br>
     *     &nbsp;</li>
     *   <li>
     *     Scénářem s indexem 3 musí být nadstavbový chybový scénář
     *     definující reakce hry na všechny běžné uživatelské chyby
     *     specifikující reakce hry na možné uživatelské chyby
     *     při aktivaci některé rozšiřujících akcí.<br>
     *     &nbsp;</li>
     * </ul>
     * Výše uvedeným scénářům budou při jejich vytvářený automaticky
     * přiděleny předem definované názvy.
     * Názvy a účely dalších scénářů jsou již na libovůli autora.<br>
     *
     * @return Seznam spravovaných scénářů
     */
    @Override
    public List<Scenario> scenarios()
    {
        return ScenarioManager.scenarios();
    }


    /***************************************************************************
     * Vrátí odkaz na (jedinou) instanci textové verze hry;
     * dokud ještě hra neexistuje, vyhazuje po zavolání výjimku
     * {@link UnsupportedOperationException}.
     *
     * @return Požadovaný odkaz
     * @throws UnsupportedOperationException
     *         Potomek metodu korektně nepřebil
     */
    @Override
    public IGame game()
    {
        return Game.get();
    }


//##############################################################################
//== MAIN METHOD ===============================================================

//Definované etapy vývoje - etapa určuje, co se testuje:
//HAPPY       = 1 #a Definuje se výchozí šťastný scénář
//DUPLET      = 2 #b Dva kompletní scénáře: HAPPY a BASIC
//ARCHITECTURE= 3 #c Přítomnost požadovaných objektů a metod
//START       = 4 #d Hra úspěšně odstartuje
//WORLD       = 5 #e Hra úspěšně vybuduje svůj svět
//BASIC       = 6 #f Zprovoznění základních akcí při korektním zadání
//TRIPLET     = 7 #g Přidání scénáře MISTAKE
//MISTAKES    = 8 #h Základní akce jsou navržené robustní
//RUNNING     = 9 #i Zprovoznění běhu podle šťastného scénáře
//QUADRUPLET  =10 #j Úprava scénáře HAPPY a přidání scénáře MISTAKE_NS
//WHOLE       =11 #k Úspěšné zprovoznění hry, všechny akce jsou robustní

    /***************************************************************************
     * Metoda testuje danou hladinu rozpracovanosti aplikace,
     * zde schopnost odstartování hry a poskytnout korektní informace
     * o aktuálním stavu světa hry.
     *
     * @param args Parametry příkazového řádku
     */
    public static void main(String[] args)
    {
        PortalTester.VERBOSE = false;   //Nepotřebujeme podrobné výpisy
        var portal = new Portal();
        var tester = new PortalTester(portal, Level.WHOLE);
        tester.test();
    }
}
