package game77.api;
// Příliš žluťoučký kůň úpěl ďábelské ó - PŘÍLIŠ ŽLUŤOUČKÝ KŮŇ ÚPĚL ĎÁBELSKÉ Ó
// J:/77_JAVA/game77/api/IAction.java

/*******************************************************************************
 * Instance interfejsu {@code IAction}
 * mají na starosti interpretaci příkazů zadávaných uživatelem hrajícím hru.
 * Název spouštěné akce je první slovo zadávaného příkazu;
 * další slova pak jsou interpretována jako argumenty.
 * <p>
 * Lze ale definovat i akci, která odstartuje konverzaci
 * (např. s osobou přítomnou v místnosti) a tím přepne systém do režimu,
 * v němž se zadávané texty neinterpretují jako příkazy,
 * ale předávají se hře, nejvýše nastavují nějaký vnitřní stav,
 * a to až do chvíle, kdy bude rozhovor ukončen, a hra se přepne zpět
 * do režimu klasických příkazů.
 */
public interface IAction
         extends INamed
{
//===== ABSTRACT GETTERS AND SETTERS ===========================================

    /***************************************************************************
     * Vrátí popis akce s vysvětlením její funkce,
     * významu jednotlivých parametrů
     * a možností (resp. účelu) použití dané akce.
     * Tento popis slouží jako nápověda k použití dané akce.
     *
     * @return Popis akce
     */
    //@Override
    public String description()
    ;



//===== REMAINING ABSTRACT METHODS =============================================

    /***************************************************************************
     * Metoda realizující reakci hry na zadání daného příkazu.
     * Předávané pole je vždy neprázdné,
     * protože jeho nultý prvek je zadaný název vyvolaného příkazu.
     * Počet argumentů je závislý na konkrétním příkazu,
     * např. příkazy <i>konec</i> a <i>nápověda</i> nemají parametry,
     * příkazy <i>jdi</i> a <i>seber</i> očekávají zadání jednoho argumentu,
     * příkaz <i>použij</i> muže mít dva argumenty atd.
     *
     * @param arguments Parametry příkazu;
     *                  jejich celkový počet muže byt pro každý příkaz jiný,
     *                  ale nultý prvek vždy obsahuje název příkazu
     * @return Text zprávy vypsané po provedeni příkazu
     */
    //@Override
    public String execute(String... arguments)
    ;



//===== EMBEDDED DATA TYPES ====================================================

    /***************************************************************************
     * Funkční interfejs implementovaný lambda-výrazy definujícími
     * reakce na zadané příkazy.
     */
    @FunctionalInterface
    interface ICommand
    {
        /***********************************************************************
         * Obdrží v argumentech jednotlivá slova zadaného příkazu
         * a vrátí odpověď hry.
         *
         * @param args Slova zadaného příkazu
         * @return  Odpověď hry na zadaný příkaz
         */
        String execute(String... args);
    }



    /***************************************************************************
     * Funkční interfejs implementovaný testovacími funkcemi prověřujícími
     * vykonatelnost pomocných akcí.
     */
    @FunctionalInterface
    interface ITest
    {
        /***********************************************************************
         * Obdrží v argumentech jednotlivá slova zadaného příkazu
         * a prověří, jestli je splněna podmínka pro úspěšné provedení
         * zadané akce.
         *
         * @param args Slova zadaného příkazu
         * @return  Zda příslušná nutná podmínka platí
         */
        boolean test(String... args);
    }

}
