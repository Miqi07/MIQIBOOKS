package game77.api;
// Příliš žluťoučký kůň úpěl ďábelské ó - PŘÍLIŠ ŽLUŤOUČKÝ KŮŇ ÚPĚL ĎÁBELSKÉ Ó
// J:/77_JAVA/game77/api/IGame.java

import java.util.List;
import java.util.Map;


/*******************************************************************************
 * Instance interfejsu {@code IGame} má na starosti řízení hry
 * a komunikaci s uživatelským rozhraním.
 * Je schopna reagovat na zadávané příkazy a poskytovat informace
 * o průběžném stavu hry a jejích součástí.
 * <p>
 * <b>Hra musí být definována jako jedináček (singleton)</b>
 * a kromě metod deklarovaných v tomto interfejsu musí její třída definovat
 * statickou tovární metodu <b>{@code get()}</b>
 * vracející instanci tohoto jedináčka.<br>
 * Splnění této podmínky nemůže prověřit překladač,
 * ale prověří ji až následné testy hry.
 */
public interface IGame
{
//===== ABSTRACT GETTERS AND SETTERS ===========================================

    /***************************************************************************
     * Vrátí informaci o tom, je-li hra aktuálně spuštěná.
     * Spuštěnou hru není možno pustit znovu.
     * Chceme-li hru spustit znovu, musíme ji nejprve ukončit.
     *
     * @return Je-li hra spuštěná, vrátí {@code true},
     *         jinak vrátí {@code false}
     */
    //@Override
    public boolean isActive()
    ;


    /***************************************************************************
     * Vrátí odkaz na batoh, do nějž bude hráč ukládat sebrané objekty.
     *
     * @return Batoh, do nějž hráč ukládá sebrané objekty
     */
    //@Override
    public IBag bag()
    ;


    /***************************************************************************
     * Vrátí kolekci všech příkazů použitelných ve hře.
     *
     * @return Kolekce všech příkazů použitelných ve hře
     */
    //@Override
    public List<? extends IAction> allActions()
    ;


    /***************************************************************************
     * Vrátí odkaz na přepravku s názvy povinných příkazů, tj. příkazů pro
     * <ul>
     *   <li>přesun hráče do jiného prostoru,</li>
     *   <li>zvednutí objektu (odebrání z prostoru a vložení do batohu),</li>
     *   <li>položení objektu (odebrání z batohu a vložení do prostoru),</li>
     *   <li>vyvolání nápovědy,</li>
     *   <li>okamžité ukončení hry.</li>
     * </ul>
     *
     * @return Přepravka s názvy povinných příkazů
     */
    //@Override
    public BasicActions basicActions()
    ;


    /***************************************************************************
     * Vrátí odkaz na objekt reprezentující svět, v němž se hra odehrává.
     *
     * @return Svět, v němž se hra odehrává
     */
    //@Override
    public IWorld world()
    ;



//===== REMAINING ABSTRACT METHODS =============================================

    /***************************************************************************
     * Zpracuje zadaný příkaz a vrátí text zprávy pro uživatele.
     *
     * @param command Zadávaný příkaz
     * @return Textová odpověď hry na zadaný příkaz
     */
    //@Override
    public String executeCommand(String command)
    ;


    /***************************************************************************
     * Ukončí celou hru a uvolní alokované prostředky.
     * Zadáním prázdného příkazu lze následně spustit hru znovu.
     */
    //@Override
    public void stop()
    ;


//===== GENERAL DEFAULT METHODS ================================================


    /***************************************************************************
     * Vrátí odkaz na mapu obsahující aktuální stav příznaků
     * ovlivňujících proveditelnost nestandardních akcí.
     *
     * @return Požadovaná mapa
     */
    default
    //@Override
    public Map<String, Object> conditions()
    {
        throw new UnsupportedOperationException("\n"
                + "Není korektně definována metoda conditions()\n"
                + "vracející mapu příznaků a jejich hodnot");
    }


    /***************************************************************************
     * Vrátí odkaz na mapu testů ověřujících splnění podmínek
     * nutných pro provedení nestandardních akcí.
     *
     * @return Požadovaná mapa
     */
    default
    //@Override
    public Map<String, IAction.ITest> tests()
    {
        throw new UnsupportedOperationException("\n"
                + "Není korektně definována metoda tests()\n"
                + "vracející mapu názvů pomocných testů a odkazů na ně");
    }


    /***************************************************************************
     * Vrací string informující o aktuálním stavu hry.
     */
    default String state2string()
    {
        IPlace cp = world().currentPlace();
        String ret = "-".repeat(60)
            + "\nProstor:  " + cp
            + "\nSousedé:  " + cp.neighbors()
            + "\nPředměty: " + cp.items()
            + "\nBatoh:    " + bag().items()
            + "\nPříznaky: " + conditions()
            + "\nTesty  :  " + tests()
            + "\n" + "-".repeat(60) + "\n";
        return ret;

    }

}
