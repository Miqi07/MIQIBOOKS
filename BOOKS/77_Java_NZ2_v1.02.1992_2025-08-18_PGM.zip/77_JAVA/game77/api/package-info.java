// Příliš žluťoučký kůň úpěl ďábelské ó - PŘÍLIŠ ŽLUŤOUČKÝ KŮŇ ÚPĚL ĎÁBELSKÉ Ó
// J:/77_JAVA/game77/api/package-info.java


/*******************************************************************************
 * Balíček {@code game77.api} obsahuje sadu datových typů
 * definující závazné společné aplikační programové rozhraní
 * pro textové konverzační hry vyvíjené jako semestrální práce.
 */
package game77.api;

