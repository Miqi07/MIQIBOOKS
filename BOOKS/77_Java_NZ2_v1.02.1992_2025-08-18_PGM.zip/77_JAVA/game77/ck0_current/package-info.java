// Příliš žluťoučký kůň úpěl ďábelské ó - PŘÍLIŠ ŽLUŤOUČKÝ KŮŇ ÚPĚL ĎÁBELSKÉ Ó
// J:/77_JAVA/game77/ck0_current/package-info.java


/*******************************************************************************
 * Balíček {@code game77.ck0_current} obsahuje třídy z výchozí etapy projektu,
 * v níž je definován pouze portál a scénář HAPPY.
 */
package game77.ck0_current;

