package game77.ck1d_start;
// Příliš žluťoučký kůň úpěl ďábelské ó - PŘÍLIŠ ŽLUŤOUČKÝ KŮŇ ÚPĚL ĎÁBELSKÉ Ó
// J:/77_JAVA/game77/ck1d_start/Action.java

import game77.api.IAction;
import game77.api.IAction.ICommand;



/*******************************************************************************
 * Instance třídy {@code Action}
 * mají na starosti interpretaci příkazů zadávaných uživatelem hrajícím hru.
 * Název spouštěné akce je první slovo zadávaného příkazu;
 * další slova pak jsou interpretována jako argumenty.
 * <p>
 * Lze ale definovat i akci, která odstartuje konverzaci
 * (např. s osobou přítomnou v místnosti) a tím přepne systém do režimu,
 * v němž se zadávané texty neinterpretují jako příkazy,
 * ale předávají se hře, nejvýše nastavují nějaký vnitřní stav,
 * a to až do chvíle, kdy bude rozhovor ukončen, a hra se přepne zpět
 * do režimu klasických příkazů.
 */
public   class Action
       extends ANamed
    implements IAction
{
//===== CLASS/STATIC ATTRIBUTES/FIELDS =========================================

    static private boolean isActive = false;


//===== CLASS/STATIC METHODS ===================================================

    /***************************************************************************
     * Vrátí informaci o tom, je-li hra aktuálně spuštěná.
     *
     * @return Je-li spuštěná, vrátí {@code true}, jinak vrátí {@code false}
     */
    static public boolean isActive()
    {
        return isActive;
    }


    /***************************************************************************
     * Ukončí běh hry a uvolní případné alokované prostředky.
     */
    static public void stop()
    {
        isActive = false;
    }


    /***************************************************************************
     * Zpracuje zadaný příkaz a vrátí text zprávy pro uživatele.
     *
     * @param command Zadávaný příkaz
     * @return Textová odpověď hry na zadaný příkaz
     */
    static public String executeCommand(String command)
    {
        command = command.strip();  //Odebrání počátečních a koncových mezer
        if (command.isEmpty()) {
            return executeEmptyCommand();           //Start hry
        }
        else {
            return executeStandardCommand(command); //Běh hry
        }
    }


//===== CLASS (STATIC) PRIVATE AND AUXILIARY METHODS ===========================

    /***************************************************************************
     * Definuje reakci na prázdný příkaz.
     *
     * @return Uvítací text hry
     */
    private static String executeEmptyCommand()
    {
        isActive = true;
        initialize();
        return ScenarioManager.anWELCOME;
    }


    /***************************************************************************
     * Definuje reakci na neprázdný příkaz.
     *
     * @param command Slova zadávaného příkau
     * @return Odpověď hry
     */
    private static String executeStandardCommand(String command)
    {
        return "Tento příkaz neumím zpracovat: " + command;
    }


    /***************************************************************************
     * Inicializuje aplikaci při startu další hry.
     */
    private static void initialize()
    {
    }



//##############################################################################
//===== INSTANCE CONSTANTS (CONSTANT INSTANCE ATTRIBUTES/FIELDS) ===============

    /** Stručná charakteristika dané akce. */
    private final String description;

    /** Kód, který se má provést při zadání příslušného příkazu. */
    private final ICommand action;


//===== INSTANCE INITIALIZERS (CONSTRUCTORS) ===================================

    /***************************************************************************
     * Vytvoří novou akci se zadaným názvem, popisem a výkonným kódem.
     *
     * @param name          Název vytvářené akce
     * @param description   Popis akce pro nápovědu
     * @param action        Kód realizující danou akci
     */
    private Action(String name, ICommand action, String description)
    {
        super(name);
        this.action      = action;
        this.description = description;
    }


//===== INSTANCE GETTERS AND SETTERS ===========================================

    /***************************************************************************
     * Vrátí popis akce s vysvětlením její funkce,
     * významu jednotlivých parametrů
     * a možností (resp. účelu) použití dané akce.
     * Tento popis slouží jako nápověda k použití dané akce.
     *
     * @return Popis akce
     */
    @Override
    public String description()
    {
        return description;
    }


//===== INSTANCE REMAINING NON-PRIVATE METHODS =================================

    /***************************************************************************
     * Metoda realizující reakci hry na zadání daného příkazu.
     * Předávané pole je vždy neprázdné,
     * protože jeho nultý prvek je zadaný název vyvolaného příkazu.
     * Počet argumentů je závislý na konkrétním příkazu,
     * např. příkazy <i>konec</i> a <i>nápověda</i> nemají parametry,
     * příkazy <i>jdi</i> a <i>seber</i> očekávají zadání jednoho argumentu,
     * příkaz <i>použij</i> muže mít dva argumenty atd.
     *
     * @param arguments Zadané argumenty příkazu;
     *                  jejich celkový počet muže byt pro každý příkaz jiný,
     *                  ale nultý prvek vždy obsahuje název příkazu
     * @return Text zprávy vypsané po provedeni příkazu
     */
    @Override
    public String execute(String... arguments)
    {
        return action.execute(arguments);
    }
}
