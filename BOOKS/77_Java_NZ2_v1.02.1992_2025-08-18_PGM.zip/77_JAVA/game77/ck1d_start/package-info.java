// Příliš žluťoučký kůň úpěl ďábelské ó - PŘÍLIŠ ŽLUŤOUČKÝ KŮŇ ÚPĚL ĎÁBELSKÉ Ó
// J:/77_JAVA/game77/ck1d_start/package-info.java


/*******************************************************************************
 * Balíček {@code game77.ck1d_start} je demonstrační balíček,
 * do nějž jsou zkopíroány třídy z balíčku game77.ck1c_architecture
 * a následně upraveny tak, aby bylo možno hru korektně odstartovat.
 */
package game77.ck1d_start;

