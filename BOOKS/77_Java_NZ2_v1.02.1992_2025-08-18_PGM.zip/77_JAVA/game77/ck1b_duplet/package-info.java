// Příliš žluťoučký kůň úpěl ďábelské ó - PŘÍLIŠ ŽLUŤOUČKÝ KŮŇ ÚPĚL ĎÁBELSKÉ Ó
// J:/77_JAVA/game77/ck1b_duplet/package-info.java


/*******************************************************************************
 * Balíček {@code game77.ck1b_duplet} je balíček druhé etapy rozpracovanosti,
 * v níž je ke šťastnému scénáři (HAPPY) přidán ještě scénář BASIC.
 */
package game77.ck1b_duplet;

