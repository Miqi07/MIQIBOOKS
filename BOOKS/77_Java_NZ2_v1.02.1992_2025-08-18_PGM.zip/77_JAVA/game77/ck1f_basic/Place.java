package game77.ck1f_basic;
// Příliš žluťoučký kůň úpěl ďábelské ó - PŘÍLIŠ ŽLUŤOUČKÝ KŮŇ ÚPĚL ĎÁBELSKÉ Ó
// J:/77_JAVA/game77/ck1f_basic/Place.java

import game77.api.IPlace;

import java.util.ArrayList;
import java.util.List;


/*******************************************************************************
Instance třídy {@code Place} představují prostory ve hře.
Dosažení prostoru si můžeme představovat jako částečný cíl,
kterého se hráč ve hře snaží dosáhnout.
Prostory mohou být místnosti, planety, životní etapy atd.
Prostory mohou obsahovat různé h-objekty,
které mohou hráči pomoci v dosažení cíle hry.
Každý prostor zná své aktuální bezprostřední sousedy
a ví, jaké objekty se v něm v daném okamžiku nacházejí.
Sousedé daného prostoru i v něm se nacházející objekty
se mohou v průběhu hry měnit.
 */
public   class Place
       extends AItemContainer
    implements IPlace
{
    /** Stručná charakteristika daného prostoru. */
    private final String description;

    /** Názvy výchozích sousedů daného prostoru po startu hry. */
    private final List<String> initialNeighborNames;

    /** Seznam aktuálních sousedů daného prostoru v průběhu hry. */
    private List<Place> currentNeighbors;



    public Place(String name, String description,
                 String[]  initialNeighborNames,
                 String... initialItemNames)
    {
        super(name, initialItemNames);
        this.description          = description;
        this.initialNeighborNames = List.of(initialNeighborNames);
    }


    /***************************************************************************
     * Vrátí stručný popis daného prostoru.
     *
     * @return Stručný popis daného prostoru
     */
    @Override
    public String description()
    {
        return description;
    }


    /***************************************************************************
     * Vrátí kolekci sousedů daného prostoru, tj. kolekci prostorů,
     * do nichž je možno se z tohoto prostoru přesunout příkazem typu
     * {@link game77.api.TypeOfStep#tsGOTO TypeOfStep.tsGOTO}.
     *
     * @return Kolekce sousedů
     */
    @Override
    public List<Place> neighbors()
    {
        return currentNeighbors;
    }


    /***************************************************************************
     * Inicializuje daný prostor, tj. přiřadí mu počáteční sadu sousedů
     * a umístí do něj počáteční sadu objektů.
     */
    @Override
    public void initialize()
    {
        super.initializeItems();    //Inicializace h-objektů
        World world = World.get();
        currentNeighbors = new ArrayList<>();
        for (String name : initialNeighborNames) {
            currentNeighbors.add(world.place(name));
        }
    }
}
