// Příliš žluťoučký kůň úpěl ďábelské ó - PŘÍLIŠ ŽLUŤOUČKÝ KŮŇ ÚPĚL ĎÁBELSKÉ Ó
// J:/77_JAVA/game77/ck1f_basic/package-info.java


/*******************************************************************************
 * Balíček {@code game77.ck1f_basic} je demonstrační balíček,
 * jenž obsahuje vzorové řešení, které má za úkol dovést aplikaci do stavu,
 * kdy projdou všechny povinné akce spouštěné a prověřované prostřednictvím
 * scénářů BASIC a MISTAKES.
 */
package game77.ck1f_basic;

