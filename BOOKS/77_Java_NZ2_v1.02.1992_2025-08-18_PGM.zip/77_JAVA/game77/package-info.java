// Příliš žluťoučký kůň úpěl ďábelské ó - PŘÍLIŠ ŽLUŤOUČKÝ KŮŇ ÚPĚL ĎÁBELSKÉ Ó
// J:/77_JAVA/game77/package-info.java


/*******************************************************************************
 * Balíček {@code game77} obsahuje posloupnost balíčků
 * s třídami demonstrujícími postup vývoje aplikace v jednotlivých etapách.
 */
package game77;

