// Příliš žluťoučký kůň úpěl ďábelské ó - PŘÍLIŠ ŽLUŤOUČKÝ KŮŇ ÚPĚL ĎÁBELSKÉ Ó
// J:/77_JAVA/game77/ck1a_happy/package-info.java


/*******************************************************************************
 * Balíček {@code game77.ck1a_happy} je balíček výchozí etapy rozpracovanosti,
 * ve které je definován pouze portál a správce scénářů se scénářem HAPPY.
 */
package game77.ck1a_happy;

