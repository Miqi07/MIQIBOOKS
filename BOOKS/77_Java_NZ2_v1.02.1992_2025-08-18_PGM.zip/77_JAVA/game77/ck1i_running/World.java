package game77.ck1i_running;
// Příliš žluťoučký kůň úpěl ďábelské ó - PŘÍLIŠ ŽLUŤOUČKÝ KŮŇ ÚPĚL ĎÁBELSKÉ Ó
// J:/77_JAVA/game77/ck1i_running/World.java

import game77.api.INamed;
import game77.api.IPlace;
import game77.api.IWorld;

import java.util.List;

import static game77.ck1i_running.ScenarioManager.*;


/*******************************************************************************
 * Instance interfejsu {@code IWorld} reprezentuje svět hry.
 * V dané hře musí být definována jako jedináček.
 * Má na starosti uspořádání jednotlivých prostorů a udržuje informaci o tom,
 * ve kterém z nich se hráč právě nachází.
 * Vzájemné uspořádání prostorů se může v průběhu hry měnit –
 * prostory mohou v průběhu hry získávat a ztrácet sousedy.
 */
public   class World
    implements IWorld
{
//===== CLASS SECTION ==========================================================

    /** Odkaz na jedinou instanci (jedináčka) světa této hry. */
    private static final World WORLD = new World();


    /***************************************************************************
     * Tovární metoda poskytující jedinou existující instanci daného světa.
     *
     * @return Odkaz na jedináčka
     */
    public static World get()
    {
        return WORLD;
    }


//===== INSTANCE SECTION =======================================================

    private final List<Place> places;
    private Place currentPlace;


    /***************************************************************************
     * Soukromý konstruktor jedináčka zabrání vytváření nechtěných instancí.
     */
    private World()
    {
        places = List.of(
            new Place(plHOUSE,   dsHOUSE,   nbHOUSE,
                      "_Bábovka", "_Víno", "#Stůl", "_Panenka"),
            new Place(plWOOD,    dsWOOD,    nbWOOD,
                      "_Maliny", "_Jahody", "#Studánka"),
            new Place(plFOREST,  dsFOREST,  nbFOREST,  "#Vlk"),
            new Place(plCOTTAGE, dsCOTTAGE, nbCOTTAGE,
                      "#Postel", "#Stůl", "#Babička"),
            new Place(plCAVE,    dsCAVE,   nbCAVE,
                      "#Medvěd", "_Kosti")
        );
    }


    /***************************************************************************
     * Vrátí kolekci odkazů na všechny prostory vystupující ve hře.
     *
     * @return Kolekce odkazů na všechny prostory vystupující ve hře
     */
    @Override
    public List<Place> places()
    {
        return places;
    }


    /***************************************************************************
     * Vrátí odkaz na aktuální prostor,
     * tj. na prostor, v němž se hráč pravé nachází.
     *
     * @return Prostor, v němž se hráč pravé nachází
     */
    @Override
    public Place currentPlace()
    {
        return currentPlace;
    }


    /***************************************************************************
     * Nastaví zadaný prosto jako aktuální, tj. jako prostor,
     * v němž se aktuálně nachází hráč.
     *
     * @param destinationPlace Nastavovaný prostor
     */
    @Override
    public void setCurrentPlace(IPlace destinationPlace)
    {
        currentPlace = (Place)destinationPlace;
    }


    /***************************************************************************
     * Je li ve světě hry prostor se zadaným názvem, vrátí jej,
     * není-li tam, vrátí prázdný odkaz {@code null}.
     *
     * @param  name Název hledané prostoru
     * @return Hledaný prostor nebo prázdný odkaz {@code null}
     */
    @Override
    public Place place(String name)
    {
        return INamed.get(name, places);
    }


    /***************************************************************************
     * Inicializuje svět hry, tj. inicializuje propojení prostorů
     * a jejich obsah a nastaví výchozí aktuální prostor.
     */
    @Override
    public void initialize()
    {
        for (Place place : places) place.initialize();
        currentPlace = places.get(0);
    }
}
