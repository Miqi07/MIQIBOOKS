// Příliš žluťoučký kůň úpěl ďábelské ó - PŘÍLIŠ ŽLUŤOUČKÝ KŮŇ ÚPĚL ĎÁBELSKÉ Ó
// J:/77_JAVA/game77/ck1i_running/package-info.java


/*******************************************************************************
 * Balíček {@code game77.ck1h_running} je demonstrační balíček,
 * jenž obsahuje vzorové řešení, které má za úkol dovést aplikaci do stavu,
 * kdy projde opakovatelný běh dle scénáře HAPPY.
 */
package game77.ck1i_running;

