package game77.ck1i_running;
// Příliš žluťoučký kůň úpěl ďábelské ó - PŘÍLIŠ ŽLUŤOUČKÝ KŮŇ ÚPĚL ĎÁBELSKÉ Ó
// J:/77_JAVA/game77/ck1i_running/Game.java

import game77.api.BasicActions;
import game77.api.IBag;
import game77.api.IGame;
import game77.api.IWorld;

import java.util.List;


/******************************************************************************
 * Instance třídy {@code Game} má na starosti řízení hry
 * a komunikaci s uživatelským rozhraním.
 * Je schopna reagovat na zadávané příkazy a poskytovat informace
 * o průběžném stavu hry a jejích součástí.
 * <p>
 * <b>Hra musí být definována jako jedináček (singleton)</b>
 * a kromě metod deklarovaných v tomto interfejsu musí její třída definovat
 * statickou tovární metodu <b>{@code get()}</b>
 * vracející instanci tohoto jedináčka.
 */
public   class Game
    implements IGame
{
//===== CLASS SECTION ==========================================================

    /** Jediná existující instance hry. */
    private static final Game GAME = new Game();


    /***************************************************************************
     * Soukromý konstruktor bránící volnému vytváření instancí.
     */
    private Game() {}


    /***************************************************************************
     * Statická tovární metoda vracející jedinou existující instanci hry.
     *
     * @return Požadovaná instance
     */
    public static IGame get()
    {
        return GAME;
    }


//===== INSTANCE SECTION =======================================================

    /***************************************************************************
     * Vrátí informaci o tom, je-li hra aktuálně spuštěná.
     * Spuštěnou hru není možno pustit znovu.
     * Chceme-li hru spustit znovu, musíme ji nejprve ukončit.
     *
     * @return Je-li hra spuštěná, vrátí {@code true},
     *         jinak vrátí {@code false}
     */
    @Override
    public boolean isActive()
    {
        return Action.isActive();
    }


    /***************************************************************************
     * Vrátí odkaz na batoh, do nějž bude hráč ukládat sebrané objekty.
     *
     * @return Batoh, do nějž hráč ukládá sebrané objekty
     */
    @Override
    public IBag bag()
    {
        return Bag.get();
    }


    /***************************************************************************
     * Vrátí kolekci všech příkazů použitelných ve hře.
     *
     * @return Kolekce všech příkazů použitelných ve hře
     */
    @Override
    public List<Action> allActions()
    {
        return List.of();
    }


    /***************************************************************************
     * Vrátí odkaz na přepravku s názvy povinných příkazů, tj. příkazů pro
     * <ul>
     *   <li>přesun hráče do jiného prostoru,</li>
     *   <li>zvednutí objektu (odebrání z prostoru a vložení do batohu),</li>
     *   <li>položení objektu (odebrání z batohu a vložení do prostoru),</li>
     *   <li>vyvolání nápovědy,</li>
     *   <li>okamžité ukončení hry.</li>
     * </ul>
     *
     * @return Přepravka s názvy povinných příkazů
     */
    @Override
    public BasicActions basicActions()
    {
        return new BasicActions("Jdi", "Vezmi", "Polož", "?", "Konec");
    }


    /***************************************************************************
     * Vrátí odkaz na objekt reprezentující svět, v němž se hra odehrává.
     *
     * @return Svět, v němž se hra odehrává
     */
    @Override
    public IWorld world()
    {
        return World.get();
    }


    /***************************************************************************
     * Zpracuje zadaný příkaz a vrátí text zprávy pro uživatele.
     *
     * @param command Zadávaný příkaz
     * @return Textová odpověď hry na zadaný příkaz
     */
    @Override
    public String executeCommand(String command)
    {
        return Action.executeCommand(command);
    }


    /***************************************************************************
     * Ukončí celou hru a uvolní alokované prostředky.
     * Zadáním prázdného příkazu lze následně spustit hru znovu.
     */
    @Override
    public void stop()
    {
        Action.stop();
    }

}
