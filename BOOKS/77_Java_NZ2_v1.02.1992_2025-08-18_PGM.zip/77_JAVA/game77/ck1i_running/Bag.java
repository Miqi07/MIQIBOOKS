package game77.ck1i_running;
// Příliš žluťoučký kůň úpěl ďábelské ó - PŘÍLIŠ ŽLUŤOUČKÝ KŮŇ ÚPĚL ĎÁBELSKÉ Ó
// J:/77_JAVA/game77/ck1i_running/Bag.java

import game77.api.IBag;
import game77.api.IItem;


/*******************************************************************************
 * Instance třídy {@code Bag} je jedináček představující úložiště,
 * do nějž hráči ukládají h-objekty sebrané v jednotlivých prostorech,
 * aby je mohli přenést do jiných prostorů a/nebo použít.
 * Úložiště má konečnou kapacitu definující maximální povolený
 * součet vah objektů vyskytujících se v úložišti.
 */
public   class Bag
       extends AItemContainer
    implements IBag
{
    /** Jediná instance batohu. */
    private static final Bag BAG = new Bag();


    /***************************************************************************
     * Tovární metoda vracející odkaz na jedinou existující instanci batohu.
     *
     * @return Odkaz na jedináčka
     */
    public static Bag get()
    {
        return BAG;
    }


//===== INSTANCE SECTION =======================================================

    int content;

    /***************************************************************************
     * Soukromý konstruktor jedináčka zabrání vytváření nechtěných instancí.
     */
    private Bag()
    {
        super("«Bag»");
    }


    /***************************************************************************
     * Vrátí kapacitu batohu, tj. maximální povolený součet vah objektů,
     * které je možno současně uložit do batohu.
     *
     * @return Kapacita batohu
     */
    @Override
    public int capacity()
    {
        return 2;
    }


    /***************************************************************************
     * Přidá zadaný h-objekt do kontejneru a vrátí informaci o tom,
     * jestli se to podařilo. Při přidávání ale kontroluje,
     * aby celková váha h-objektů v batohu nepřekročila jeho kapacitu.
     *
     * @param item Přidávaný objekt
     * @return Podařilo-li se h-objekt přidat, vrátí {@code true}
     */
    @Override
    public boolean addItem(IItem item)
    {
        if (content + item.weight() > capacity()) {
            return false; }
        content += item.weight();
        return super.addItem(item);
    }


    /***************************************************************************
     * Odebere zadaný objekt z kontejneru a vrátí informaci o tom,
     * jestli se to podařilo.
     *
     * @param item Odebíraný objekt
     * @return Podařilo-li se objekt odebrat, vrátí {@code true}
     */
    @Override
    public boolean removeItem(IItem item)
    {
        if (super.removeItem(item)) {
            content -= item.weight();
            return true;
        }
        return false;
    }


    /***************************************************************************
     * Inicializuje batoh na počátku hry. Vedle inicializace obsahu,
     * inicializuje i informaci o zbývající kapacitě.
     */
    @Override
    public void initialize()
    {
        super.initializeItems();
        content = 0;
    }
}
