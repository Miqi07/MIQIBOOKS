package game77.ck1h_mistakes;
// Příliš žluťoučký kůň úpěl ďábelské ó - PŘÍLIŠ ŽLUŤOUČKÝ KŮŇ ÚPĚL ĎÁBELSKÉ Ó
// J:/77_JAVA/game77/ck1h_mistakes/ANamed.java

import game77.api.INamed;


/*******************************************************************************
 * Abstraktní třída {@code ANamed} je společným rodičem všech tříd
 * jejichž instance vystupují jako pojmenované objekty.
 */
public   class ANamed
    implements INamed
{
    private final String name;


    /***************************************************************************
     * Vytvoří rodičovský podobjekt, jenž si pamatuje jméno instance.
     *
     * @param name
     */
    public ANamed(String name) {
        this.name = name;
    }


//===== INSTANCE METHODS ===================================================

    /***************************************************************************
     * Vrátí název dané instance.
     *
     * @return Název instance
     */
    @Override
    public String name() {
        return name;
    }


    /***************************************************************************
     * Jako podpis instance použije její název.
     *
     * @return Jméno instance
     */
    @Override
    public String toString() {
        return name;
    }
}
