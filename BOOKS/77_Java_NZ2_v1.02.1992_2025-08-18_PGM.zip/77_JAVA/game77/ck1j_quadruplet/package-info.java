// Příliš žluťoučký kůň úpěl ďábelské ó - PŘÍLIŠ ŽLUŤOUČKÝ KŮŇ ÚPĚL ĎÁBELSKÉ Ó
// J:/77_JAVA/game77/ck1j_quadruplet/package-info.java


/*******************************************************************************
 * Balíček {@code game77.ck1j_quadruplet} je demonstrační balíček,
 * jenž obsahuje kompletní čtveřici scénářů pro testování hry.
 */
package game77.ck1j_quadruplet;

