// Příliš žluťoučký kůň úpěl ďábelské ó - PŘÍLIŠ ŽLUŤOUČKÝ KŮŇ ÚPĚL ĎÁBELSKÉ Ó
// J:/77_JAVA/game77/api0/package-info.java


/*******************************************************************************
 * Balíček {@code game77.api0} obsahuje rozpracovanou podobu balíčku
 * {@code game77.api}; podobu v níž ještě nejsou třídy scénářů & spol.
 */
package game77.api0;

