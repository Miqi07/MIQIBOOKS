package game77.api0;
// Příliš žluťoučký kůň úpěl ďábelské ó - PŘÍLIŠ ŽLUŤOUČKÝ KŮŇ ÚPĚL ĎÁBELSKÉ Ó
// J:/77_JAVA/game77/api/INamed.java

import java.util.List;



/*******************************************************************************
 * Interfejs {@code INamed} je společným rodičem všech interfejsů
 * implementovaných třídami s pojmenovanými instancemi.
 */
public interface INamed
{
//===== CLASS (STATIC) METHODS =================================================

    /***************************************************************************
     * Vyhledá v seznamu objekt se zadaným názvem a vrátí jej .
     * Je-li objektů s daným názvem více, vrátí první nalezený.
     * Nenalezne-li jej, vrátí prázdný odkaz.
     *
     * @param <E>        Typ prvků prohledávané kolekce
     * @param memberName Název hledaného objektu
     * @param list       Prohledávaný seznam
     * @return Nalezený objekt nebo {@code null}
     */
    public static <E extends INamed>
    E get(String memberName, List<E> list)
    {
        for (E iNamed : list) {
            String name = iNamed.name();
            if (iNamed.name().equalsIgnoreCase(memberName)) {
                return iNamed;
            }
        }
        return null;
    }



//##############################################################################
//===== ABSTRACT GETTERS AND SETTERS ===========================================

    /***************************************************************************
     * Vrátí název dané instance.
     *
     * @return Název instance
     */
    //@Override
    public String name()
    ;



//===== REMAINING DEFAULT METHODS ==============================================

    /***************************************************************************
     * Vrátí textový podpis dané instance tvořený názvem její mateřské třídy
     * následovaným znakem podtržení a názvem instance.
     *
     * @return Název instance
     */
    default public String toStringWithClass()
    {
        return getClass().getSimpleName() + "_" + name();
    }

}
