package game77.ck1e_world;
// Příliš žluťoučký kůň úpěl ďábelské ó - PŘÍLIŠ ŽLUŤOUČKÝ KŮŇ ÚPĚL ĎÁBELSKÉ Ó
// J:/77_JAVA/game77/ck1e_world/AItemContainer.java

import game77.api.IItem;
import game77.api.IItemContainer;
import game77.api.INamed;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Collections;
import java.util.List;


/*******************************************************************************
 * Instance abstraktní třídy {@code AItemContainer} jsou rodičovskými podobjekty
 * tříd, jejichž instance představují kontejnery h-objektů.
 * Speciálními případy těchto kontejnerů jsou prostory a batoh.
 */
public   class AItemContainer
       extends ANamed
    implements IItemContainer
{
    /** Aktuálně obsažené h-objekty. */
    private final List<String> initialItemNames;

    /** Aktuálně obsažené h-objekty. */
    private final List<IItem>  currentItems = new ArrayList<>();


    /***************************************************************************
     * Vytvoří rodičovský podobjekt představující kontejner h-objektů.
     *
     * @param name  Název vlastníka předávaný rodiči
     * @param initialItemNames Názvy položek uložené v kontejneru na počátku hry
     */
    public AItemContainer(String name, String... initialItemNames)
    {
        super(name);
        this.initialItemNames = List.copyOf(Arrays.asList(initialItemNames));
    }


    /***************************************************************************
     * Vrátí kolekci objektů nacházejících se v daném kontejneru.
     *
     * @return Kolekce objektů nacházejících se v daném kontejneru
     */
    @Override
    public List<IItem> items()
    {
        return Collections.unmodifiableList(currentItems);
    }


    /***************************************************************************
     * Je li v kontejneru objekt se zadaným názvem, vrátí jej,
     * není-li tam, vrátí prázdný odkaz {@code null}.
     *
     * @param  name Název hledané objektu
     * @return Hledaný objekt nebo prázdný odkaz {@code null}.
     */
    @Override
    public Item item(String name)
    {
        return (Item)INamed.get(name, currentItems);
    }


    /***************************************************************************
     * Přidá zadaný objekt do kontejneru a vrátí informaci o tom,
     * jestli se to podařilo.
     *
     * @param item Přidávaný objekt
     * @return Podařilo-li se objekt přidat, vrátí {@code true}
     */
    @Override
    public boolean addItem(IItem item)
    {
        return currentItems.add(item);
    }


    /***************************************************************************
     * Odebere zadaný objekt z kontejneru a vrátí informaci o tom,
     * jestli se to podařilo.
     *
     * @param item Odebíraný objekt
     * @return Podařilo-li se objekt odebrat, vrátí {@code true}
     */
    @Override
    public boolean removeItem(IItem item)
    {
        return currentItems.remove(item);
    }


    /***************************************************************************
     * Inicializuje kontejner na počátku hry.
     * Po inicializace bude obsahovat příslušnou výchozí sadu objektů.
     */
    @Override
    public void initializeItems()
    {
        currentItems.clear();
        for (String name : initialItemNames) {
            currentItems.add(new Item(name));
        }
    }
}
