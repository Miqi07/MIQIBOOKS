package robotcz;
/* Saved in UTF-8 codepage: Příliš žluťoučký kůň úpěl ďábelské ódy. ÷ × ¤
 * Check: «Stereotype», Section mark-§, Copyright-©, Alpha-α, Beta-β, Smile-☺
 */



/*******************************************************************************
 * Možné směry natočení robota.
 *
 * @author  Rudolf PECINOVSKÝ
 * @version 1.05.9267_2023-03-11
 */
public enum Direction
{
    EAST ( 1, 0),
    NORTH( 0,-1),
    WEST (-1, 0),
    SOUTH( 0, 1);

    private final int dx;
    private final int dy;


    /***************************************************************************
     * Vytvoří směr s požadovanými posuny souřadnic k pozici sousedního pole.
     *
     * @param dx Vodorovný posun k sousednímu poli v daném směru
     * @param dy Svislý    posun k sousednímu poli v daném směru
     */
    private Direction(int dx, int dy)
    {
        this.dx = dx;
        this.dy = dy;
    }


    /***************************************************************************
     * Vrátí vodorovný přírůstek souřadnice při pohybu v daném směru.
     *
     * @return Vodorovný přírůstek souřadnice při pohybu v daném směru
     */
    public int dx()
    {
        return dx;
    }


    /***************************************************************************
     * Vrátí svislý přírůstek souřadnice při pohybu v daném směru.
     *
     * @return Svislý přírůstek souřadnice při pohybu v daném směru
     */
    public int dy()
    {
        return dy;
    }

//
//    /***************************************************************************
//     * Vrátí pozici sousedního pole zadané pozice v daném směru.
//     *
//     * @param pos Pozice, na jejíž sousední pole se ptáme
//     * @return Požadovaná sousední pozice
//     */
//    Position moveFrom(Position pos)
//    {
//        return new Position(pos.x()+dx, pos.y()+dy);
//    }
//
//
//    /***************************************************************************
//     * Vrátí pozici pole v daném směru o zadaný počet polí od zadané pozice.
//     *
//     * @param distance  Vzdálenost hledané pozice
//     * @param pos       Pozice, z níž se vydáváme
//     * @return Požadovaná vzdálená pozice
//     */
//    Position moveBy(int distance, Position pos)
//    {
//        return new Position(pos.x()+dx*distance, pos.y()+dy*distance);
//    }
//

    /***************************************************************************
     * Vrátí směr otočený o 90° vlevo.
     *
     * @return Směr otočený o 90° vlevo
     */
    Direction turnLeft()
    {
        return values()[(ordinal()+1) & 3];
    }


    /***************************************************************************
     * Vrátí směr otočený o 90° vpravo.
     *
     * @return Směr otočený o 90° vpravo
     */
    Direction turnRight()
    {
        return values()[(ordinal()+3) & 3];
    }


    /***************************************************************************
     * Vrátí směr otočený o 180°.
     *
     * @return Směr otočený o 90° vpravo
     */
    Direction turnAbout()
    {
        return values()[(ordinal()+2) & 3];
    }

}
