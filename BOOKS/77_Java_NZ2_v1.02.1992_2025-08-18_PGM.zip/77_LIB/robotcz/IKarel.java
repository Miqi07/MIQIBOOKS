package robotcz;
/* Saved in UTF-8 codepage: Příliš žluťoučký kůň úpěl ďábelské ódy. ÷ × ¤
 * Check: «Stereotype», Section mark-§, Copyright-©, Alpha-α, Beta-β, Smile-☺
 */



/*******************************************************************************
 * Interfejs deklarující základní sadu metod robota.
 *
 * @author  Rudolf PECINOVSKÝ
 * @version 1.05.9267_2023-03-11
 */
public  interface   IKarel
{
    /** Implicitní směr natočení přidávaného robota. */
    public static final Direction DEFAULT_DIR = Direction.EAST;

    /** Implicitní barva přidávaného robota. */
    public static final Color DEFAULT_COLOR = Color.BLUE;



    /***************************************************************************
     * Posune robota na další políčko ve směru, do nějž je natočen.
     * Je-li na daném políčku robot nebo zeď, ohlásí chybu.
     *
     * @return Odkaz na osloveného robota
     */
//    @Override
    public IKarel step()
    ;


    /***************************************************************************
     * Otočí robotem o 90° vlevo.
     *
     * @return Odkaz na osloveného robota
     */
//    @Override
    public IKarel turnLeft()
    ;


    /***************************************************************************
     * Položí značku na políčko, na němž stojí.
     * Je-li již na něm maximální povolený počet značek, ohlásí chybu.
     *
     * @return Odkaz na osloveného robota
     */
//    @Override
    public IKarel put()
    ;


    /***************************************************************************
     * Zvedne značku z políčka, na němž stojí.
     * Není-li již na daném políčku žádná značka, ohlásí chybu.
     *
     * @return Odkaz na osloveného robota
     */
//    @Override
    public IKarel pick()
    ;


    /***************************************************************************
     * Vrátí informaci o tom, je-li na políčku pod robotem nějaká značka.
     *
     * @return Je-li na pod ním značka, vrátí {@code true},
     *         jinak vrátí {@code false}.
     */
//    @Override
    public boolean isMarker()
    ;


    /***************************************************************************
     * Vrátí informaci o tom, je-li na políčku před robotem zeď.
     *
     * @return Je-li před ním zeď, vrátí {@code true},
     *         jinak vrátí {@code false}.
     */
//    @Override
    public boolean isWall()
    ;


    /***************************************************************************
     * Vrátí informaci o tom, je-li robot otočen na východ.
     *
     * @return Je-li otočen na východ, vrátí {@code true}.
     *         jinak vrátí {@code false}.
     */
//    @Override
    public boolean isEast()
    ;


    /***************************************************************************
     * Je-li na políčku před robotem jiný robot, vrátí odkaz na tohoto robota,
     * jinak vrátí {@code null}.
     *
     * @return Odkaz na robota na políčku před ním, není-li, vrátí {@code null}.
     */
//    @Override
    public IKarel robotAhead()
    ;


    /***************************************************************************
     * Přestane robota zobrazovat, čímž jeho činnost výrazně zrychlí.
     */
//    @Override
    public IKarel hide()
    ;


    /***************************************************************************
     * Vrátí úroveň zobrazování do stavy před posledním skrytím.
     * Byl-li proto již tehdy skrytý (a tím pádem i zrychlený),
     * zůstane skrytý (a zrychlený) i nadále. Byl-li zobrazovaný,
     * začne se opět zobrazovat.
     */
//    @Override
    public IKarel unhide()
    ;

}//public interface IKarel
