package robotcz;

public final class Version {

    private Version() {}

    public static String get() {
        return "RobotCZ_25s - 1.06.1830_2024-12-26";
    }

}
