package robotcz;
/* Saved in UTF-8 codepage: Příliš žluťoučký kůň úpěl ďábelské ódy. ÷ × ¤
 * Check: «Stereotype», Section mark-§, Copyright-©, Alpha-α, Beta-β, Smile-☺
 */

import java.util.Collection;

import robotcz.RobotWorld.WRobot;



/*******************************************************************************
 * Instance interfejsu {@code IRobotWorldListener} představují posluchače,
 * kteří reagují na změny ve světě robota.
 *
 * @author  Rudolf PECINOVSKÝ
 * @version 1.05.9267_2023-03-11
 */
public interface IRobotWorldListener
{
//##############################################################################
//\AG== ABSTRACT GETTERS AND SETTERS ===========================================

    /***************************************************************************
     * Hlášení o změně ve světě robota vyžadující jeho překreslení.
     *
     * @param fields    Aktuální obsah jednotlivých polí
     * @param robots    Kolekce robotů aktuálně rozmístěných na dvorku
     */
    public void repaint(int[][] fields, Collection<WRobot> robots);


    /***************************************************************************
     * Oznámení o konci světa robota a z toho plynoucí povinnosti
     * uvolnit blokované zdroje.
     */
    public void release();

}
