package robotcz;
/* Saved in UTF-8 codepage: Příliš žluťoučký kůň úpěl ďábelské ódy. ÷ × ¤
 * Check: «Stereotype», Section mark-§, Copyright-©, Alpha-α, Beta-β, Smile-☺
 */



/*******************************************************************************
 *  The possible robot's colors.
 *
 *  @author       Rudolf PECINOVSKÝ
 *  @version 1.05.9267_2023-03-11
 */
public enum Color
{
    // 0   1     2    3        4      5     6        7
    BLACK, BLUE, RED, MAGENTA, GREEN, CYAN, YELLOW , WHITE;
}
