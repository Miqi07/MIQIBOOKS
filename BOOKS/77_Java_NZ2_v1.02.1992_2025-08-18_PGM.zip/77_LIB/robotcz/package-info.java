/* Saved in UTF-8 codepage: Příliš žluťoučký kůň úpěl ďábelské ó. */

/*******************************************************************************
 * Balíček se světem robotů navrženým jako vyučovací pomůcka
 * pro výuku základů algoritmizace a objektového programování.
 *
 * @author  Rudolf PECINOVSKÝ
 * @version 1.05.9267_2023-03-11
 */
package robotcz;

