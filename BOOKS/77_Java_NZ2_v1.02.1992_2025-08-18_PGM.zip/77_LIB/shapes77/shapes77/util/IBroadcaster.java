package shapes77.util;
/* Saved in UTF-8 codepage: Příliš žluťoučký kůň úpěl ďábelské ódy. ÷ × ¤ */



/*******************************************************************************
 * Instance rozhraní {@code IBroadcaster} představuji hlasatele
 * oznamujícího přihlášeným posluchačům výskyt události, na niž čekají.
 *
 * @param <Informant> Typ objektu obsahujícího informace o události,
 *                    kterou hlasatel oznamuje svým posluchačům
 *
 * @author  Rudolf PECINOVSKÝ
 * @version 2020-Winter
 */
public interface IBroadcaster<Informant>
{
//== STATIC CONSTANTS ==========================================================
//== STATIC METHODS ============================================================



//##############################################################################
//== ABSTRACT GETTERS AND SETTERS ==============================================
//== OTHER ABSTRACT METHODS ====================================================

    /***************************************************************************
     * Přidá zadaného posluchače do seznamu posluchačů,
     * které zpravuje o výskytu očekávané události.
     *
     * @param listener Přihlašovaný posluchač
     */
//    @Override
    public void addListener(IListener<Informant> listener);


    /***************************************************************************
     * Odebere zadaného posluchače ze seznamu posluchačů,
     * které zpravuje o výskytu očekávané události.
     *
     * @param listener Odhlašovaný posluchač
     */
//    @Override
    public void removeListener(IListener<Informant> listener);



//== DEFAULT GETTERS AND SETTERS ===============================================
//== OTHER DEFAULT METHODS =====================================================



//##############################################################################
//== NESTED DATA TYPES =========================================================
}
