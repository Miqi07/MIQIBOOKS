package shapes77.geom;
/* Saved in UTF-8 codepage: Příliš žluťoučký kůň úpěl ďábelské ódy. ÷ × ¤ */

/********************************************************************************
 * Instance třídy {@code Position} představují přepravky uchovávající informace
 * o pozici objektu.
 *
 * @param x  Vodorovná souřadnice
 * @param y  Svislá souřadnice
 *
 * @author  Rudolf PECINOVSKÝ
 * @version 2021-Winter
 */
public record Position(int x, int y)
{
}
