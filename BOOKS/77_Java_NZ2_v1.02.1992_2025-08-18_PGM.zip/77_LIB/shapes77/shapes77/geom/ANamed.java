package shapes77.geom;
/* Saved in UTF-8 codepage: Příliš žluťoučký kůň úpěl ďábelské ódy. ÷ × ¤ */



/********************************************************************************
 * Instance třídy {@code ANamed} představují ...
 *
 * @author  Rudolf PECINOVSKÝ
 * @version 2020-Winter
 */
public abstract class ANamed
{
//== CONSTANT CLASS FIELDS =====================================================
//== VARIABLE CLASS FIELDS =====================================================

    /** Celkový počet vytvořených instancí. */
    private static int created = 0;



//##############################################################################
//== STATIC INITIALIZER (CLASS CONSTRUCTOR) ====================================
//== CLASS GETTERS AND SETTERS =================================================
//== OTHER NON-PRIVATE CLASS METHODS ===========================================
//== PRIVATE AND AUXILIARY CLASS METHODS =======================================



//##############################################################################
//== CONSTANT INSTANCE FIELDS ==================================================

    /** Rodné číslo instance = pořadí vytvoření dané instance v rámci třídy. */
    private final int ID;



//== VARIABLE INSTANCE FIELDS ==================================================

    /** Název instance sestávající implicitně z názvu třídy a pořadí instance */
    private String name;



//##############################################################################
//== CONSTRUCTORS AND FACTORY METHODS ==========================================

    /****************************************************************************
     * Vytvoří rodičovský podobjekt, který ihned pojmenuje.
     */
    public ANamed()
    {
        ID   = ++created;
        name = this.getClass().getSimpleName() + "_" + ID;
    }



//== ABSTRACT METHODS ==========================================================
//== INSTANCE GETTERS AND SETTERS ==============================================

    /****************************************************************************
     * Vrátí název instance, implicitně název její třídy následovaný
     * pořadím vytvoření instance v rámci instancí této třídy.
     *
     * @return  Řetězec s názvem instance
     */
    public String getName()
    {
        return name;
    }


    /****************************************************************************
     * Nastaví nový název instance.
     *
     * @param name  Řetězec s novým názvem instance
     */
    public void setName(String name)
    {
        this.name = name;
    }



//== OTHER NON-PRIVATE INSTANCE METHODS ========================================

    /****************************************************************************
     * Vrátí textový podpis instance, tj. její řetězcovou reprezentaci.
     * Používá se především při ladění.
     *
     * @return Název instance následovaný charakteristikami v závorkách
     */
    @Override
    public String toString()
    {
        return name + "(" + forToString() + ")";
    }


    /****************************************************************************
     * Vrátí textový podpis instance, tj. její řetězcovou reprezentaci.
     * Používá se především při ladění.
     *
     * @return Název instance následovaný jejími souřadnicemi,
     *         rozměry a barvou
     */
//    @Override
    protected String forToString()
    {
        return "";
    }



//== PRIVATE AND AUXILIARY INSTANCE METHODS ====================================



//##############################################################################
//== NESTED DATA TYPES =========================================================
}
