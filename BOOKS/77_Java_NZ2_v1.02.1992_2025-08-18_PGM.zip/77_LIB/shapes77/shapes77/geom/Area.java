package shapes77.geom;
/* Saved in UTF-8 codepage: Příliš žluťoučký kůň úpěl ďábelské ódy. ÷ × ¤ */



/********************************************************************************
 * Instance záznamu {@code Area} představují přepravky uchovávající informace
 * o pozici a rozměrech objektu.
 *
 * @param x      Vodorovná souřadnice oblasti, tj. jejího levého horního rohu
 * @param y      Svislá souřadnice oblasti, tj. jejího levého horního rohu
 * @param width  Šířka oblasti
 * @param height Výška oblasti
 *
 * @author  Rudolf PECINOVSKÝ
 * @version 2021-Winter
 */
public record Area(int x, int y, int width, int height)
{
    /****************************************************************************
     * Vytvoří oblast se zadaným umístěním a rozměry.
     *
     * @param position Pozice oblasti, tj. pozice jejího levého horního rohu
     * @param size     Rozměr vytvářené oblasti
     */
    public Area(Position position, Size size)
    {
        this(position.x(), position.y(), size.width(), size.height());
    }

    /****************************************************************************
     * Vrátí pozici oblasti.
     *
     * @return  Pozice oblasti, tj. jejího levého horního rohu
     */
    public Position position()
    {
        return new Position (x, y);
    }

    /****************************************************************************
     * Vrátí rozměr oblasti.
     *
     * @return  Rozměr oblasti
     */
    public Size size()
    {
        return new Size(width, height);
    }
}
