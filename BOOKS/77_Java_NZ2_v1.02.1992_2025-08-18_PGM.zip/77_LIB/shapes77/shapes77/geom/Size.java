package shapes77.geom;
/* Saved in UTF-8 codepage: Příliš žluťoučký kůň úpěl ďábelské ódy. ÷ × ¤ */



/********************************************************************************
 * Instance třídy {@code Rozměr} představují přepravky uchovávající informace
 * o rozměrech objektu.
 *
 * @param width  Šířka objektu
 * @param height Výška objektu
 *
 * @author  Rudolf PECINOVSKÝ
 * @version 2020-Winter
 */
public record Size(int width, int height)
{
}
