package shapes77.geom;
/* Saved in UTF-8 codepage: Příliš žluťoučký kůň úpěl ďábelské ódy. ÷ × ¤ */



/********************************************************************************
 * Instance interfejsu {@code IModular} představují geometrické objekty,
 * které umějí prozradit a nastavit svoji pozici a modul.
 * Modul objektu je přitom základní rozměr, od nějž jsou dovozovány
 * všechny ostatní rozměry objektu.
 * Většinou je definován jako délka strany opsaného čtverce.
 *
 * @author  Rudolf PECINOVSKÝ
 * @version 2020-Winter
 */
public interface IModular
         extends IMovable, IAdaptable
{
//\CC== CLASS (STATIC) CONSTANTS ===============================================
//\CM== CLASS (STATIC) METHODS =================================================



//##############################################################################
//\AG== ABSTRACT GETTERS AND SETTERS ===========================================

    /****************************************************************************
     * Vrátí velikost modulu, tj. délku strany opsaného čtverce.
     *
     * @return   Velikost modulu instance
     */
//    @Override
    public int getModule();


    /****************************************************************************
     * Změni velikost instance, aby měl její nový modul
     * (= délku strany opsaného čtverce) zadanou velikost.
     *
     * @param module    Nově nastavovaný modul
     */
//    @Override
    public void setModule(int module);



//\AM== REMAINING ABSTRACT METHODS =============================================
//\DG== DEFAULT GETTERS AND SETTERS ============================================
//\DM== REMAINING DEFAULT METHODS ==============================================

    /****************************************************************************
     * V závislosti na zadané změně referenční velikosti <br>
     * změní absolutní pozici a rozměr instance tak,
     * aby se její reklativní pozice a velikost nezměnila .
     *
     * @param oldSize  Původní hodnota referenční velikosti
     * @param newSize  Nově nastavená hodnota referenční velikosti
     */
    @Override
    default
    public void stepChanged(int oldSize, int newSize)
    {
        double ratio = (double)newSize / oldSize;
        int x = (int)(getX() * ratio);
        int y = (int)(getY() * ratio);
        setPosition(x, y);
        int m = (int)(getModule() * ratio);
        setModule(m);
    }



//##############################################################################
//\NT== NESTED DATA TYPES ======================================================
}
