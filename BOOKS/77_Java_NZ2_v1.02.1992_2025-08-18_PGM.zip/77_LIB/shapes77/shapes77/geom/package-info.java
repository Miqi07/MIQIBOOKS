/* Saved in UTF-8 codepage: Příliš žluťoučký kůň úpěl ďábelské ódy. ÷ × ¤
 * Check: «Stereotype», Section mark-§, Copyright-©, Alpha-α, Beta-β, Smile-☺
 */



/*******************************************************************************
 * Balíček obsahuje datové typy související s velikostí a pozicí objektů
 * a s jejich změnami.
 * <p>
 * Oproti předchozím verzím jsou nyní její datové typy definovány tak,
 * aby byly použitelné jak při použití jednodušších datových typů z balíčku
 * {@link shapes77.canvas.Canvas}, <br>
 * tak při použití zdokonalených datových typů z balíčku
 * {@link shapes77.canvasmanager.CanvasManager}.
 *
 * @author  Rudolf PECINOVSKÝ
 * @version 2020-Winter
 */
package shapes77.geom;
