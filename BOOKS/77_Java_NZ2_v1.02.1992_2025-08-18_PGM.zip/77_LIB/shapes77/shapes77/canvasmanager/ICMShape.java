package shapes77.canvasmanager;
/* Saved in UTF-8 codepage: Příliš žluťoučký kůň úpěl ďábelské ódy. ÷ × ¤ */

import shapes77.geom.IShape;
import shapes77.util.ICopyable;



/*******************************************************************************
 * Instance interfejsu {@code ICMShape} představují objekty určené pro zobrazení
 * na virtuálním plátně spravovaném správcem plátna.
 *
 * @author  Rudolf PECINOVSKÝ
 * @version 2020-Winter
 */
public interface ICMShape
         extends IShape, ICMPaintable
{
//\CC== CLASS (STATIC) CONSTANTS ===============================================
//\CM== CLASS (STATIC) METHODS =================================================



//##############################################################################
//\AG== ABSTRACT GETTERS AND SETTERS ===========================================
//\AM== REMAINING ABSTRACT METHODS =============================================

    /***************************************************************************
     * Returns a deep copy of the instance.
     * <p>
     * In opposition to its parent that returns an instance of the interface
     * {@link ICopyable} this method restricts the returned values
     * to instances of this interface {@code ICMShape}.
     *
     * @return The requested copy
     */
    @Override
    public ICMShape copy();



//\DG== DEFAULT GETTERS AND SETTERS ============================================
//\DM== REMAINING DEFAULT METHODS ==============================================



//##############################################################################
//\NT== NESTED DATA TYPES ======================================================
}
