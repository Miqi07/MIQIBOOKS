/* Saved in UTF-8 codepage: Příliš žluťoučký kůň úpěl ďábelské ódy. ÷ × ¤
 * Check: «Stereotype», Section mark-§, Copyright-©, Alpha-α, Beta-β, Smile-☺
 */



/*******************************************************************************
 * Balíček obsahuje základní grafické třídy používané ve vstupních kurzech
 * programování a to jak v interaktivním, tak i v textovém režimu.<br>
 * Zařazení tohoto balíčku do výuky vyžaduje jisté minimální znalosti
 * koncepce a použití návrhových vzorů, především pak návrhových vzorů
 * <i>Jedináček</i> (<i>Singleton</i>), <i>Prostředník</i> a <i>Pozorovatel</i>,
 * na nichž je založena činnost správce plátna &ndash; jediné instance třídy
 * {@link shapes77.canvasmanager.CanvasManager}.
 *
 * @author  Rudolf PECINOVSKÝ
 * @version 2020-Winter
 */
package shapes77.canvasmanager;
