package shapes77.canvasmanager;
/* Saved in UTF-8 codepage: Příliš žluťoučký kůň úpěl ďábelské ódy. ÷ × ¤ */

import shapes77.geom.IModular;



/*******************************************************************************
 * Instance interfejsu {@code ICMShape} představují objekty určené pro zobrazení
 * na virtuálním plátně spravovaném správcem plátna.
 *
 * @author  Rudolf PECINOVSKÝ
 * @version 2020-Winter
 */
public interface ICMModular
         extends IModular, ICMPaintable
{
//\CC== CLASS (STATIC) CONSTANTS ===============================================
//\CM== CLASS (STATIC) METHODS =================================================



//##############################################################################
//\AG== ABSTRACT GETTERS AND SETTERS ===========================================
//\AM== REMAINING ABSTRACT METHODS =============================================
//\DG== DEFAULT GETTERS AND SETTERS ============================================
//\DM== REMAINING DEFAULT METHODS ==============================================



//##############################################################################
//\NT== NESTED DATA TYPES ======================================================
}
