package shapes77.canvasmanager;
/* Saved in UTF-8 codepage: Příliš žluťoučký kůň úpěl ďábelské ódy. ÷ × ¤ */

import shapes77.geom.IMovable;



/*******************************************************************************
* Rozhraní doplňuje metody svého rodiče o metodu {@link #moved()},
 * kterou {@link Multimover} zavolá poté,
 * co "dostrká" svěřený objekt do zadané cílové pozice.
*
 * @author  Rudolf PECINOVSKÝ
 * @version 2020-Winter
 */
public interface IMultimovable
         extends IMovable, ICMPaintable
{
//\CC== CLASS (STATIC) CONSTANTS ===============================================
//\CM== CLASS (STATIC) METHODS =================================================



//##############################################################################
//\AG== ABSTRACT GETTERS AND SETTERS ===========================================
//\AM== REMAINING ABSTRACT METHODS =============================================

    /***************************************************************************
     * Metoda vyvolaná multipřesouvačem poté, co dovedl svěřený objekt
     * do zadané cílové pozice. Při svém typickém použití metoda nastaví
     * novou cílovou pozici své instance a instanci opět předá multipřesouvači.
     */
//    @Override
    public void moved();



//\DG== DEFAULT GETTERS AND SETTERS ============================================
//\DM== REMAINING DEFAULT METHODS ==============================================



//##############################################################################
//\NT== NESTED DATA TYPES ======================================================
}
