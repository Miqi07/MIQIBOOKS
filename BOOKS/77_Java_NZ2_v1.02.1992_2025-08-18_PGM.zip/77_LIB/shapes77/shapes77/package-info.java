/* Saved in UTF-8 codepage: Příliš žluťoučký kůň úpěl ďábelské ódy. ÷ × ¤
 * Check: «Stereotype», Section mark-§, Copyright-©, Alpha-α, Beta-β, Smile-☺
 */
////////////////////////////////////////////////////////////////////////////////
//%P-  +++++ End of ignored starting test - place for imports +++++



/*******************************************************************************
 * Balíček {@code eu.pedu.lib} obsahuje datové typy knihovny
 * pro podporu výuky programování v Javě.
 *
 * @author  Rudolf PECINOVSKÝ
 * @version 2019-Summer
 */
package eu.pedu.lib19s;
