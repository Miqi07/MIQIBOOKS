package shapes77.canvas;
/* Saved in UTF-8 codepage: Příliš žluťoučký kůň úpěl ďábelské ódy. ÷ × ¤ */



/*******************************************************************************
 * Instance interfejsu {@code ICanvasPaintable} představují objekty,
 * které jsou schopny se nakreslit na plátno a opět se smazat.
 *
 * @author  Rudolf PECINOVSKÝ
 * @version 2020-Winter
 */
public interface ICanvasPaintable
{
//\CC== CLASS (STATIC) CONSTANTS ===============================================
//\CM== CLASS (STATIC) METHODS =================================================



//##############################################################################
//\AG== ABSTRACT GETTERS AND SETTERS ===========================================
//\AM== REMAINING ABSTRACT METHODS =============================================

    /***************************************************************************
     * Zobrazí svoji instanci, tj.vykreslí její obraz na plátno.
     */
//     @Override
    public void paint();


    /***************************************************************************
     * Smaže obraz své instance z plátna,
     * t.j. nakreslí ji barvou pozadí plátna.
     */
//     @Override
    public void rubOut();



//\DG== DEFAULT GETTERS AND SETTERS ============================================
//\DM== REMAINING DEFAULT METHODS ==============================================



//##############################################################################
//\NT== NESTED DATA TYPES ======================================================
}
