/* Saved in UTF-8 codepage: Příliš žluťoučký kůň úpěl ďábelské ódy. ÷ × ¤
 * Check: «Stereotype», Section mark-§, Copyright-©, Alpha-α, Beta-β, Smile-☺
 */



/*******************************************************************************
 * Balíček obsahuje základní grafické třídy používané v úvodních lekcích
 * vstupních kurzů programování před tím, než jsou vysvětleny základní
 * návrhové vzory a je představen správce plátna s jeho dokonalejším
 * řešením grafiky založeném na použití vzorů <i>Prostředník</i>
 * a <i>Pozorovatel</i>.
 *
 * @author  Rudolf PECINOVSKÝ
 * @version 2020-Winter
 */
package shapes77.canvas;
