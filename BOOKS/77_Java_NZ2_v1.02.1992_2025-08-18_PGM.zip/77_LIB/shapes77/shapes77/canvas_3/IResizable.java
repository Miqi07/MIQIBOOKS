package shapes77.canvas_3;
/* UTF-8 codepage: Příliš žluťoučký kůň úpěl ďábelské ó. ÷ × ¤ */

/*******************************************************************************
* Instance interfejsu {@code IResizeable} představují objekty,
 * které umějí prozradit a nastavit svoje rozměry.
 * Rozměry instance jsou přitom definovány jako rozměry
 * opsaného obdélníku.
*
 * @author  Rudolf PECINOVSKÝ
 * @version 2021-Winter
 */
public interface IResizable
{
    /***************************************************************************
     * Vrátí aktuální šířku instance.
     * Šířka instance jsou přitom definována jako šířka
     * opsaného obdélníku.
     *
     * @return  Aktuální šířka instance
     */
    //@Override
    public int getWidth();


    /***************************************************************************
     * Vrátí aktuální výšku instance.
     * Výška instance jsou přitom definována jako výška
     * opsaného obdélníku.
     *
     * @return  Aktuální výška instance
     */
    //@Override
    public int getHeight();


    /***************************************************************************
     * Nastaví nové rozměry instance.
     * Rozměry instance jsou přitom definovány jako rozměry
     * opsaného obdélníku.
     * Nastavované rozměry musí být nezáporné,
     * místo nulového rozměru se nastaví rozměr rovný jedné.
     *
     * @param width   Nově nastavovaná šířka; šířka &gt;= 0
     * @param height  Nově nastavovaná výška; výška &gt;= 0
     */
    //@Override
    public void setSize(int width, int height);
}
