/* Saved in UTF-8 codepage: Příliš žluťoučký kůň úpěl ďábelské ódy. ÷ × ¤
 * Check: «Stereotype», Section mark-§, Copyright-©, Alpha-α, Beta-β, Smile-☺
 */



/********************************************************************************
 * Balíček obsahuje pomocné třídy používané při ladění.
 *
 * @author  Rudolf PECINOVSKÝ
 * @version 2020-Winter
 */
package shapes77.dbg;
