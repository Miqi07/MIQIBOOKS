package shapes77.canvas_4;
/* UTF-8 codepage: Příliš žluťoučký kůň úpěl ďábelské ó. ÷ × ¤ */

/*******************************************************************************
 * Instance interfejsu {@code IChangeable} představují objekty,
 * které umějí prozradit a nastavit svoji pozici a svoje rozměry.
 * Pozice instance je implicitně definována jako pozice
 * levého horního rohu opsaného obdélníku.
 * Rozměry instance jsou přitom definovány jako rozměry opsaného obdélníku.
 *
 * @author  Rudolf PECINOVSKÝ
 * @version 2021-Winter
 */
public interface IChangeable
         extends IMovable, IResizable
{
}
