// Příliš žluťoučký kůň úpěl ďábelské ó - PŘÍLIŠ ŽLUŤOUČKÝ KŮŇ ÚPĚL ĎÁBELSKÉ Ó
// J:/77_JSH/GuessC.java

import java.util.Scanner;

/** Konzolová aplikace používající standardní vstup a výstup. */
public class GuessC
{
    private static Scanner sc = new Scanner(System.in);

    /** Hlavní metoda aplikace, kterou spustí virtuální stroj. */
    public static void main(String[] args)
    {
        int number = new java.util.Random().nextInt(100); //Hádané číslo
        String msg = "Myslím si číslo od 0 do 100.\n"
                   + "Zkus jej uhodnout.\n"
                   + "Zadáním nuly předčasně ukončíš hru";
        int guess = 0;              //Proměnná pro odpovědi uživatele
        for(;;) {
            guess = enter(msg);     //Další odhad
            if (guess == number)    break;  //Trefil se
            msg = "Zadal jsi " + guess + " - "
                + ((guess < number)  ?  "To je málo."
                                     :  "To je moc.")
                + " - Zkus to znovu.";
        }
        System.out.print("Hurá! To bylo ono!\nDěkuji za hru.");
    }

    /** Pomocná metoda realizující vstup. */
    private static int enter(String msg)
    {
        System.out.print(msg + "\nZadáš: ");    //Neodřádkuje
        int result;
        for(;;) {
            try {
                result = sc.nextInt();  //Přečte další odhad
                if (result == 0) {      //Uživatel už chce končit
                    System.out.print("Děkuji za hru\n");
                    System.exit(0);     //Ukončení aplikace ≡≡≡≡≡≡≡≡≡≡>
                }
            } catch (Exception e) {
                String answer = sc.next();  //Přečte vadný token
                System.out.print(answer + " není celé číslo, zkus to znovu"
                               + "\nZadej celé číslo: ");
                continue;   //Necháme uživatele zadat odhad znovu
            }
            return result;
        }
    }
}
