// Příliš žluťoučký kůň úpěl ďábelské ó - PŘÍLIŠ ŽLUŤOUČKÝ KŮŇ ÚPĚL ĎÁBELSKÉ Ó
// J:/77_JAVA/b77_java_nz2/_27_application/Guess.java

import java.util.Scanner;

/** Konzolová aplikace používající standardní vstup a výstup. */
public class GuessC2
{
    /** Hlavní metoda aplikace, kterou spustí virtuální stroj. */
    public static void main(String[] args)
    {
        int number = new java.util.Random().nextInt(100); //To bude hádat
        String msg = "Myslím si číslo od 0 do 100.\n"
                   + "Zkus jej uhodnout.\n"
                   + "Zadáním nuly předčasně ukončíš hru";
        int guess = 0;              //Proměnná pro odpovědi uživatele
        for(;;) {
            guess = Enter.enter(msg);     //Další odhad
            if (guess == number)    break;  //Trefil se
            msg = ((guess < number)  ?  "To je málo."
                                     :  "To je moc.")
                + " - Zkus to znovu.";
        }
        System.out.println("Hurá! To bylo ono!\nDěkuji za hru.");
    }
}

class Enter
{
    private static Scanner sc = new Scanner(System.in);

    /** Pomocná metoda realizující vstup. */
    public static int enter(String msg)
    {
        System.out.print(msg + "\nZadáš: ");    //Neodřádkuje
        int result;
        for(;;) {
            try {
                result = sc.nextInt();  //Přečte další odhad
                if (result == 0) {      //Uživatel už chce končit
                    System.out.println("Děkuji za hru\n");
                    System.exit(0);     //Ukončení aplikace //≡≡≡≡≡≡≡≡≡≡>
                }
            } catch (Exception e) {
                System.out.println("To nebylo celé číslo, zkus to znovu"
                                 + "\nZadáš: ");
                continue;   //Necháme uživatle zadat odhad znovu
            }
            return result;
        }
    }
}
