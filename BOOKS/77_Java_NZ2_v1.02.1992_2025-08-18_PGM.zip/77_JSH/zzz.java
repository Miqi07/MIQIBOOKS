public class zzz extends c {
    public void mtd() { System.out.println("Žiju"); }

    public static void main(String[] args) {
        new zzz().mtd();
    }
}

interface i {
    void mtd();
}

abstract class c implements i {
}

